#!/bin/bash
set -euo pipefail
source config/default.conf

aws ssm put-parameter --name "AIDP.CONFIG.PROJECT-SHORT-NAME" --type String --value "${PROJECT_SHORT_NAME}" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.ENVIRONMENT" --type String --value "${ENVIRONMENT}" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.VPC-CIDR" --type String --value "${VPC_CIDR}" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.PUBLIC-SUBNET-CIDRS" --type StringList --value "${PUBLIC_SUBNET1_CIDR},${PUBLIC_SUBNET2_CIDR}" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.PRIVATE-SUBNET-CIDRS" --type StringList --value "${PRIVATE_SUBNET1_CIDR},${PRIVATE_SUBNET2_CIDR}" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.PRIVATE-DB-SUBNET-CIDRS" --type StringList --value "${PRIVATE_DB_SUBNET1_CIDR},${PRIVATE_DB_SUBNET2_CIDR}" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.AZS" --type StringList --value "${AZ1},${AZ2}" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.CORE-BUCKET" --type String --value "${PROJECT_SHORT_NAME}-${AWS_REGION}-${ACCOUNT_ID}-${ENVIRONMENT}-core-bucket" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.DRIVE-SECRET" --type String --value "${PROJECT_SHORT_NAME}-${ENVIRONMENT}-drive-secret" --overwrite
aws ssm put-parameter --name "AIDP.CONFIG.EMAIL" --type String --value "${PROJECT_SHORT_NAME}.${ENVIRONMENT}@emailtest.amorphic.team" --overwrite

echo "Config SSM Parameters created."