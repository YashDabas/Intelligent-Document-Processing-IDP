#!/bin/bash
set -euo pipefail
source config/default.conf

mkdir -p ~/.aws
touch ~/.aws/config
echo "[default]" > ~/.aws/config
echo "output = json" >> ~/.aws/config
echo "region = ${AWS_REGION}" >> ~/.aws/config
echo "role_arn = ${BB_OIDC_ROLE_ARN}" >> ~/.aws/config
echo $BITBUCKET_STEP_OIDC_TOKEN > $(pwd)/web-identity-token
echo $BITBUCKET_STEP_OIDC_TOKEN
echo "web_identity_token_file = $(pwd)/web-identity-token" >> ~/.aws/config
cat ~/.aws/config
echo "AWS configuration done."