"""pylint"""
import os
import json
from datetime import datetime, timedelta
import logging
import urllib.parse
import uuid
import email
import re
from email import policy
import io
from boto3.dynamodb.conditions import Key
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import fitz  # PyMuPDF
import requests
import boto3
from IDPutils import response, get_current_time, get_item, query_items, put_item, update_item, delete_item, generate_presigned_url, send_email, paginate_list
from GoogleUtils.auth import refresh_google_token


LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

DOCVAULTS_BUCKET = os.environ.get("DOCVAULTS_BUCKET")
FILES_TABLE = os.environ.get("FILES_TABLE","IDP-Files-Table")
TOKENS_TABLE = os.environ.get("TOKENS_TABLE")
ACCESS_TABLE = os.environ.get("ACCESS_TABLE","IDP-Access-Table")
DOCVAULTS_TABLE = os.environ.get("DOCVAULTS_TABLE","IDP-Docvaults-Table")
USERS_TABLE = os.environ.get("USERS_TABLE")
EXTRACTED_FILES_TABLE = os.environ.get("EXTRACTED_FILES_TABLE")
ACCESS_TABLE_DOCVAULT_INDEX=os.getenv("ACCESS_TABLE_INDEX")
EMAIL_ID_INDEX = os.environ.get("USERS_TABLE_INDEX")
DOCVAULTS_TABLE_INDEX = os.environ.get("DOCVAULTS_TABLE_INDEX")
SOURCE_EMAIL=os.getenv("SOURCE_EMAIL")
VALID_SHARED_USERS_SORT_KEYS=["Username","AccessType","CreatedAt","LastModifiedAt"]
CLIENT_ID = json.loads(os.environ.get('DRIVE_CLIENT_ID'))
CLIENT_SECRET = json.loads(os.environ.get('DRIVE_CLIENT_SECRET'))
API_KEY = json.loads(os.environ.get('DRIVE_API_KEY'))
REDIRECT_URI = json.loads(os.environ.get('CALL_BACK_URL'))


SECRETS_CLIENT = boto3.client("secretsmanager")
S3_CLIENT = boto3.client("s3")
DYNAMODB = boto3.resource("dynamodb")

SES_CLIENT = boto3.client('ses')
SQS_CLIENT = boto3.client('sqs')
SQS_QUEUE_URL = os.environ.get("SQS_QUEUE_URL")
MAX_FILES_PER_REQUEST = 100  # Safety limit
MAX_RETRIES = 3



VALID_CONTENT_TYPES = [
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/tiff"
]

def list_shared_users(event, docvault_id):
    """
    Lists all shared users for a given docvault.

    This function retrieves a paginated list of users who have access to a specific docvault.
    It supports pagination (limit, offset) and sorting based on predefined keys.

    Args:
        event (dict): The Lambda event object, containing 'queryStringParameters' for
                      'limit', 'offset', and 'sort-by'.
        docvault_id (str): The unique identifier of the docvault for which to list shared users.

    Returns:
        dict: An API Gateway compatible response dictionary.
              - On success: Contains a dictionary with 'SharedUsers' list,'totalRecords', 'offset', and 'limit'.
              - On error : Contains an 'Error' message.
    """
    try:
        query_string_parameters = event.get("queryStringParameters", {})
        limit_param = query_string_parameters.get("limit")
        sort_by = query_string_parameters.get("sort-by")
        offset_param = query_string_parameters.get("offset")
        try:
            limit = int(limit_param) if limit_param else 15
            offset = int(offset_param) if offset_param else 0
        except ValueError:
            LOGGER.error(
                "In IDP-DocVaults-Lambda.list_shared_users, Limit and offset must be integers."
            )
            return response(400, {"Error": "Limit and offset must be integers."})

        shared_users = query_items(
            table_name=ACCESS_TABLE,
            key_condition_expression=Key("DocVaultId").eq(docvault_id),
            index_name=ACCESS_TABLE_DOCVAULT_INDEX,
            projection_expression="Username,AccessType,CreatedAt,LastModifiedAt",
        )
        result = paginate_list(
            "SharedUsers",
            shared_users,
            VALID_SHARED_USERS_SORT_KEYS,
            offset,
            limit,
            sort_by,
        )
        return response(200, result)
    except Exception as e:
        LOGGER.error(
            "In IDP-DocVaults-Lambda.list_shared_users, Error in listing shared users: %s",
            e,
            exc_info=True,
        )
        return response(500, {"Error": f"Error in listing shared users: {e}"})


def manage_share(event, owner, docvault_id, docvault_name):
    """
    Manages access permissions (grant, revoke, update) for users to a given docvault.

    This function supports three actions:
    - 'grant-access': Adds new users or updates existing users' access type.
    - 'remove-access': Revokes access for a specific user.
    - 'update-access': Changes the access type (VIEWER/EDITOR) for an existing user.

    It performs necessary validations, interacts with DynamoDB to modify access records,
    and sends email notifications.

    Args:
        event (dict): The Lambda event object, containing 'queryStringParameters' (for 'action')
                      and 'body' (JSON payload with user details).
        owner (str): The username of the docvault owner, used in email notifications.
        docvault_id (str): The unique identifier of the docvault whose access is being managed.

    Returns:
        dict: An API Gateway compatible response dictionary.
              - On success: Contains a 'Message' indicating success.
              - On error: Contains an 'Error' message.
    """
    query_string_parameters = event.get("queryStringParameters", {})
    if not query_string_parameters:
        LOGGER.error(
            "In IDP-DocVaults-Lambda.manage_share, Query string parameter must be provided."
        )
        return response(400, {"Error": "Query string parameter must be provided"})

    access_permission = query_string_parameters.get("action")
    if access_permission is None:
        LOGGER.error(
            "In IDP-DocVaults-Lambda.manage_share, Action must be provided (grant-access, remove-access, or update-access)."
        )
        return response(
            400,
            {
                "Error": "Action must be provided(grant-access, remove-access, or update-access)"
            },
        )

    try:
        body = json.loads(event.get("body") or "{}")
    except (json.JSONDecodeError, TypeError):
        LOGGER.error(
            "In IDP-DocVaults-Lambda.manage_share, Invalid JSON body provided."
        )
        return response(400, {"Error": "Invalid JSON body provided."})

    if access_permission == "grant-access":
        LOGGER.info(
            "In IDP-DocVaults-Lambda.manage_share, Granting access to the users."
        )
        new_users = []  # storing({'Username':username,"AccessType":accesstype})
        update_users = []
        new_users_access = {"VIEWER": [], "EDITOR": []}

        users_to_process = body.get("Users", [])
        if not users_to_process:
            LOGGER.error(
                "In IDP-DocVaults-Lambda.manage_share, No users provided for granting access."
            )
            return response(400, {"Error": "No users provided for granting access."})

        try:
            for user in users_to_process:
                user_name = user.get("Username")
                access_type = user.get("AccessType")

                if not user_name or not access_type:
                    LOGGER.error(
                        "In IDP-DocVaults-Lambda.manage_share, Missing username or access type for a user in 'grant-access'."
                    )
                    return response(
                        400,
                        {
                            "Error": f"Please provide all the details- username and access type(VIEWER,EDITOR) for user: {user_name}"
                        },
                    )
                if access_type not in ["VIEWER", "EDITOR"]:
                    LOGGER.error(
                        "In IDP-DocVaults-Lambda.manage_share, Invalid access type '%s' provided for user '%s' in 'grant-access'.",
                        access_type,
                        user_name,
                    )
                    return response(
                        400,
                        {"Error": f"Invalid access type is provided for {user_name}"},
                    )
                # Fetch usering item to ensure user exists
                user_item = get_item(USERS_TABLE, {"Username": user_name})
                if user_item is None:
                    LOGGER.error(
                        "In IDP-DocVaults-Lambda.manage_share, Invalid user: %s (user not found in USERS_TABLE) in 'grant-access'.",
                        user_name,
                    )
                    return response(400, {"Error": f"Invalid user: {user_name}"})

                # checking if user is the owner of the docvault
                if user_name == owner:
                    LOGGER.error(
                        "In IDP-DocVaults-Lambda.manage_share, Owner cannot be granted access to the docvault."
                    )
                    return response(
                        400, {"Error": "You cannot grant access to yourself."}
                    )

                # Fetching existing access item for the user and docvault
                user_access_item = get_item(
                    ACCESS_TABLE,
                    {"Username": user_name, "DocVaultId": docvault_id},
                )

                if user_access_item is None:
                    # giving access for the first time
                    new_users_access[access_type].append(user_item.get("Email"))
                    new_users.append({"Username": user_name, "AccessType": access_type})
                elif user_access_item.get("AccessType") != access_type:
                    # updating the access type
                    update_users.append(
                        {"Username": user_name, "AccessType": access_type}
                    )

            # adding records to the table
            for item in new_users:
                put_item(
                    ACCESS_TABLE,
                    {
                        "Username": item["Username"],
                        "DocVaultId": docvault_id,
                        "AccessType": item["AccessType"],
                        "CreatedAt": get_current_time(),
                        "LastModifiedAt": get_current_time(),
                    },
                )

            LOGGER.info(
                "In IDP-DocVaults-Lambda.manage_share, New users: %s", new_users
            )
            LOGGER.info(
                "In IDP-DocVaults-Lambda.manage_share, Users whose access is being updated: %s",
                update_users,
            )

            # updating the records in the table with modified access
            for item in update_users:
                LOGGER.info(
                    "In IDP-DocVaults-Lambda.manage_share, Item for update: %s", item
                )
                update_expression = (
                    "SET AccessType = :access_type, LastModifiedAt = :last_modified_at"
                )
                expression_values = {
                    ":access_type": item["AccessType"],
                    ":last_modified_at": get_current_time(),
                }
                update_item(
                    table_name=ACCESS_TABLE,
                    key={"Username": item["Username"], "DocVaultId": docvault_id},
                    update_expression=update_expression,
                    expression_attributes=expression_values,
                )

            # sending email to only new users
            for access_type, users_list in new_users_access.items():
                if users_list:
                    data = (
                        f"Hi,\n\n"
                        f"  {owner} has shared DocVault '{docvault_name}' with you.\n"
                        f"You can now {'edit' if access_type == 'EDITOR' else 'view'} this DocVault in the website.\n"
                        f"Have a nice day!\n\n"
                        f"Thanks,\n"
                        f"DocVault Team"
                    )
                    send_email(
                        SOURCE_EMAIL,
                        f"Access to DocVault '{docvault_name}' Shared",
                        data,
                        users_list,
                    )

            return response(200, {"Message": "Successfully granted access to users"})

        except Exception as e:
            LOGGER.error(
                "In IDP-DocVaults-Lambda.manage_share, Error during 'grant-access' operation: %s",
                e,
                exc_info=True,
            )
            return response(
                500, {"Error": f"Error during 'grant-access' operation: {e}"}
            )

    elif access_permission == "remove-access":

        user_name = body.get("Username")
        LOGGER.info(
            "In IDP-DocVaults-Lambda.manage_share, User name for removal: %s", user_name
        )
        if not user_name:
            LOGGER.error(
                "In IDP-DocVaults-Lambda.manage_share, Username not provided for removal."
            )
            return response(400, {"Error": "Please provide username"})
        # checking if user exists
        user_item = get_item(USERS_TABLE, {"Username": user_name})
        user_email = user_item.get("Email")
        if user_item is None:
            LOGGER.error(
                "In IDP-DocVaults-Lambda.manage_share, Invalid username provided for removal: %s",
                user_name,
            )
            return response(
                400, {"Error": f"Invalid username is provided: {user_name}"}
            )

        user_email = user_item.get("Email")
        user_access_item = get_item(
            ACCESS_TABLE, {"Username": user_name, "DocVaultId": docvault_id}
        )
        if user_access_item is None:
            LOGGER.error(
                "In IDP-DocVaults-Lambda.manage_share, User '%s' does not have access to this docvault.",
                user_name,
            )
            return response(
                400, {"Error": f"{user_name} does not have access to this docvault"}
            )

        try:
            delete_item(
                ACCESS_TABLE, {"Username": user_name, "DocVaultId": docvault_id}
            )
            data = (
                f"Hi,\n\n"
                f"  {owner} has revoked your access to DocVault '{docvault_name}'.\n"
                f"You can no longer access this DocVault in the website.\n"
                f"Please contact {owner} for further details.\n"
                f"Have a nice day!\n\n"
                f"Thanks,\n"
                f"DocVault Team"
            )

            send_email(
                SOURCE_EMAIL,
                f"Access to DocVault '{docvault_name}' Revoked",
                data,
                user_email,
            )
            LOGGER.info(
                "In IDP-DocVaults-Lambda.manage_share, Email sent to user for removal: %s",
                user_email,
            )
            return response(
                200, {"Message": f"Successfully revoked access to {user_name}"}
            )

        except Exception as e:
            LOGGER.error(
                "In IDP-DocVaults-Lambda.manage_share, Error revoking access or sending email: %s",
                e,
                exc_info=True,
            )
            return response(
                500, {"Error": f"Error revoking access to {user_name}: {e}"}
            )

    elif access_permission == "update-access":
        user_name = body.get("Username")
        access_type = body.get("AccessType")

        LOGGER.info("In IDP-DocVaults-Lambda.manage_share, Entered update access flow.")
        LOGGER.info(
            "In IDP-DocVaults-Lambda.manage_share, User name: %s, Access type: %s",
            user_name,
            access_type,
        )
        if not user_name or not access_type:
            return response(400, {"Error": "Please provide username and access type"})

        if access_type not in ["VIEWER", "EDITOR"]:
            return response(400, {"Error": "Invalid access type is provided"})

        user_item = get_item(USERS_TABLE, {"Username": user_name})
        if user_item is None:
            return response(
                400, {"Error": f"Invalid username is provided: {user_name}"}
            )
        user_access_item = get_item(
            ACCESS_TABLE, {"Username": user_name, "DocVaultId": docvault_id}
        )

        if user_access_item is None:
            return response(
                400, {"Error": f"{user_name} does not have access to this docvault"}
            )
        update_expression = (
            "SET AccessType = :access_type, LastModifiedAt = :last_modified_at"
        )
        expression_values = {
            ":access_type": access_type,
            ":last_modified_at": get_current_time(),
        }
        update_item(
            table_name=ACCESS_TABLE,
            key={"Username": user_name, "DocVaultId": docvault_id},
            update_expression=update_expression,
            expression_attributes=expression_values,
        )
        return response(200, {"Message": f"Successfully updated access to {user_name}"})

    elif access_permission == "transfer-ownership":
        user_name = body.get("Username")
        LOGGER.info(
            "In IDP-DocVaults-Lambda.manage_share, Entered transfer ownership flow."
        )
        if not user_name:
            return response(400, {"Error": "Please provide username"})

        user_item = get_item(USERS_TABLE, {"Username": user_name})
        if user_item is None:
            return response(
                400, {"Error": f"Invalid username is provided: {user_name}"}
            )

        user_access_item = get_item(
            ACCESS_TABLE, {"Username": user_name, "DocVaultId": docvault_id}
        )
        if user_access_item:
            delete_item(
                ACCESS_TABLE, {"Username": user_name, "DocVaultId": docvault_id}
            )
        update_expression = "SET CreatedBy = :user_name, LastModifiedAt = :last_modified_at, LastModifiedBy = :last_modified_by"
        expression_values = {
            ":user_name": user_name,
            ":last_modified_at": get_current_time(),
            ":last_modified_by": owner,
        }
        update_item(
            table_name=DOCVAULTS_TABLE,
            key={"DocVaultId": docvault_id},
            update_expression=update_expression,
            expression_attributes=expression_values,
        )
        return response(
            200, {"Message": f"Successfully transferred ownership to {user_name}"}
        )
    else:
        return response(400, {"Error": "Invalid action is provided"})


def get_google_drive_credentials_with_refresh(username):
    """
    Retrieves Google Drive credentials for the specified user, refreshing the access token if expired.

    This function performs the following:
    1. Retrieves the token reference from DynamoDB using the provided username.
    2. Fetches the actual token data from AWS Secrets Manager.
    3. Checks if the access token has expired and refreshes it if necessary.
    4. Returns a google.auth.credentials.Credentials object for authenticated access.

    Args:
        username (str): The username for which to retrieve Google Drive credentials.

    Returns:
        Credentials: An authenticated Google credentials object.

    Raises:
        Exception: If the credentials cannot be retrieved or refreshed.
    """
    try:
        # 1. Get token reference from DynamoDB
        item = get_item(TOKENS_TABLE, key={"Username": username})
        if not item:
            raise Exception("No Google token found for user")
        # 2. Get actual tokens from Secrets Manager
        secret = SECRETS_CLIENT.get_secret_value(SecretId=item["SecretARN"])
        token_data = json.loads(secret["SecretString"])
        # 3. Check if token needs refresh
        expires_at = datetime.fromisoformat(item.get("ExpiresAt"))
        if datetime.now() >= expires_at:
            LOGGER.info("Refreshing expired Google token")
            token_data["access_token"] = refresh_google_token(
                item, token_data, CLIENT_ID, CLIENT_SECRET, TOKENS_TABLE
            )["access_token"]
        # 4. Return credentials
        return Credentials(
            token=token_data["access_token"],
            refresh_token=token_data["refresh_token"],
            token_uri="https://oauth2.googleapis.com/token",
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET,
        )
    except Exception as e:
        LOGGER.error("In IDPDependencies, Failed to get credentials: %s", str(e))
        raise


def update_upload_status(record):
    """
    Extracts metadata from an uploaded S3 object and updates the corresponding entry in the DynamoDB files table.

    The function:
    - Parses the S3 event record to get the bucket key.
    - Checks if the uploaded file is a PDF.
    - If it is a PDF and has more than 20 pages, marks it as 'Failed' and deletes the entry from DynamoDB.
    - Otherwise, updates the upload status to 'Uploaded'.

    Args:
        record (dict): S3 event record from the trigger.

    Returns:
        dict: API-style response with statusCode and body.
    """
    try:
        LOGGER.info("Adding file metadata to files table")

        try:
            object_key = record.get("s3").get("object").get("key")
            docvault_id = object_key.split("/")[1]
            file_name = object_key.split("/")[-1]
            s3_head_object = S3_CLIENT.head_object(
                Bucket=DOCVAULT_BUCKET, Key=object_key
            )
            s3_object = S3_CLIENT.get_object(
                Bucket=DOCVAULT_BUCKET, Key=object_key
            )

            LOGGER.info(
                "In IDP-Docvaults-Lambda.update_upload_status, s3_object: %s", s3_object
            )

            if s3_head_object.get("ContentType") == "application/pdf":
                pdf_file = fitz.open(stream=s3_object["Body"].read(), filetype="pdf")
                num_pages = pdf_file.page_count
                pdf_file.close()
                if num_pages > 50:
                    S3_CLIENT.delete_object(Bucket=DOCVAULT_BUCKET, Key=object_key)

                    LOGGER.info("PDF with more than 50 pages")
                    update_item(
                        FILES_TABLE,
                        key={"FileName": file_name, "DocVaultId": docvault_id},
                        update_expression="SET UploadStatus = :status , Message = :msg",
                        expression_attributes={
                            ":status": "Failed",
                            ":msg": "PDF with more than 50 pages",
                        },
                    )
                else:
                    LOGGER.info("PDF with less than 20 pages")
                    update_item(
                        FILES_TABLE,
                        key={"FileName": file_name, "DocVaultId": docvault_id},
                        update_expression="SET UploadStatus = :status REMOVE UploadFailedTTL",
                        expression_attributes={":status": "Uploaded"},
                    )

            else:
                LOGGER.info("File is not a PDF")
                update_item(
                    FILES_TABLE,
                    key={"FileName": file_name, "DocVaultId": docvault_id},
                    update_expression="SET UploadStatus = :status REMOVE UploadFailedTTL",
                    expression_attributes={":status": "Uploaded"},
                )

            return response(200, {"Response": "File saved successfully"})
        except Exception as e:
            LOGGER.error(
                "In IDP-Docvaults-Lambda.update_upload_status failed with Error: %s",
                str(e),
            )
            return response(500, e)

    except Exception as e:
        LOGGER.error(
            "In IDP-Docvaults-Lambda.update_upload_status failed with Error: %s", str(e)
        )
        return response(500, e)


def handle_google_auth(user_details):
    """
    Handles Google OAuth authentication for a user.

    If a valid token is already stored in the DynamoDB tokens table and not expired, it retrieves
    the tokens from AWS Secrets Manager and returns them to the client. Otherwise, it constructs
    a Google OAuth consent URL to initiate authentication.

    Args:
        user_details (dict): Dictionary containing user-related details. Must include "username".

    Returns:
        dict: API Gateway-compatible response with either:
              - Authenticated status and tokens if valid token exists, or
              - Unauthenticated status and Google OAuth URL to initiate login.
              On error, returns a 500 status with an error message.
    """
    try:
        LOGGER.info("Handling google auth")

        token_obj = get_item(
            TOKENS_TABLE, key={"Username": user_details.get("username")}
        )

        if token_obj:
            LOGGER.info("Token found in tokens table")
            # REDIRECT TO GOOGLE PICKER
            if datetime.fromisoformat(token_obj.get("ExpiresAt")) > datetime.now():
                LOGGER.info("Token is valid")
                tokens = SECRETS_CLIENT.get_secret_value(
                    SecretId=token_obj.get("SecretARN")
                )
                tokens = json.loads(tokens["SecretString"])
                # LOGGER.info("Tokens: {tokens}")
                return response(
                    200,
                    {
                        "Status": "Authenticated",
                        "AccessToken": tokens["access_token"],
                        "ClientId": CLIENT_ID,
                        "APIKey": API_KEY,
                    },
                )
            else:
                LOGGER.info("Token is expired")
                # REFRESH TOKEN
                try:
                    LOGGER.info("Refreshing token")
                    tokens = SECRETS_CLIENT.get_secret_value(
                        SecretId=token_obj.get("SecretARN")
                    )
                    tokens = json.loads(tokens["SecretString"])
                    tokens = refresh_google_token(
                        token_obj, tokens, CLIENT_ID, CLIENT_SECRET, TOKENS_TABLE
                    )
                    # LOGGER.info(f"Token refreshed : {tokens}")
                    return response(
                        200,
                        {
                            "Status": "Authenticated",
                            "AccessToken": tokens["access_token"],
                            "ClientId": CLIENT_ID,
                            "APIKey": API_KEY,
                        },
                    )
                except Exception as e:
                    LOGGER.error(
                        "In IDP-Docvaults-Lambda.handle_google_auth failed with Error: %s",
                        str(e),
                    )
                    return response(500, e)
        auth_url = (
            "https://accounts.google.com/o/oauth2/v2/auth?"
            + urllib.parse.urlencode(
                {
                    "client_id": CLIENT_ID,
                    "redirect_uri": REDIRECT_URI,
                    "response_type": "code",
                    "scope": "https://www.googleapis.com/auth/drive",
                    "access_type": "offline",
                    "prompt": "consent",
                }
            )
        )

        return response(200, {"Status": "Unauthenticated", "AuthUrl": auth_url})
    except Exception as e:
        LOGGER.error(
            "In IDP-Docvaults-Lambda.handle_google_auth failed with Error: %s", str(e)
        )
        return response(500, e)


def code_token_exhange(code, user_details):
    """
    Exchanges an OAuth 2.0 authorization code for access and refresh tokens using Google's OAuth endpoint.
    Stores the retrieved tokens in AWS Secrets Manager and references them in a DynamoDB table.

    Args:
        code (str): The authorization code received from the OAuth redirect.
        user_details (dict): Dictionary containing user information (expects a 'username' key).

    Returns:
        dict: A response object with HTTP status code, headers, and body indicating the success or failure of the token exchange.
              If successful, includes the access and refresh tokens in the response body.
    """
    try:

        if not code:
            return response(400, {"error": "Authorization code missing"})

        # Exchange code for tokens
        token_response = requests.post(
            "https://oauth2.googleapis.com/token",
            data={
                "code": code,
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "redirect_uri": REDIRECT_URI,
                "grant_type": "authorization_code",
            },
        )

        # LOGGER.info(f"Token response: {token_response}")

        if token_response.status_code != 200:
            return response(400, {"error": "Token exchange failed"})

        tokens = token_response.json()
        username = user_details.get("username")

        # Store tokens in Secrets Manager
        secret_name = f"IDP-Google-Auth-Token/{username}"
        secret_value = {
            "access_token": tokens["access_token"],
            "refresh_token": tokens["refresh_token"],
            "expires_at": (
                datetime.now() + timedelta(seconds=tokens["expires_in"])
            ).isoformat(),
        }

        try:
            secret_response = SECRETS_CLIENT.create_secret(
                Name=secret_name,
                SecretString=json.dumps(secret_value),
                Description=f"Google OAuth tokens for {username}",
                Tags=[
                    {"Key": "Owner", "Value": username},
                    {"Key": "Provider", "Value": "Google"},
                ],
            )
            secret_arn = secret_response["ARN"]
            # Store only the Secret ARN in DynamoDB
            put_item(
                TOKENS_TABLE,
                item={
                    "Username": username,
                    "Provider": "Google",
                    "SecretARN": secret_arn,  # Reference to Secrets Manager
                    "CreatedAt": datetime.now().isoformat(),
                    "ExpiresAt": (
                        datetime.now() + timedelta(seconds=tokens["expires_in"])
                    ).isoformat(),
                    "LastModifiedAt": datetime.now().isoformat(),
                },
            )
        except SECRETS_CLIENT.exceptions.ResourceExistsException:
            return response(
                200,
                {
                    "Status": "Authenticated",
                    "AccessToken": tokens["access_token"],
                    "ClientId": CLIENT_ID,
                    "APIKey": API_KEY,
                },
            )

        return response(
            200,
            {
                "Status": "Authenticated",
                "AccessToken": tokens["access_token"],
                "ClientId": CLIENT_ID,
                "APIKey": API_KEY,
            },
        )
    except Exception as e:
        LOGGER.error(
            "In IDP-Docvaults-Lambda.code_token_exchange failed with Error: %s", str(e)
        )
        return response(500, e)


def handle_filename_versioning(file_name, docvault_id, file_obj):
    """
    Safely generate versioned components of an S3 key based on the provided filename and existing file metadata.

    Args:
        file_name (str): The new incoming file name (used as fallback if file_obj is not provided).
        docvault_id (str): The identifier of the document vault, used in fallback path.
        file_obj (tuple): A tuple where:
                         - First element is a list of file metadata dicts
                         - Second element is a dict with FileName and DocVaultId

    Returns:
        dict: {
            "basename": str - base name without version or extension,
            "version": int - version number (starting at 0 or 1),
            "ext": str - file extension without dot
        }
        OR str: S3 key with UUID fallback in case of errors
    """
    try:
        # Unpack the tuple - first element is list of files, second is metadata
        file_list, file_metadata = file_obj if file_obj else ([], {})

        # Use the metadata FileName if available, otherwise use the input file_name
        existing_file_name = file_metadata.get("FileName", file_name)
        base_name, ext = os.path.splitext(existing_file_name)
        ext = ext.lstrip(".")  # Remove leading dot

        LOGGER.info(
            "Processing filename: %s, Base: %s, Ext: %s",
            existing_file_name,
            base_name,
            ext,
        )

        # Determine version number
        version = 0  # Default version for new files

        if file_list and len(file_list) > 0:
            # Get the most recent file's name
            latest_file = file_list[0].get("FileName", "")
            LOGGER.info("Existing filename found: %s", latest_file)

            # Extract version number (looking for _N before extension)
            version_match = re.search(r"_(\d+)(?=\.\w+$)", latest_file)
            if version_match:
                version = int(version_match.group(1)) + 1
            else:
                # No version number found, start with 1
                version = 1

        return {"basename": base_name, "version": version, "ext": ext}

    except Exception as e:
        LOGGER.error(
            "Error in handle_filename_versioning for file %s: %s", file_name, str(e)
        )
        # Fallback to UUID if versioning fails
        return (
            f"original/{docvault_id}/{uuid.uuid4()}.{ext}"
            if ext
            else f"original/{docvault_id}/{uuid.uuid4()}"
        )


def handle_ui_upload(docvault_id, files, user_details):
    """
    Handles the generation of presigned URLs for uploading files via the UI to an S3 bucket.

    This function validates each file for content type and size, manages filename versioning,
    logs metadata to a DynamoDB table, and returns presigned S3 URLs for valid uploads.

    Args:
        docvault_id (str): The ID of the document vault to associate uploaded files with.
        files (list): A list of file metadata dictionaries, each containing:
                      - FileName (str)
                      - ContentType (str)
                      - FileSize (int)
        user_details (dict): A dictionary containing user information, typically including:
                             - username (str)

    Returns:
        dict: A response object with status code, headers, and body containing presigned URLs
              or error messages if validation fails.
    """
    try:
        LOGGER.info("Generating presigned urls for file upload")

        presigned_urls = []

        LOGGER.info("Files: {files}")

        if len(files) > 20:
            return response(
                400,
                {
                    "Error": "Too many files. Please upload atmost 20 files at a time. Upload more using Google Drive"
                },
            )
        for file in files:

            original_filename = file.get("FileName")
            file_name = file.get("FileName")
            file_name = file_name.replace(" ", "_")
            file_name = file_name.replace("(", "")
            file_name = file_name.replace(")", "")
            content_type = file.get("ContentType")
            file_size = file.get("FileSize")
            if (
                file_size > 100 * 1024 * 1024 and content_type.startswith("image/")
            ) or content_type not in VALID_CONTENT_TYPES:
                presigned_urls.append(
                    {
                        "FileName": original_filename,
                        "FilePreSignedUrl": "",
                        "Status": "Invalid",
                    }
                )
                continue
            file_obj = query_items(
                FILES_TABLE,
                key_condition_expression="DocVaultId = :pk AND begins_with(FileName, :fn)",
                expression_values={":pk": docvault_id, ":fn": file_name.split(".")[0]},
                scan_index_forward=False,
                limit=1,
            )
            LOGGER.info("File object: %s", file_obj)
            s3_key_parts = handle_filename_versioning(file_name, docvault_id, file_obj)
            s3_key = f"original/{docvault_id}/{s3_key_parts.get('basename')}_{s3_key_parts.get('version')}.{s3_key_parts.get('ext')}"
            try:
                put_item(
                    FILES_TABLE,
                    item={
                        "DocVaultId": docvault_id,
                        "FileName": s3_key.split("/")[-1],
                        "CreatedBy": user_details.get("username"),
                        "CreatedAt": datetime.now().isoformat(),
                        "Source": "Upload",
                        "ExtractStatus": "Unprocessed",
                        "FileSize": file_size,
                        "LastModifiedBy": user_details.get("username"),
                        "LastModifiedAt": datetime.now().isoformat(),
                        "UploadStatus": "Uploading",
                        "UploadFailedTTL": int(datetime.now().timestamp()) + 36000
                    }
                )

                presigned_url = generate_presigned_url(
                    DOCVAULT_BUCKET, s3_key, 3600, "put_object", content_type
                )

                presigned_urls.append(
                    {
                        "FileName": original_filename,
                        "FilePreSignedUrl": presigned_url,
                        "Status": "Uploading"
                    }
                )
            except Exception as e:
                LOGGER.error(
                    "In IDP-Docvaults-Lambda.handle_ui_upload, Failed with: %s", e
                )
                file_item = get_item(
                    FILES_TABLE,
                    key={"DocVaultId": docvault_id, "FileName": original_filename}
                )
                if file_item:
                    update_item(
                        FILES_TABLE,
                        key={"DocVaultId": docvault_id, "FileName": file_name},
                        update_expression="set UploadStatus = :us",
                        expression_attributes={
                            ":us": "Failed"
                        }
                    )
                presigned_urls.append(
                    {
                        "FileName": original_filename,
                        "FilePreSignedUrl": "",
                        "Status": "Failed"
                    }
                )

        LOGGER.info("Presigned urls: %s", presigned_urls)

        return response(202, {"Message": "Upload Started", "Files": presigned_urls})
    except Exception as e:
        LOGGER.error(
            "In IDP-Docvaults-Lambda.handle_ui_upload failed with Error: %s", str(e)
        )
        return response(500, e)


def handle_google_drive_upload(docvault_id, file_ids, user_details):
    """
    Handles file uploads from Google Drive by queuing them for processing and updating metadata in DynamoDB.

    This function:
    - Authenticates the user using stored Google credentials.
    - Validates file count.
    - Fetches file metadata from Google Drive.
    - Generates a versioned S3 key for each file.
    - Stores file metadata in a DynamoDB table.
    - Queues file data into an SQS queue for async processing.

    Args:
        docvault_id (str): The identifier for the document vault to which files are being uploaded.
        file_ids (list[str]): A list of Google Drive file IDs to be uploaded.
        user_details (dict): Dictionary containing user information, expects a "username" key.

    Returns:
        dict: A JSON response with HTTP status code and body containing the result message or error.
    """
    try:
        username = user_details.get("username")
        # Validate input
        if len(file_ids) > MAX_FILES_PER_REQUEST:
            return response(
                400, {"error": f"Max {MAX_FILES_PER_REQUEST} files per request"}
            )
        creds = get_google_drive_credentials_with_refresh(username)
        service = build("drive", "v3", credentials=creds)
        files = []
        # Push each file ID to SQS as separate message
        for file_id in file_ids:
            file_meta = (
                service.files()
                .get(fileId=file_id, fields="name,size,mimeType,modifiedTime")
                .execute()
            )

            file_name = file_meta["name"]
            file_name = file_name.replace(" ", "_")
            file_name = file_name.replace("(", "")
            file_name = file_name.replace(")", "")
            file_size = int(file_meta.get("size", 0))
            mime_type = file_meta.get("mimeType", "application/octet-stream")

            file_obj = query_items(
                FILES_TABLE,
                key_condition_expression="DocVaultId = :pk AND begins_with(FileName, :fn)",
                expression_values={
                    ":pk": docvault_id,
                    ":fn": file_name.split(".")[0],
                },
                scan_index_forward=False,
                limit=1,
            )

            s3_key_parts = handle_filename_versioning(file_name, docvault_id, file_obj)
            s3_key = f"original/{docvault_id}/{s3_key_parts.get('basename')}_{s3_key_parts.get('version')}.{s3_key_parts.get('ext')}"
            files.append(s3_key.split("/")[-1])

            put_item(
                FILES_TABLE,
                item={
                    "DocVaultId": docvault_id,
                    "FileName": s3_key.split("/")[-1],
                    "CreatedBy": username,
                    "CreatedAt": datetime.now().isoformat(),
                    "Source": "Google Drive",
                    "ExtractStatus": "Unprocessed",
                    "FileSize": file_size,
                    "LastModifiedBy": username,
                    "LastModifiedAt": datetime.now().isoformat(),
                    "UploadStatus": "Uploading",
                    "UploadFailedTTL": int(datetime.now().timestamp()) + 36000,
                },
            )

            SQS_CLIENT.send_message(
                QueueUrl=SQS_QUEUE_URL,
                MessageBody=json.dumps(
                    {
                        "file_id": file_id,
                        "file_name": s3_key.split("/")[-1],
                        "file_size": file_size,
                        "mime_type": mime_type,
                        "s3_key": s3_key,
                        "docvault_id": docvault_id,
                        "username": username,
                        "retry_count": 0,
                    }
                ),
            )
        return response(202, {"message": "Uploading Started", "Files": files})
    except Exception as e:
        return response(500, {"error": str(e)})


def handle_sqs(records):
    """
    Processes a batch of records received from an Amazon SQS queue.

    This function:
    - Parses each message from the SQS records.
    - Validates the presence of required fields.
    - Calls the `process_file` function to handle each file.
    - Deletes successfully processed messages from the queue.
    - Implements retry with exponential backoff for failed messages.

    Args:
        records (list): A list of records from the SQS event, where each record contains a message body.

    Returns:
        dict: A response dict with statusCode and results or error message.
    """
    try:
        LOGGER.info("Processing %s records", len(records))
        results = []
        for record in records:
            try:
                message = json.loads(record["body"])
                required_fields = ["file_id", "docvault_id", "username", "retry_count"]
                if not all(field in message for field in required_fields):
                    LOGGER.error(
                        "In IDP-Docvaults-Lambda.handle_sqs failed with: , Missing required fields in sqs message"
                    )
            except json.JSONDecodeError:
                LOGGER.error(
                    "in IDP-Docvaults-Lambda.handle_sqs failed with: Malformed SQS message body: %s",
                    record["body"],
                )
                continue
            file_id = message["file_id"]
            file_name = message["file_name"]
            file_size = message["file_size"]
            mime_type = message["mime_type"]
            docvault_id = message["docvault_id"]
            s3_key = message["s3_key"]
            username = message["username"]
            retry_count = message["retry_count"]
            try:
                LOGGER.info("Processing file %s from Google Drive", file_id)
                result = process_file(
                    file_id,
                    file_name,
                    file_size,
                    mime_type,
                    s3_key,
                    username,
                    docvault_id,
                )
                LOGGER.info("Processing done")
                results.append(result)
                # Delete from queue if successful
                if result["status"] == "success":
                    SQS_CLIENT.delete_message(
                        QueueUrl=SQS_QUEUE_URL, ReceiptHandle=record["receiptHandle"]
                    )
            except Exception:
                # Increment retry count and re-queue
                if retry_count < MAX_RETRIES:
                    SQS_CLIENT.change_message_visibility(
                        QueueUrl=SQS_QUEUE_URL,
                        ReceiptHandle=record["receiptHandle"],
                        VisibilityTimeout=30 * (retry_count + 1),  # Exponential backoff
                    )
                raise
        return response(200, {"results": results})
    except Exception as e:
        return response(500, {"error": str(e)})


def process_file(
    file_id, file_name, file_size, mime_type, s3_key, username, docvault_id
):
    """
    Downloads a file from Google Drive and uploads it to Amazon S3 with proper validation and handling.

    This function authenticates using the user's Google Drive credentials, validates file size and type,
    and uploads the file to an S3 bucket. It uses multipart upload for large files (>25MB) and standard
    upload for smaller ones. Also adds metadata to the uploaded S3 object.

    Args:
        file_id (str): Google Drive file ID.
        file_name (str): Name of the file.
        file_size (int): Size of the file in bytes.
        mime_type (str): MIME type of the file.
        s3_key (str): Target S3 key for upload.
        docvault_id (str): Identifier for the document vault.
        username (str): Username of the owner/uploader.
        retry_count (int): Number of retries attempted.

    Returns:
        dict: A dictionary with upload status and metadata on success.

    Raises:
        Exception: Any error during processing will be raised to the caller.
    """
    try:
        LOGGER.info("Processing file %s for user %s", file_id, username)
        # 1. Get credentials with automatic refresh
        creds = get_google_drive_credentials_with_refresh(username)
        service = build("drive", "v3", credentials=creds)
        # 2. Validate file before processing
        if file_size > 100 * 1024 * 1024:  # 100MB max
            raise ValueError(f"File {file_name} exceeds maximum size limit (100MB)")
        if mime_type not in VALID_CONTENT_TYPES:
            raise ValueError(f"Unsupported file type: {mime_type}")
        # 3. Process based on size
        if file_size > 25 * 1024 * 1024:
            LOGGER.info("Streaming large file (%s bytes) directly to S3", file_size)
            try:
                request = service.files().get_media(fileId=file_id)
                # Use multipart upload for large files
                with io.BytesIO() as file_buffer:
                    downloader = MediaIoBaseDownload(file_buffer, request)
                    done = False
                    while not done:
                        status, done = downloader.next_chunk()
                        LOGGER.info(
                            "Download progress: %s", int(status.progress() * 100)
                        )
                    file_buffer.seek(0)
                    S3_CLIENT.upload_fileobj(
                        file_buffer,
                        DOCVAULT_BUCKET,
                        s3_key,
                        ExtraArgs={
                            "ContentType": mime_type,
                            "Metadata": {
                                "source": "GoogleDrive",
                                "original-filename": file_name,
                                "processed-at": datetime.now().isoformat(),
                            },
                        },
                    )
            except Exception as e:
                LOGGER.error(
                    "In IDP-Docvaults-Lambda.process_file Error processing file %s. Failed with : %s",
                    file_id,
                    str(e),
                )
                file_item = get_item(
                    FILES_TABLE, {"DocVaultId": docvault_id, "FileName": file_name}
                )
                
        else:
            LOGGER.info("Downloading small file (%s bytes)", file_size)
            try:
                request = service.files().get_media(fileId=file_id)
                fh = io.BytesIO()
                downloader = MediaIoBaseDownload(fh, request)
                done = False
                while not done:
                    status, done = downloader.next_chunk()
                    LOGGER.info("Download progress: %s", int(status.progress() * 100))
                fh.seek(0)
                S3_CLIENT.put_object(
                    Bucket=DOCVAULT_BUCKET,
                    Key=s3_key,
                    Body=fh.getvalue(),
                    ContentType=mime_type,
                    Metadata={
                        "source": "GoogleDrive",
                        "original-filename": file_name,
                        "processed-at": datetime.now().isoformat(),
                    },
                )
            except Exception as e:
                LOGGER.error(
                    "In IDP-Docvaults-Lambda.process_file Error processing file %s. Failed with : %s",
                    file_id,
                    str(e),
                )
                file_item = get_item(
                    FILES_TABLE, {"DocVaultId": docvault_id, "FileName": file_name}
                )
                if file_item:
                    update_item(
                        FILES_TABLE,
                        key={"DocVaultId": docvault_id, "FileName": file_name},
                        update_expression="set UploadStatus = :us",
                        expression_attributes={
                            ":us": "Failed"
                        }
                    )
        LOGGER.info("Successfully processed file %s to %s", file_name, s3_key)
        return {
            "status": "success",
            "s3_key": s3_key,
            "file_name": file_name,
            "file_size": file_size
        }
    except Exception as e:
        LOGGER.error(
            "In IDP-Docvaults-Lambda.proces_file Error processing file %s. Failed with : %s",
            file_id,
            str(e),
        )


def save_attachment_to_s3(bucket, docvault_id, attachment, username, file_size):
    """
    Save an email attachment to an S3 bucket with original extension and track metadata in DynamoDB.

    This function:
    - Extracts the filename from the email attachment and sanitizes it.
    - Ensures the filename is unique using a versioning mechanism.
    - Saves metadata about the file to the DynamoDB FILES_TABLE.
    - Uploads the file to S3 under the `original/{docvault_id}/` prefix.

    Args:
        bucket (str): Name of the target S3 bucket.
        docvault_id (str): The ID of the document vault to group attachments.
        attachment (email.message.Message): The email attachment to be stored.
        username (str): The username performing the upload.
        file_size (int): Size of the file in bytes.

    Returns:
        str: The full S3 key where the attachment was saved.

    Raises:
        Exception: If any error occurs during processing or upload.
    """
    try:
        # Generate a unique filename with original extension
        file_name = attachment.get_filename()
        file_name = file_name.replace(" ", "_")
        file_name = file_name.replace("(", "")
        file_name = file_name.replace(")", "")
        LOGGER.info("File name: %s", file_name)

        if not file_name:
            file_name = f"attachment_{uuid.uuid4().hex}"
            content_type = attachment.get_content_type()
            extension = {
                "image/png": ".png",
                "application/pdf": ".pdf",
                "image/jpeg": ".jpg",
                "image/tiff": ".tiff",
            }.get(content_type, ".bin")
            file_name += extension
        file_obj = query_items(
            FILES_TABLE,
            key_condition_expression="DocVaultId = :pk AND begins_with(FileName, :fn)",
            expression_values={
                ":pk": docvault_id,
                ":fn": file_name.split(".")[0],
            },
            scan_index_forward=False,
            limit=1,
        )

        s3_key_parts = handle_filename_versioning(file_name, docvault_id, file_obj)
        s3_key = f"original/{docvault_id}/{s3_key_parts.get('basename')}_{s3_key_parts.get('version')}.{s3_key_parts.get('ext')}"

        put_item(
            FILES_TABLE,
            item={
                "DocVaultId": docvault_id,
                "FileName": s3_key.split("/")[-1],
                "CreatedBy": username,
                "CreatedAt": datetime.now().isoformat(),
                "Source": "Email",
                "FileSize": file_size,
                "ExtractStatus": "Unprocessed",
                "LastModifiedBy": username,
                "LastModifiedAt": datetime.now().isoformat(),
                "UploadStatus": "Uploading",
                "UploadFailedTTL": int(datetime.now().timestamp()) + 360000,
            },
        )
        # Upload to S3
        try:
            S3_CLIENT.put_object(
                Bucket=bucket,
                Key=s3_key,
                Body=attachment.get_payload(decode=True),
                Metadata={"source": "Email", "username": username},
                ContentType=attachment.get_content_type(),
            )
            return s3_key
        except Exception as e:
            LOGGER.error(
                "IN IDP-Docvaults-Lambda.save-attachment_to_s3 Failed to upload attachment to S3: %s",
                str(e),
            )
            file_item = get_item(
                FILES_TABLE,
                key={"DocVaultId": docvault_id, "FileName": s3_key.split("/")[-1]},
            )
            if file_item:
                update_item(
                    FILES_TABLE,
                    key={"DocVaultId": docvault_id, "FileName": s3_key.split("/")[-1]},
                    update_expression="set UploadStatus = :us",
                    expression_attributes={
                        ":us": "Failed"
                    },
                )
    except Exception as e:
        LOGGER.error(
            "IN IDP-Docvaults-Lambda.save-attachment_to_s3 Failed to save attachment: %s",
            str(e),
        )
        raise


def process_email_attachments(email_content, docvault_id, username, sender):
    """
    Extracts, validates, and uploads email attachments to an S3 bucket.

    This function parses the provided email content, filters attachments based on allowed content types,
    validates size and file extensions, and uploads valid files to the specified S3 bucket.
    Invalid files are tracked with appropriate reasons.

    Args:
        email_content (bytes): Raw email content in bytes.
        docvault_id (str): The ID of the document vault for organizing files in S3.
        username (str): The name of the user uploading the attachments.

    Returns:
        dict: A dictionary containing two lists:
            - 'ValidAttachments': List of successfully uploaded attachment metadata.
            - 'InvalidAttachments': List of attachments rejected with reasons.
    """
    msg = email.message_from_bytes(email_content, policy=policy.default)
    valid_content_types = {
        "application/pdf": [".pdf"],
        "image/jpeg": [".jpg", ".jpeg"],
        "image/png": [".png"],
        "image/tiff": [".tiff", ".tif"],
    }
    max_file_size = 5 * 1024 * 1024
    valid_attachments = []
    invalid_attachments = []
    for part in msg.walk():
        if part.get_content_disposition() == "attachment":
            content_type = part.get_content_type()
            file_name = part.get_filename() or f"attachment_{uuid.uuid4().hex}"
            file_name = file_name.replace(" ", "_")
            file_name = file_name.replace("(", "")
            file_name = file_name.replace(")", "")
            file_size = len(part.get_payload(decode=True))
            # Validate file type
            if content_type not in valid_content_types:
                LOGGER.warning("Rejected invalid type: %s", content_type)
                SES_CLIENT.send_email(
                    Source=SOURCE_EMAIL,
                    Destination={"ToAddresses": [sender]},
                    Message={
                        "Subject": {"Data": "Upload Failed"},
                        "Body": {
                            "Text": {
                                "Data": f"Upload of {file_name} failed. {content_type} not supported. Only .png .jpeg .pdf and .tiff are supported"
                            }
                        },
                    },
                )
                continue
            # Validate file size
            if file_size > max_file_size and content_type.startswith("image/"):
                LOGGER.warning("Rejected large file: %s bytes", file_size)
                invalid_attachments.append(
                    {"filename": file_name, "reason": "Image size exceeds 5MB"}
                )
                continue
            # Validate file extension
            _, ext = os.path.splitext(file_name.lower())
            if ext not in valid_content_types[content_type]:
                LOGGER.warning("Extension mismatch: %s for %s", ext, content_type)
                invalid_attachments.append(
                    {"filename": file_name, "reason": "File type not supported"}
                )
                continue
            try:
                file_size = len(part.get_payload(decode=True))
                s3_path = save_attachment_to_s3(
                    DOCVAULT_BUCKET, docvault_id, part, username, file_size
                )
                valid_attachments.append(
                    {
                        "filename": part.get_filename(),
                        "s3_key": s3_path,
                        "content_type": part.get_content_type(),
                        "size": file_size,
                    }
                )
            except Exception as e:
                LOGGER.error(
                    "In IDP-Docvaults-Lambda.process_email_attachments Failed to process attachment: %s",
                    str(e),
                )
                continue
    return {
        "ValidAttachments": valid_attachments,
        "InvalidAttachments": invalid_attachments,
    }


def handle_email_ingest(record):
    """
    Handles the ingestion of an email received via AWS SES.

    This function:
    - Extracts metadata from the SES record, including the docvault ID and sender.
    - Validates the sender's access to the docvault.
    - Retrieves the raw email content from the S3 bucket.
    - Processes the email to extract attachments and classify them.
    - Deletes the original email from the S3 bucket after processing.

    Args:
        record (dict): A single SES event record containing mail and receipt information.

    Returns:
        dict: A response object with statusCode and body. If successful, body contains
              lists of valid and invalid attachments. If failed, returns appropriate error.
    """
    try:
        # Extract metadata
        ses_data = record["ses"]
        mail = ses_data["mail"]
        recipient = mail["destination"][0]
        docvault_id = recipient.split("@")[0].split("+")[1]
        sender = mail["source"]
        message_id = mail["messageId"]

        user = query_items(
            USERS_TABLE,
            index_name="Email-Index",
            key_condition_expression="Email=:e",
            expression_values={":e": sender},
        )
        user = user[0]
        username = user["Username"]

        has_access = validate_access(docvault_id, username)

        if not has_access:
            return response(403, {"Error": "Access Denied"})

        # Get email content from S3
        email_obj = S3_CLIENT.get_object(
            Bucket=DOCVAULT_BUCKET, Key=f"emails/{message_id}"
        )
        email_content = email_obj["Body"].read()

        # Process attachments
        attachments = process_email_attachments(
            email_content, docvault_id, username, sender
        )
        valid_attachments = attachments["ValidAttachments"]
        invalid_attachments = attachments["InvalidAttachments"]

        # Clean up original
        S3_CLIENT.delete_object(Bucket=DOCVAULT_BUCKET, Key=f"emails/{message_id}")

        return response(
            200,
            {
                "message": "Email processed successfully",
                "valid_attachments": valid_attachments,
                "invalid_attachments": invalid_attachments,
            },
        )
    except Exception as e:
        LOGGER.error(
            "In IDP-Docvaults-Lambda.handle_email_ingest Failed to process email: %s",
            str(e),
        )
        return response(500, e)


def validate_access(docvault_id, username):
    """
    Validates whether the given user has editor access to a specific DocVault.

    Access is granted if:
      - The user has an 'EDITOR' access type entry in the ACCESS_TABLE for the given DocVault.
      - OR the user is the creator of the DocVault.

    Args:
        docvault_id (str): The unique identifier of the DocVault.
        username (str): The username of the user requesting access.

    Returns:
        bool: True if the user has editor access or is the creator, False otherwise.
    """
    docvault_details = get_item(DOCVAULTS_TABLE, key={"DocVaultId": docvault_id})

    if not docvault_details:
        return False
    access = get_item(
        ACCESS_TABLE, key={"Username": username, "DocVaultId": docvault_id}
    )
    if (not access or access.get("AccessType") != "EDITOR") and docvault_details.get(
        "CreatedBy"
    ) != username:
        return False
    return True


def get_docvaults(event, username):
    """
    Retrieves all DocVaults created by a specific user.

    Queries the DOCVAULT_TABLE using the CreatedBy-Index to fetch all DocVault entries
    that were created by the specified user.

    Args:
        event (dict): The incoming Lambda event. Not used directly but required for interface consistency.
        username (str): The username whose DocVaults are to be retrieved.

    Returns:
        dict: A response object containing HTTP status code, headers, and the list of DocVaults in the body.
    """
    items = query_items(
        DOCVAULT_TABLE,
        index_name="CreatedBy-Index",
        key_condition_expression=Key("CreatedBy").eq(username),
    )
    LOGGER.info("items:%s", items)
    LOGGER.info("DocVaults for user %s: %s", username, items)
    return response(200, {"DocVaults": items})


def get_shared_docvaults(event, username):
    """
    Retrieves the list of docvaults shared with a specific user.

    This function queries the access control table for all DocVault IDs the user has access to,
    then fetches their corresponding details from the DocVaults table.

    Args:
        event (dict): The AWS Lambda event payload (not used directly in this function).
        username (str): The username of the user whose shared docvaults are to be retrieved.

    Returns:
        dict: An HTTP response object containing:
            - statusCode: 200
            - headers: CORS or other relevant headers
            - body: A JSON string with either the shared docvault details or a message if none exist
    """
    access_items = query_items(
        ACCESS_TABLE, key_condition_expression=Key("Username").eq(username)
    )
    LOGGER.info("Access items for user %s: %s", username, access_items)
    if not access_items:
        LOGGER.info("No shared docvaults found for user: %s", username)
        return response(200, {"message": "no shared docvaults"})
    shared_docvault_ids = [
        item["DocVaultId"] for item in access_items if "DocVaultId" in item
    ]
    shared_docvaults_details = []
    for docvault_id in shared_docvault_ids:
        docvault = get_item(DOCVAULTS_TABLE, key={"DocVaultId": docvault_id})
        if docvault:
            shared_docvaults_details.append(docvault)
        else:
            LOGGER.warning(
                "DocVault with ID %s not found in DOCVAULT_TABLE, despite access entry existing.",
                docvault_id,
            )
    LOGGER.info("Shared docvaults details: %s", shared_docvaults_details)
    return response(200, {"SharedDocVaults": shared_docvaults_details})


def create_docvault(event, username):
    """
    Creates a new DocVault for a user after validating the input.

    This function parses the request body to extract the DocVault name and optional description.
    It checks if a DocVault with the same name already exists for the user. If it doesn't exist,
    the function creates a new DocVault entry in the DynamoDB table.

    Args:
        event (dict): The Lambda event object containing the HTTP request.
        username (str): The username of the user creating the DocVault.

    Returns:
        dict: An HTTP response object with status code, headers, and body.
    """
    raw_body = event.get("body")
    if not raw_body:
        return response(400, {"Error": "Request body is missing."})

    try:
        body = json.loads(raw_body)
    except json.JSONDecodeError:
        return response(400, {"Error": "Invalid JSON format in request body."})

    docvault_name = body.get("DocVaultName")
    if (
        not docvault_name
        or not isinstance(docvault_name, str)
        or not docvault_name.strip()
    ):
        return response(
            400, {"Error": "The 'DocVaultName' field is required and cannot be empty."}
        )

    existing = query_items(
        DOCVAULT_TABLE,
        index_name="CreatedBy-Index",
        key_condition_expression=Key("CreatedBy").eq(username),
        filter_expression="DocVaultName = :dvname",
        expression_values={":dvname": docvault_name},
    )

    if existing:
        return response(409, {"message": "A DocVault with this name already exists."})
    item = {
        "DocVaultId": str(uuid.uuid4()),
        "DocVaultName": docvault_name,
        "Description": body.get("Description", ""),
        "CreatedBy": username,
        "CreatedAt": datetime.utcnow().isoformat(),
        "LastModifiedBy": username,
        "LastModifiedAt": datetime.utcnow().isoformat(),
    }
    put_item(DOCVAULT_TABLE, item=item)
    LOGGER.info("DocVault created: %s", item["DocVaultId"])
    return response(201, {"Message": "DocVault created successfully", "DocVault": item})


def get_docvault_details(event, username):
    """
    Retrieves details for a specific DocVault, including the user's access type.

    This function fetches a DocVault record based on the docvault-id in the request path.
    It verifies if the user is the owner or has access via the Access table, and returns
    the appropriate access type.

    Args:
        event (dict): The Lambda event object, which must contain 'pathParameters' with 'docvault-id'.
        username (str): The username of the currently authenticated user.

    Returns:
        dict: A response object with status code, headers, and body containing either:
              - The DocVault details with an added 'AccessType' key, or
              - An error message with appropriate HTTP status code.
    """
    docvault_id = event["pathParameters"].get("docvault-id")
    if not docvault_id:
        LOGGER.warning("Missing docvault-id in path parameters.")
        return response(400, {"Error": "DocVault ID is missing from the request path."})

    item = get_item(DOCVAULTS_TABLE, key={"DocVaultId": docvault_id})

    if not item:
        return response(404, {"Error": "DocVault not found."})

    if item.get("CreatedBy") == username:
        item["AccessType"] = "OWNER"
    else:
        access_item = get_item(
            ACCESS_TABLE, key={"Username": username, "DocVaultId": docvault_id}
        )
        if not access_item:
            return response(
                403, {"Error": "You do not have permission to access this DocVault."}
            )
        # Set the specific access type (e.g., 'viewer', 'editor') from the access table
        item["AccessType"] = access_item.get("AccessType", "UNKNOWN")

    return response(200, item)


def delete_docvault(event, username):
    """Deletes a DocVault and all associated files and access records."""
    docvault_id = event["pathParameters"]["docvault-id"]
    docvault = get_item(DOCVAULTS_TABLE, {"DocVaultId": docvault_id})

    if not docvault or docvault.get("CreatedBy") != username:
        return response(403, {"Error": "You are not authorized to delete this DocVault."})

    # Delete associated items from other tables one by one
    for table_name, pk_name, sk_name in [
        (FILES_TABLE, "DocVaultId", "FileName"),
        (EXTRACTED_FILES_TABLE, "DocVaultId", "ExtractedFileName"),
    ]:
        items_to_delete = query_items(table_name, key_condition_expression=Key(pk_name).eq(docvault_id))
        if items_to_delete:
            for item in items_to_delete:
                key_to_delete = {pk_name: item[pk_name], sk_name: item[sk_name]}
                delete_item(table_name, key_to_delete)

    access_items = query_items(ACCESS_TABLE, index_name=ACCESS_TABLE_DOCVAULT_INDEX, key_condition_expression=Key("DocVaultId").eq(docvault_id))
    if access_items:
        for item in access_items:
            key_to_delete = {"Username": item["Username"], "DocVaultId": item["DocVaultId"]}
            delete_item(ACCESS_TABLE, key_to_delete)
        
    # Delete S3 folder (optional, can be done via lifecycle policies)

    # Finally, delete the docvault item
    delete_item(DOCVAULTS_TABLE, {"DocVaultId": docvault_id})
    
    return response(200, {"Message": "DocVault deleted successfully."})

def lambda_handler(event, context):
    """
    AWS Lambda handler function to process different types of events including:
    - S3 event notifications for object creation (for ingestion to DynamoDB)
    - SES email events (for email ingestion)
    - SQS events (for asynchronous processing)
    - API Gateway events (for handling REST API logic)

    Args:
        event (dict): The event data passed by the invoking service (e.g., S3, API Gateway, SQS, SES).
        context (object): The runtime context which contains metadata about the invocation, function, and execution environment.

    Returns:
        dict: A response object containing HTTP status code and a JSON-formatted body.
    """
    try:
        LOGGER.info("Event: %s", event)

        if (
            "Records" in event
            and event.get("Records")[0].get("eventSource") == "aws:s3"
        ):
            record = event["Records"][0]
            if not record.get("s3", {}).get("object", {}).get("key"):
                return response(400, {"Error": "Missing S3 object in event"})
            LOGGER.info("In IDP-Docvaults-Lambda.lambda_handler triggered by s3")

            if record.get("eventName") in [
                "ObjectCreated:Put",
                "ObjectCreated:CompleteMultipartUpload",
            ]:
                LOGGER.info(
                    "In IDP-Docvaults-Lambda.lambda_handler adding details to dynamodb..."
                )
                try:
                    return update_upload_status(record)
                except Exception as e:
                    LOGGER.error(
                        "In IDP-Docvaults-Lambda.lambda_handler.s3_event_notification_trigger failed with Error: %s",
                        str(e),
                    )
            return response(
                400,
                {
                    "Response": {
                        "message": "could not add details to DB",
                        "record": record,
                    }
                },
            )
        elif "Records" in event and event["Records"][0].get("eventSource") == "aws:ses":
            return handle_email_ingest(event["Records"][0])
        elif "Records" in event and event["Records"][0].get("eventSource") == "aws:sqs":
            LOGGER.info("Triggered by sqs")
            records = event["Records"]
            return handle_sqs(records)
        else:
            if (
                not event.get("requestContext", {})
                .get("authorizer", {})
                .get("claims", {})
            ):
                return response(401, {"Error": "Token not provided"})

            token_details = event["requestContext"]["authorizer"]["claims"]

            if not token_details:
                return response(401, {"Error": "Token not provided"})

            # Validate required claims
            required_claims = [
                "cognito:username",
                "email",
                "email_verified",
                "preferred_username",
            ]
            missing_claims = [
                claim for claim in required_claims if claim not in token_details
            ]
            if missing_claims:
                return response(
                    400,
                    {"Error": f"Missing required claims: {', '.join(missing_claims)}"},
                )

            # Validate email verification
            if token_details.get("email_verified") != "true":
                return response(403, {"Error": "Email not verified"})

            user_details = {
                "username": token_details.get("preferred_username"),
                "email": token_details.get("email"),
                "email_verified": token_details.get("email_verified"),
            }

            user = get_item(
                USERS_TABLE, key={"Username": user_details["username"]}
            )

            if not user:
                return response(401, {"Error": "User not found"})

            if not "httpMethod" in event or not "resource" in event:
                return response(400, {"Error": "Invalid request structure"})

            http_method = event.get("httpMethod", "")
            resource = event.get("resource")
            username = user_details.get("username")
            LOGGER.info("username:%s", username)
            if resource == "/docvaults":
                if http_method == "GET":
                    query_params = event.get("queryStringParameters", {})
                    LOGGER.info("getting docvaults")
                    if query_params and "type" in query_params:
                        doc_type = query_params.get("type")
                        if doc_type == "shared":
                            LOGGER.info("getting shared docvaults")
                            return get_shared_docvaults(event, username)
                        else:
                            return response(
                                400,
                                {
                                    "Error": "Invalid 'type' parameter. Must be 'shared' if present."
                                },
                            )
                    else:
                        LOGGER.info("getting my docvaults")
                        return get_docvaults(event, username)
                elif http_method == "POST":
                    return create_docvault(event, username)
            elif resource == "/docvaults/{docvault-id}":
                query_params = event.get("queryStringParameters", {})
                path_params = event.get("pathParameters", {})
                docvault_id = path_params.get("docvault-id", "")
                if http_method == "POST":
                    body = json.loads(event.get("body", {}))

                    if not docvault_id:
                        return response(400, {"Error": "Docvault Id not provided"})

                    has_access = validate_access(docvault_id, username)

                    if not has_access:
                        return response(401, {"Error": "Access Denied"})
                    if not query_params:
                        files = body.get("Files")
                        if not files:
                            return response(400, {"Error": "Files not provided"})
                        return handle_ui_upload(docvault_id, files, user_details)
                    elif query_params.get("source") == "google-drive":
                        google_file_ids = body.get("GoogleFileIds", [])
                        if not google_file_ids:
                            return response(
                                400, {"Error": "Google File Id not provided"}
                            )
                        # LOGGER.info(f"user details: {user_details}")
                        return handle_google_drive_upload(
                            docvault_id, google_file_ids, user_details
                        )
                    else:
                        return response(400, {"error": "invalid source specified"})
                elif http_method == "GET":
                    return get_docvault_details(event, username)
                elif http_method == "DELETE":
                    return delete_docvault(event, username)
            elif resource == "/auth/google/code":
                return handle_google_auth(user_details)
            elif resource == "/auth/google/exchange":
                query_params = event.get("queryStringParameters", {})
                code = query_params.get("code")
                if not code:
                    return response(400, {"Error": "Code not provided"})
                return code_token_exhange(code, user_details)
            elif resource == "/docvaults/{docvault-id}/shared-users":
                path_parameters = event.get("pathParameters")
                if not path_parameters:
                    LOGGER.error(
                        "In IDP-DocVaults-Lambda.lambda_handler, Path parameter must be provided."
                    )
                    return response(400, {"Error": "Path parameter must be provided"})

                # checking if docvaultid is provided
                if path_parameters.get("docvault-id") is None:
                    return response(400, {"Error": "Docvault id must be provided"})
                docvault_id = event["pathParameters"]["docvault-id"]
                # checking if docvaultid is valid
                docvault_item = None
                try:
                    docvault_item = get_item(
                        DOCVAULT_TABLE, {"DocVaultId": docvault_id}
                    )
                    if docvault_item is None:
                        return response(
                            400, {"Error": "Invalid docvaultid is provided"}
                        )
                    # checking if user is the owner of the docvault
                    if docvault_item.get("CreatedBy") != username:
                        return response(
                            400,
                            {
                                "Error": "You are not authorised to perform this action as you are not the owner of this docvault"
                            },
                        )
                except Exception as e:
                    logging.error(f"Error in getting item from docvault table:{e}")
                    return response(
                        500, {"Error": "Error in getting item from docvault table"}
                    )

                docvault_name = docvault_item.get("DocVaultName")
                if event["httpMethod"] == "GET":
                    resp = list_shared_users(event, docvault_id)
                    LOGGER.info(
                        "In IDP-DocVaults-Lambda.lambda_handler, List shared users response: %s",
                        resp,
                    )
                    return resp
                elif event["httpMethod"] == "PUT":
                    return manage_share(event, username, docvault_id, docvault_name)
                else:
                    return response(400, {"Error": "Invalid method"})
            else:
                return response(400, {"Error": "Invalid Request"})

    except Exception as e:
        LOGGER.error(
            "In IDP-Docvaults-Lambda.lambda_handler failed with Error: %s", str(e)
        )
        return response(500, e)
