import io
import os
import re
import cv2
import json
import fitz
import time
import boto3
import base64
import asyncio
import logging
import inspect
import mimetypes
import numpy as np
from PIL import Image
from datetime import datetime
from typing import Any, Optional
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Attr, Key

# Setting up the logger
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

# Initialize boto3 clients
bedrock = boto3.client(service_name="bedrock-runtime", region_name="us-east-1")
s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
step_function = boto3.client("stepfunctions", region_name="us-east-1")

CURRENT_FUNC_NAME = lambda: inspect.stack()[1][3]

LAMBDA_NAME = None

# Centralized Configuration
class AppConfig:
    """
        Centralized Application Configuration.
        Holds all the environment variables and other important configurations.
    """

    # S3 and File Processing Settings
    DOCVAULTS_BUCKET = os.environ["DOCVAULTS_BUCKET"]
    ORIGINAL_FILE_KEY = "original/{}/{}" # original/DocVaultId/filename
    MODEL_OUTPUT_KEY = "intermediate/{}/model/{}" # extract/DocVaultId/model/FileName
    BDA_OUTPUT_KEY = "intermediate/{}/bda/{}" # extract/DocVaultId/bda/FileName
    FINAL_OUTPUT_KEY = "final-extracted/{}/{}" # final-extracted/DocVaultId/FileName

    CLASSIFICATION_BUCKET = os.environ["CLASSIFICATION_BUCKET"]
    SCHEMA_PREFIX = "schemas/"

    INTER_BUCKET = os.environ["INTERMEDIATE_BUCKET"]

    # Dynamo DB Settings
    ACCESS_TABLE = os.environ["ACCESS_TABLE"]
    CLASSIFICATIONS_TABLE = os.environ["CLASSIFICATIONS_TABLE"]
    DOCVAULTS_TABLE = os.environ["DOCVAULTS_TABLE"]
    FILES_TABLE = os.environ["FILES_TABLE"]
    EXTRACTED_FILES_TABLE = os.environ["EXTRACTED_FILES_TABLE"]

    # Image Processing Settings
    DEFAULT_DPI = 300
    IMAGE_MAX_SIZE: tuple[int, int] = (1024, 1024)
    IMAGE_QUALITY = 90

    # Bedrock Extraction Settings
    EXTRACTION_MODEL_ID = "us.mistral.pixtral-large-2502-v1:0"
    EXTRACTION_MAX_TOKENS = 4000
    EXTRACTION_CHUNK_SIZE = 3  # Number of pages to process at once

    # Bedrock Analysis & Classification Settings
    ANALYSIS_MODEL_ID = "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
    ANALYSIS_MAX_TOKENS = 4000
    ANALYSIS_TEMPERATURE = 0.0
    CLASSIFICATION_PAGE_LIMIT = 2
    
    # Chunking Settings
    MARKDOWN_MAX_CHUNK_SIZE = 2000
    MARKDOWN_OVERLAP_SIZE = 200
    MARKDOWN_MIN_CHUNK_SIZE = 100

    # Bedrock Data Automation Settings
    DATA_AUTOMATION_PROFILE = "arn:aws:bedrock:us-east-1:043309350924:data-automation-profile/us.data-automation-v1"
    MAX_WAIT_TIME = 600

    # Step Function ARN
    EFP_STEP_FUNCTION_ARN = os.environ["EFP_STEP_FUNCTION_ARN"]

    # Caller Settings
    USER = None

    # CORS Headers
    CORS_HEADERS = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With",
        "Access-Control-Allow-Credentials": "true",
        "Content-Type": "application/json"
    } 


class DocumentToMarkdownConverter:
    """
        Handles the conversion of a source document(PDF or Image) into markdown text.

        Encapsulates the entire process, including file type detection, image preprocessing and enhancement, PDF page-to-image conversion,
        and interaction with a multimodal AI model (via Bedrock) to perform the final text extraction into markdown format.
    """

    def __init__(self):
        """
            Initializes the converter and the Bedrock runtime client.
        """
        self.bedrock = bedrock

    def get_file_type(self, key: str) -> str:
        """
            Determines the file type ('pdf', 'image', or 'unknown') from its key or filename.

            It first attempts to guess the MIME type and falls back to checking the
            file extension.

            Args:
                key (str): The S3 object key or filename.

            Returns:
                str: The determined file type as a string.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        mime_type, _ = mimetypes.guess_type(key)
        if mime_type:
            if mime_type.startswith("image/"):
                return "image"
            elif mime_type == "application/pdf":
                return "pdf"

        try:
            extension = key.lower().split('.')[-1]
            if extension in ["jpg", "jpeg", "png", "tiff"]:
                return "image"
            elif extension == "pdf":
                return "pdf"
        except IndexError:
            # Handles cases where the key has no '.'
            return "unknown"

        return "unknown"

    def _resize_image_from_bytes(self, image_data: bytes) -> str:
        """
            Resizes an image from byte data to a configured max size and returns it as a base64 string.

            The image is converted to RGB, a thumbnail is generated preserving the aspect
            ratio, and it's saved as a high-quality JPEG.

            Args:
                image_data (bytes): The raw byte content of the image.

            Returns:
                str: A base64 encoded string representation of the resized JPEG image.
        """
        
        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        img = Image.open(io.BytesIO(image_data))
        if img.mode != "RGB":
            img = img.convert("RGB")
        
        img.thumbnail(AppConfig.IMAGE_MAX_SIZE, Image.Resampling.LANCZOS)
        
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format="JPEG", quality=AppConfig.IMAGE_QUALITY, optimize=True)
        
        return base64.b64encode(img_byte_arr.getvalue()).decode("utf-8")

    def _enhance_image(self, image_data: bytes) -> bytes:
        """
            Applies image enhancements like contrast adjustment to improve OCR quality.

            This method uses OpenCV to decode the image, applies Contrast Limited
            Adaptive Histogram Equalization (CLAHE) to the luminance channel to
            improve local contrast, and then re-encodes the image.

            Args:
                image_data (bytes): The raw byte content of the image.

            Returns:
                bytes: The byte content of the enhanced image. Returns original data on failure.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        # 1. Decode image data into an OpenCV object
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            # If decoding fails, return original data
            return image_data

        # 2. Enhance Contrast using CLAHE (applied to the luminance channel)
        # Convert to LAB color space, apply CLAHE to L-channel, then convert back
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l_channel, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        cl = clahe.apply(l_channel)
        limg = cv2.merge((cl, a, b))
        enhanced_img = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)

        # 3. Encode the enhanced image back to bytes
        is_success, buffer = cv2.imencode(".png", enhanced_img)
        if not is_success:
            return image_data # Return original on failure
        
        return buffer.tobytes()

    def _pdf_to_images(self, pdf_data: bytes) -> list[str]:
        """
            Converts each page of a PDF from byte data into a list of base64 encoded images.

            Each page is rendered at a configured DPI, enhanced, resized, and then
            base64 encoded.

            Args:
                pdf_data (bytes): The raw byte content of the PDF file.

            Returns:
                list[str]: A list where each item is a base64 encoded string of a page image.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        images = []
        pdf_document = fitz.open(stream=pdf_data, filetype="pdf")
        
        try:
            for page_num in range(len(pdf_document)):
                page = pdf_document[page_num]
                mat = fitz.Matrix(AppConfig.DEFAULT_DPI / 72, AppConfig.DEFAULT_DPI / 72)
                pix = page.get_pixmap(matrix=mat)
                img_data = pix.tobytes("png")
                
                enhanced_img_data = self._enhance_image(img_data)
                
                resized_image = self._resize_image_from_bytes(enhanced_img_data)
                images.append(resized_image)
        finally:
            pdf_document.close()
        
        return images
    
    def _create_bedrock_message(self, images: list[str], prompt: str) -> dict[str, Any]:
        """
            Constructs the JSON payload for a Bedrock multimodal model request.

            Args:
                images (list[str]): A list of base64 encoded page images.
                prompt (str): The text prompt to guide the model's extraction.

            Returns:
                dict[str, Any]: The complete request body for the Bedrock API call.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        content = [{"text": prompt, "type": "text"}]
        for image_b64 in images:
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"}
            })
        
        return {
            "messages": [{"role": "user", "content": content}],
            "max_tokens": AppConfig.EXTRACTION_MAX_TOKENS
        }

    def convert(self, file_data: bytes, file_type: str) -> str:
        """
            Converts a full document (PDF or image) into a single markdown string.

            This is the main public method of the class. It handles the full pipeline:
            1. Converts the input file data into one or more page images.
            2. Chunks the pages for processing to fit model context limits.
            3. Invokes a multimodal Bedrock model for each chunk.
            4. Combines the markdown results from all chunks into a final string.

            Args:
                file_data (bytes): The raw byte content of the file.
                file_type (str): The type of file ('pdf' or 'image').

            Returns:
                str: A single string containing the extracted markdown content for the entire document.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        if file_type == 'pdf':
            images = self._pdf_to_images(file_data)
        else:
            enhanced_img_data = self._enhance_image(file_data)
            images = [self._resize_image_from_bytes(file_data)]
        
        print(f"Converted document to {len(images)} image(s).")

        all_results = []
        total_pages = len(images)
        chunk_size = AppConfig.EXTRACTION_CHUNK_SIZE

        for i in range(0, len(images), chunk_size):
            chunk = images[i:i+chunk_size]
            start_page, end_page = i + 1, min(i + chunk_size, total_pages)
            
            print(f"Processing pages {start_page}-{end_page} of {total_pages} for markdown extraction.")
            
            if file_type == "pdf":
                prompt = (f"Extract and return all text from page {start_page} of this {total_pages}-page PDF document as markdown." 
                          if len(chunk) == 1 else 
                          f"Extract all text from pages {start_page}-{end_page} of this {total_pages}-page PDF. Maintain structure and indicate page breaks.")
            else:
                prompt = "Extract and return all text from this image as markdown."
            
            request_body = self._create_bedrock_message(chunk, prompt)
            
            try:
                response = self.bedrock.invoke_model(
                    modelId=AppConfig.EXTRACTION_MODEL_ID,
                    contentType="application/json",
                    body=json.dumps(request_body)
                )
                response_body = json.loads(response.get("body").read())
                
                content = ""
                if "choices" in response_body and response_body["choices"]:
                    message = response_body["choices"][0].get("message", {})
                    content = message.get("content", "")
                else:
                    content = str(response_body)

                all_results.append({"pages": f"{start_page}-{end_page}", "content": content})
                
            except ClientError as e:
                error_message = f"Bedrock API error on chunk {start_page}-{end_page}: {e.response['Error']['Message']}"
                print(error_message)
                all_results.append({"pages": f"{start_page}-{end_page}", "error": error_message})
            except Exception as e:
                error_message = f"An unexpected error occurred on chunk {start_page}-{end_page}: {str(e)}"
                print(error_message)
                all_results.append({"pages": f"{start_page}-{end_page}", "error": error_message})

        combined_content = "\n\n".join(
            f"--- Pages {result['pages']} ---\n{result['content']}" if "content" in result 
            else f"--- Pages {result['pages']} (ERROR) ---\n{result['error']}" 
            for result in all_results
        )
        
        return combined_content.strip()

class MarkdownProcessor:
    """
        Handles the processing of large markdown texts, primarily by splitting them into smaller, context-aware chunks.

        This class is designed to break down a single large markdown document into
        manageable pieces that can be fed into a language model, ensuring that
        semantically related content (like sections under a specific heading) is
        kept together as much as possible.
    """
    
    def __init__(self):
        """
            Initializes the MarkdownProcessor with chunking parameters from the application configuration.
        """

        self.max_chunk_size = AppConfig.MARKDOWN_MAX_CHUNK_SIZE
        self.overlap_size = AppConfig.MARKDOWN_OVERLAP_SIZE

    def create_contextual_chunks(self, text: str) -> list[dict[str, Any]]:
        """
            Creates context-aware chunks from a markdown string.

            This method splits the text by markdown headings (`#`, `##`, etc.) and
            groups these sections into chunks that are close to the maximum size limit.
            It adds a configurable overlap between chunks to help maintain context
            across boundaries.

            Args:
                text (str): The raw markdown text to be chunked.

            Returns:
                list[dict[str, Any]]: A list of chunk objects, where each object
                                    contains the content and some metadata.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        chunks = []
        current_chunk_content = ""
        
        sections = re.split(r'(^#+\s.*$)', text, flags=re.MULTILINE)
        
        if sections[0]:
             current_chunk_content += sections[0]

        for i in range(1, len(sections), 2):
            header = sections[i]
            content = sections[i+1]
            section_text = header + content

            if len(current_chunk_content) + len(section_text) > self.max_chunk_size and current_chunk_content:
                chunks.append(self._create_chunk_obj(current_chunk_content))
                overlap = current_chunk_content[-self.overlap_size:]
                current_chunk_content = overlap + section_text
            else:
                current_chunk_content += section_text
        
        if current_chunk_content:
            chunks.append(self._create_chunk_obj(current_chunk_content))
            
        return chunks

    def _create_chunk_obj(self, content: str) -> dict[str, Any]:
        """
            A helper method to create a standardized dictionary for a chunk.

            Args:
                content (str): The text content of the chunk.

            Returns:
                dict[str, Any]: A dictionary containing the chunk's content and metadata.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        return {
            'content': content,
            'metadata': { 'char_count': len(content) }
        }

class DocumentClassifier:
    """
        Classifies a document and creates tailored prompts for data extraction.

        This class interacts with multimodal AI models to determine a document's type
        (e.g., "Invoice", "Receipt") based on its visual content. It then uses this
        classification to fetch a corresponding data schema from DynamoDB/S3 and
        dynamically constructs a precise prompt to guide the AI in extracting
        structured data from the document.
    """

    def __init__(self):
        """
            Initializes the DocumentClassifier with a Bedrock runtime client.
        """
        self.bedrock = bedrock 

    def _invoke_multimodal_claude(self, images: list[str], prompt: str, system_prompt: str) -> str:
        """
            Invokes a multimodal Claude model on Bedrock with text and image inputs.

            Args:
                images (List[str]): A list of base64 encoded image strings.
                prompt (str): The user prompt to send to the model.
                system_prompt (str): The system prompt to guide the model's behavior.

            Returns:
                str: The text response from the model. Returns an empty string on failure.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        content = [{"type": "text", "text": prompt}]
        for image_b64 in images:
            content.append({
                "type": "image",
                "source": {"type": "base64", "media_type": "image/jpeg", "data": image_b64}
            })

        messages = [{"role": "user", "content": content}]
        
        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": AppConfig.ANALYSIS_MAX_TOKENS,
            "temperature": AppConfig.ANALYSIS_TEMPERATURE,
            "system": system_prompt,
            "messages": messages
        }
        try:
            response = self.bedrock.invoke_model(
                modelId=AppConfig.ANALYSIS_MODEL_ID,
                body=json.dumps(request_body)
            )
            response_body = json.loads(response['body'].read())
            return response_body['content'][0]['text']
        except ClientError as e:
            print(f"Claude multimodal invocation failed: {e}")
            return ""

    def _get_classifications_from_table(self) -> dict[str, str]:
        """
            Fetches available document classifications and their schema locations from DynamoDB.

            The query retrieves all items where the 'CreatedBy' attribute is either
            'System' or matches the currently configured username, handling pagination.

            Returns:
                dict[str, str]: A dictionary mapping classification names to their S3 schema locations.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        try:
            table = dynamodb.Table(AppConfig.CLASSIFICATIONS_TABLE)
            
            filter_expression = Attr('CreatedBy').eq('System') | Attr('CreatedBy').eq(AppConfig.USER)
            
            response = table.scan(
                FilterExpression=filter_expression,
                ProjectionExpression="ClassificationName, SchemaS3Location"
            )

            classifications = [
                (item['ClassificationName'], item["SchemaS3Location"]) 
                for item in response.get('Items', [])
                if item and "ClassificationName" in item and "SchemaS3Location" in item
            ]
            
            # Handle paginated results if the table is large
            while 'LastEvaluatedKey' in response:
                response = table.scan(
                    FilterExpression=filter_expression,
                    ProjectionExpression="ClassificationName, SchemaS3Location",
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                classifications.extend([
                (item['ClassificationName'], item["SchemaS3Location"]) 
                for item in response.get('Items', [])
                if item and "ClassificationName" in item and "SchemaS3Location" in item
            ])
                
            print(f"Successfully fetched {len(classifications)} classifications for user '{AppConfig.USER}'.")
            return {classification: schema for classification, schema in classifications}

        except ClientError as e:
            print(f"Error fetching classifications from DynamoDB: {e}")
            raise e
            return {}

    def classify_document(self, images: list[str]) -> dict[str, Any]:
        """
            Classifies a document based on its page images using a multimodal AI model.

            It uses a subset of the document's pages for efficiency and prompts the model
            to categorize the document based on a predefined list or provide a general
            "Auto" classification.

            Args:
                images (list[str]): A list of base64 encoded images of the document's pages.

            Returns:
                dict[str, Any]: A dictionary containing the 'classification' and 'confidence'.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        system_prompt = "You are an expert document classifier. Your job is to determine the document type from the provided image(s)."
        classifications = self._get_classifications_from_table()

        print(f"Classifications: {classifications}")
        
        user_prompt = f"""
        Analyze the following document image(s) and classify the document.
        First, determine if the document belongs to one of the following predefined categories: [{", ".join(classifications.keys())}].
        If it does, classify it as such. If it does not fit, classify it as 'Auto' and provide a brief, one-or-two-word description (e.g., 'Contract', 'Report').
        
        Respond ONLY with a single JSON object with two keys:
        1. "classification": The name of the category (e.g., "Invoice", "Auto - Report").
        2. "confidence": A float from 0.0 to 1.0 indicating your confidence.
        """

        # Use only the first few pages for classification to be efficient
        image_subset_for_classification = images[:AppConfig.CLASSIFICATION_PAGE_LIMIT]

        response_text = self._invoke_multimodal_claude(
            image_subset_for_classification, user_prompt, system_prompt
        )
        try:
            # Assuming DocumentChunkConsolidator is available or its method is accessible
            return DocumentChunkConsolidator().extract_json_from_response(response_text)
        except (json.JSONDecodeError, KeyError) as e:
            print(f"Failed to parse classification response: {e}\nResponse: {response_text}")
            return {"classification": "Unknown", "confidence": 0.0}

    def _transform_schema_for_prompt(self, schema):
        """
            Recursively transforms a descriptive schema into a fillable JSON template structure.

            This function prepares the schema to be used as a template in the extraction
            prompt, converting final field values into `{"value": "...", "confidence": "..."}` objects.

            Args:
                schema (dict): The descriptive schema with nested objects and string values.

            Returns:
                dict: The transformed schema ready for inclusion in a prompt.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        output_schema = {}
        for key, value in schema.items():
            if isinstance(value, dict):
                # Recurse for nested objects like ACCOUNT_SUMMARY
                output_schema[key] = self._transform_schema_for_prompt(value)
            else:
                # For a final field, create the {"value": "...", "confidence": ...} structure
                output_schema[key] = {
                    "value": "...",
                    "confidence": "..."
                }
        return output_schema

    def create_extraction_prompt(self, classification: str) -> tuple[str, str]:
        """
            Creates a tailored user and system prompt for data extraction based on classification.

            If a schema exists for the given classification, it constructs a detailed,
            rule-based prompt with a JSON template for the model to fill. If no schema is found,
            it generates a generic key-value pair extraction prompt.

            Args:
                classification (str): The classification of the document (e.g., "Invoice").

            Returns:
                tuple[str, str]: A tuple containing the user prompt template and the system prompt.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        base_classification = classification.split(' - ')[0]

        system_prompt = (
            "You are a precise, rule-following data extraction engine. Your only job is to return a JSON object that "
            "perfectly matches the schema and rules provided. Do not add explanations or any text outside of the JSON."
        )
        
        # --- CHANGE: We need to fetch the full list again to check if the classified document is a custom or system one ---
        classifications = self._get_classifications_from_table()
        if base_classification in classifications:
            schema_key = classifications[base_classification]
            try:
                response = s3.get_object(Bucket=AppConfig.CLASSIFICATION_BUCKET, Key=schema_key)
                descriptive_schema = json.loads(response["Body"].read())

                # --- KEY CHANGE: Transform the schema into a fillable template ---
                output_template_schema = self._transform_schema_for_prompt(descriptive_schema)
                schema_str = json.dumps(output_template_schema, indent=2)

                print(schema_str)
                
                user_prompt_template = f"""
                Your task is to extract information from the document chunk and use it to fill in the JSON template below.
                
                <rules>
                1.  Your output MUST be a single, valid JSON object that uses the exact structure of the provided template.
                2.  Preserve the exact key names and casing (e.g., `ACCOUNT_HOLDER_NAME`).
                3.  For each field, provide the extracted 'value' and a 'confidence' score between 0.0 and 1.0.
                4.  For repeating line items like TRANSACTION_DETAILS, create a JSON array where each row becomes an object.
                5.  **For any field ending in '_DATE', you MUST reformat the extracted value into a strict `YYYY-MM-DD` format.**
                6.  **Extract the literal text found for each field. If a value appears to be a placeholder (e.g., 'Name'), extract that placeholder text. Only omit the key if the value is completely blank.**
                7.  DO NOT add any fields that are not present in the template.
                </rules>
                
                <example>
                <document_chunk>
                Service Receipt for Jane Doe. ID: XYZ-789.
                Item: Annual Support, Date: 15 Jul 2025, Amount: 250.00
                Item: Anual Team Cost, Date: 16 Jul 2025, Amount: 25000.00
                </document_chunk>
                <json_output>
                {{
                  "CUSTOMER_NAME": {{
                    "value": "Jane Doe",
                    "confidence": 0.99
                  }},
                  "DOCUMENT_ID": {{
                    "value": "XYZ-789",
                    "confidence": 0.98
                  }},
                  "LINE_ITEMS": [
                    {{
                      "ITEM_DATE": {{
                        "value": "2025-07-15",
                        "confidence": 0.99
                      }},
                      "ITEM_DESCRIPTION": {{
                        "value": "Annual Support",
                        "confidence": 0.97
                      }},
                      "ITEM_AMOUNT": {{
                        "value": 250.00,
                        "confidence": 0.99
                      }}
                    }},
                    {{
                      "ITEM_DATE": {{
                        "value": "2025-07-16",
                        "confidence": 0.9
                      }},
                      "ITEM_DESCRIPTION": {{
                        "value": "Annual Team Costs",
                        "confidence": 0.83
                      }},
                      "ITEM_AMOUNT": {{
                        "value": 25000.00,
                        "confidence": 1.0
                      }}
                    }}
                  ]
                }}
                </json_output>
                </example>
                
                <json_template_to_fill>
                ```json
                {schema_str}
                
                DOCUMENT CHUNK:
                ---
                {{content}}
                ---
                """
                return (user_prompt_template.replace('{', '{{').replace('}', '}}').replace('{{content}}', '{content}'), system_prompt)

            except ClientError as e:
                print(f"Schema not found for {classification}. Defaulting to generic extraction. Error: {e}")
        
        user_prompt_template = f"""
        Analyze the document chunk, which has been auto-classified as '{classification}'.
        Extract all important key-value pairs from the text.
        For each value, provide a confidence score from 0.0 to 1.0.
        The output must be a single, valid JSON object where each key's value is another object containing "value" and "confidence".
        If a value is not found, omit the key.
        
        Document Chunk Content:
        ---
        {{content}}
        ---
        """
        return (user_prompt_template.replace('{', '{{').replace('}', '}}').replace('{{content}}', '{content}'), system_prompt)
    
    def create_direct_image_extraction_prompt(self, classification: str) -> tuple[str, str]:
        """
            Creates a prompt for extracting data directly from a single image.

            This method reuses the logic from `create_extraction_prompt` but tailors the
            final user prompt for direct image analysis by removing references to a "document chunk".

            Args:
                classification (str): The classification of the document.

            Returns:
                tuple[str, str]: A tuple containing the user prompt and the system prompt.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        base_classification = classification.split(' - ')[0]
        system_prompt = (
            "You are a precise, rule-following data extraction engine. Your only job is to return a JSON object that "
            "perfectly matches the schema and rules provided. Do not add explanations or any text outside of the JSON."
        )
        classifications = self._get_classifications_from_table()
        
        if base_classification in classifications:
            schema_key = classifications[base_classification]
            try:
                response = s3.get_object(Bucket=AppConfig.CLASSIFICATION_BUCKET, Key=schema_key)
                descriptive_schema = json.loads(response["Body"].read())
                output_template_schema = self._transform_schema_for_prompt(descriptive_schema) # Assuming transform is a method of this class now
                schema_str = json.dumps(output_template_schema, indent=2)
                
                # --- PROMPT CHANGE: Tailored for direct image analysis ---
                user_prompt = f"""
                Your task is to extract information from the document chunk and use it to fill in the JSON template below.
                
                <rules>
                1.  Your output MUST be a single, valid JSON object that uses the exact structure of the provided template.
                2.  Preserve the exact key names and casing (e.g., `ACCOUNT_HOLDER_NAME`).
                3.  For each field, provide the extracted 'value' and a 'confidence' score between 0.0 and 1.0.
                4.  For repeating line items like TRANSACTION_DETAILS, create a JSON array where each row becomes an object.
                5.  **For any field ending in '_DATE', you MUST reformat the extracted value into a strict `YYYY-MM-DD` format.**
                6.  **Extract the literal text found for each field. If a value appears to be a placeholder (e.g., 'XXXXX'), extract that placeholder text. Only omit the key if the value is completely blank.**
                7.  DO NOT add any fields that are not present in the template.
                </rules>
                
                <example>
                <document_chunk>
                Service Receipt for Jane Doe. ID: XYZ-789.
                Item: Annual Support, Date: 15 Jul 2025, Amount: 250.00
                Item: Anual Team Cost, Date: 16 Jul 2025, Amount: 25000.00
                </document_chunk>
                <json_output>
                {{
                  "CUSTOMER_NAME": {{
                    "value": "Jane Doe",
                    "confidence": 0.99
                  }},
                  "DOCUMENT_ID": {{
                    "value": "XYZ-789",
                    "confidence": 0.98
                  }},
                  "LINE_ITEMS": [
                    {{
                      "ITEM_DATE": {{
                        "value": "2025-07-15",
                        "confidence": 0.99
                      }},
                      "ITEM_DESCRIPTION": {{
                        "value": "Annual Support",
                        "confidence": 0.97
                      }},
                      "ITEM_AMOUNT": {{
                        "value": 250.00,
                        "confidence": 0.99
                      }}
                    }},
                    {{
                      "ITEM_DATE": {{
                        "value": "2025-07-16",
                        "confidence": 0.9
                      }},
                      "ITEM_DESCRIPTION": {{
                        "value": "Annual Team Costs",
                        "confidence": 0.83
                      }},
                      "ITEM_AMOUNT": {{
                        "value": 25000.00,
                        "confidence": 1.0
                      }}
                    }}
                  ]
                }}
                </json_output>
                </example>
                
                <json_template_to_fill>
                ```json
                {schema_str}
                ```
                </json_template_to_fill>
                """
                return (user_prompt, system_prompt)

            except ClientError as e:
                print(f"Schema not found for {classification}. Error: {e}")
        
        return ("Extract all key-value pairs from the image.", system_prompt)


class BedrockLLMProcessor:
    """
        Handles asynchronous interaction with AWS Bedrock language models.

        This class provides methods to invoke language models for both text-only
        and multimodal (text + image) tasks. It is designed for efficiency by
        processing multiple text chunks in parallel using asyncio.
    """

    def __init__(self):
        """Initializes the processor with an asynchronous Bedrock runtime client."""
        self.bedrock_async = boto3.client('bedrock-runtime', region_name="us-east-1")

    async def _invoke_model_async(self, formatted_prompt: str, system_prompt: str) -> dict[str, Any]:
        """
            A private coroutine to invoke a Bedrock model asynchronously with a given text prompt.

            This method constructs the request payload for a text-based model and uses
            an executor to run the synchronous boto3 call in a non-blocking manner.

            Args:
                formatted_prompt (str): The user prompt to send to the model.
                system_prompt (str): The system prompt to guide the model's behavior.

            Returns:
                dict[str, Any]: A dictionary containing the model's 'response' and a
                                'success' boolean, or an 'error' message.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        messages = [{"role": "user", "content": formatted_prompt}]
        
        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": AppConfig.ANALYSIS_MAX_TOKENS,
            "temperature": AppConfig.ANALYSIS_TEMPERATURE,
            "system": system_prompt,
            "messages": messages
        }
        try:
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,  
                lambda: self.bedrock_async.invoke_model(
                    modelId=AppConfig.ANALYSIS_MODEL_ID,
                    body=json.dumps(request_body)
                )
            )
            response_body = json.loads(response['body'].read())
            return {'response': response_body['content'][0]['text'], 'success': True}
        except Exception as e:
            return {'error': str(e), 'success': False}
    
    async def process_single_image(self, image_b64: str, user_prompt: str, system_prompt: str) -> dict:
        """
            Processes a single base64 encoded image with a corresponding text prompt.

            This method invokes a multimodal model, sending both the image and the
            prompt to extract information directly from the visual content.

            Args:
                image_b64 (str): The base64 encoded string of the image.
                user_prompt (str): The user prompt to guide the extraction.
                system_prompt (str): The system prompt to guide the model's behavior.

            Returns:
                dict: A dictionary containing the model's 'response' and a 'success' boolean,
                    or an 'error' message.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        content = [
            {"type": "text", "text": user_prompt},
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": image_b64
                }
            }
        ]
        
        messages = [{"role": "user", "content": content}]
        
        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": AppConfig.ANALYSIS_MAX_TOKENS, # Use analysis tokens as it's a rich extraction
            "temperature": AppConfig.ANALYSIS_TEMPERATURE,
            "system": system_prompt,
            "messages": messages
        }
        
        try:
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.bedrock_async.invoke_model(
                    modelId=AppConfig.ANALYSIS_MODEL_ID, # Use powerful analysis model
                    body=json.dumps(request_body)
                )
            )
            response_body = json.loads(response['body'].read())
            return {'response': response_body['content'][0]['text'], 'success': True}
        except Exception as e:
            return {'error': str(e), 'success': False}

    async def process_chunks_batch(self, chunks: list[dict], user_prompt_template: str, system_prompt: str) -> list[dict]:
        """
            Processes a batch of text chunks in parallel using asyncio.

            This method creates an asynchronous task for each chunk, runs them concurrently,
            and then updates the original chunk dictionaries with the results from the model.

            Args:
                chunks (list[dict]): A list of chunk objects, each with a 'content' key.
                user_prompt_template (str): A template for the user prompt, containing a
                                            '{content}' placeholder.
                system_prompt (str): The system prompt to guide the model's behavior.

            Returns:
                list[dict]: The original list of chunk objects, updated with the 'response',
                            'success', and potentially 'error' keys from the model invocation.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        tasks = []
        for chunk in chunks:
            formatted_prompt = user_prompt_template.format(content=chunk['content'])
            tasks.append(self._invoke_model_async(formatted_prompt, system_prompt))
        
        results = await asyncio.gather(*tasks)
        
        for i, chunk in enumerate(chunks):
            chunk.update(results[i])
        
        return chunks


class DocumentChunkConsolidator:
    """
        Consolidates JSON results from multiple text chunks into a single, unified JSON object.

        This class is responsible for post-processing the output from a language model.
        It includes methods to robustly extract JSON from a model's text response and
        intelligently merge multiple JSON objects based on confidence scores, handling
        nested data structures recursively.
    """

    def extract_json_from_response(self, response_text: str) -> dict[str, Any]:
        """
            Extracts a JSON object from a string, even if it's embedded in markdown code fences.

            This method is designed to be resilient, handling common LLM response formats
            like markdown code blocks. It also attempts to fix common JSON errors, such
            as trailing commas.

            Args:
                response_text (str): The raw text response from the language model.

            Returns:
                dict[str, Any]: The extracted JSON object. Returns an empty dictionary if
                                no valid JSON can be found or parsed.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', response_text, re.DOTALL)
        if match:
            json_str = match.group(1)
        else:
            # Handle cases where the response is inside a json code block without the ```json
            match = re.search(r'```\s*(\{.*?\})\s*```', response_text, re.DOTALL)
            if match:
                json_str = match.group(1)
            else:
                start = response_text.find('{')
                end = response_text.rfind('}')
                if start != -1 and end != -1:
                    json_str = response_text[start:end+1]
                else:
                    return {}

        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            json_str_fixed = re.sub(r',\s*([\}\]])', r'\1', json_str)
            try:
                return json.loads(json_str_fixed)
            except json.JSONDecodeError:
                print("Failed to parse JSON even after attempting to fix it.")
                return {}

    def merge_data(self, base_data: dict, new_data: dict) -> dict:
        """
            Intelligently merges two dictionaries, prioritizing higher confidence scores.

            This method recursively merges nested dictionaries. When it encounters a conflict
            on a field that has a 'confidence' score, it keeps the version with the
            higher score. For other nested structures, it continues to merge recursively.

            Args:
                base_data (dict): The base dictionary to merge into.
                new_data (dict): The new dictionary with data to be merged.

            Returns:
                dict: The intelligently merged dictionary.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        merged = base_data.copy()
        for key, new_value in new_data.items():
            if key not in merged:
                merged[key] = new_value
            # If both old and new values are dictionaries, merge them recursively
            elif isinstance(merged.get(key), dict) and isinstance(new_value, dict):
                 # If it's a value/confidence object, compare confidence
                if "confidence" in new_value and "confidence" in merged[key]:
                    if new_value["confidence"] > merged[key].get("confidence", 0.0):
                        merged[key] = new_value
                # Otherwise, it's a nested structure like an address; recurse
                else:
                    merged[key] = self.merge_data(merged[key], new_value)
        return merged

    def consolidate_chunks(self, chunks: list[dict]) -> dict[str, Any]:
        """
            Consolidates results from a list of processed chunks into a single JSON output.

            This is the main public method that iterates through a list of chunk results,
            extracts the JSON from each successful response, and merges them into a
            final, consolidated dictionary.

            Args:
                chunks (list[dict]): A list of processed chunk objects, each potentially
                                    containing a 'response' string from the model.

            Returns:
                dict[str, Any]: A single dictionary representing the merged data from all chunks.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        consolidated = {}
        for chunk in chunks:
            if chunk.get("success"):
                response_data = self.extract_json_from_response(chunk["response"])
                consolidated = self.merge_data(consolidated, response_data)
        
        return consolidated

def save_model_output_to_s3(docvault_id: str, file_key: str, output: dict[str, Any]) -> Optional[str]:
    """
        Saves a dictionary as a JSON file to a specified S3 location.

        This function constructs a destination S3 key based on the application
        configuration and input parameters. It then serializes the output
        dictionary to a JSON string and uploads it to the specified S3 bucket.

        Args:
            docvault_id (str): The unique identifier for the document vault.
            file_key (str): The original S3 key of the file being processed.
            output (dict[str, Any]): The dictionary containing the model's output data.

        Returns:
            Optional[str]: The S3 key of the newly created output file if successful,
                        otherwise None.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    bucket = AppConfig.DOCVAULTS_BUCKET
    file_name = os.path.basename(file_key).split(".")[0]
    key = f"{AppConfig.MODEL_OUTPUT_KEY.format(docvault_id, file_name)}-results.json"
    try:
        s3.put_object(Bucket=bucket, Key=key, Body=json.dumps(output))
        print(f"Model output saved to s3://{bucket}/{key}")
        return key
    except ClientError as e:
        print(f"Failed to save model output to S3: {e}")


async def model_flow(docvault_id: str, key: str, job_id: str) -> dict[str, Any]:
    """
        Orchestrates the main asynchronous workflow for document processing and data extraction.

        This function represents a complete "Model-based" extraction pipeline. It takes a
        file from S3 and performs the following steps:
        1.  Converts the source document (PDF/image) into a series of page images.
        2.  Uses the images to classify the document type (e.g., "Invoice", "Passport").
        3.  Follows one of two paths based on page count:
            * a.  **Single-page (Fast Path):** Directly extracts structured JSON from the single image.
            * b.  **Multi-page (Normal Path):** Converts the document to markdown, chunks the
                markdown, processes chunks in parallel, and consolidates the results.
        4.  Assembles the final JSON output and saves it back to S3.

        Args:
            docvault_id (str): The unique identifier for the document vault.
            key (str): The S3 object key for the file to be processed.
            job_id (str): A unique identifier for this specific processing job.

        Returns:
            dict[str, Any]: A dictionary containing the S3 key of the final output file
                            and the determined document classification.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    bucket = AppConfig.DOCVAULTS_BUCKET
    print(f"Processing file: s3://{bucket}/{key}")
    
    converter = DocumentToMarkdownConverter()
    file_type = converter.get_file_type(key)
    print(f"File-Type: {file_type}")
    if file_type == "unknown":
        raise ValueError(f"Unsupported file type for key: {key}")

    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        file_data = response["Body"].read()
    except ClientError as e:
        raise ConnectionError(f"S3 download failed for s3://{bucket}/{key}: {e}")

    # --- 1. Always convert to images first ---
    if file_type == 'pdf':
        images = converter._pdf_to_images(file_data)
    else:
        images = [converter._resize_image_from_bytes(file_data)]
    print(f"Converted document to {len(images)} page image(s).")
    
    # --- 2. Classify directly from images ---
    classifier = DocumentClassifier()
    classification_result = classifier.classify_document(images)
    if "Passport" in classification_result.get("classification", ""):
        classification_result["classification"] = "US-Passport"
    if "Driver License" in classification_result.get("classification", ""):
        classification_result["classification"] = "US-Driver-License"
    print(f"Classification result: {classification_result}")

    doc_type = classification_result.get("classification", "Unknown")
    doc_confidence = classification_result.get("confidence", 0.0)
    final_data = {}
    
    # --- 3. Diverge to Fast Path or Normal Path for EXTRACTION ---
    if len(images) == 1:
        # Fast Path for single-page documents
        print("Single-page document detected. Using direct image extraction.")
        user_prompt, system_prompt = classifier.create_direct_image_extraction_prompt(doc_type)
        llm_processor = BedrockLLMProcessor()
        extraction_result = await llm_processor.process_single_image(images[0], user_prompt, system_prompt)
        if extraction_result.get("success"):
            final_data = DocumentChunkConsolidator().extract_json_from_response(extraction_result["response"])
    else:
        # Normal Path for multi-page PDFs
        print("Multi-page document detected. Using markdown chunking flow.")
        
        # THIS is now the only place where the markdown conversion LLM call happens
        markdown_content = converter.convert(file_data, file_type)
        
        user_prompt_template, system_prompt = classifier.create_extraction_prompt(doc_type)
        markdown_processor = MarkdownProcessor()
        chunks = markdown_processor.create_contextual_chunks(markdown_content)
        
        llm_processor = BedrockLLMProcessor()
        processed_chunks = await llm_processor.process_chunks_batch(chunks, user_prompt_template, system_prompt)
        final_data = DocumentChunkConsolidator().consolidate_chunks(processed_chunks)

    # --- Final JSON assembly and saving (common to both paths) ---
    final_json = {
        "job_id": job_id,
        "document_summary": {
            "classification": doc_type,
            "classification_confidence": doc_confidence
        },
        "extracted_data": final_data
    }
    
    output_key = save_model_output_to_s3(docvault_id, key, final_json)
    
    return { 
        "OutputKey": output_key, 
        "Classification": doc_type 
        }

class BedrockDataAutomation:
    """
        Manages interactions with the AWS Bedrock Data Automation service.

        This class encapsulates functionalities for creating and deleting Bedrock
        Data Automation projects, invoking extraction jobs, polling for their status,
        and consolidating the structured output based on predefined schemas.
    """

    def __init__(self, job_id: str):
        """
            Initializes the BedrockDataAutomation client.

            Args:
                job_id (str): A unique identifier for the set of automation tasks.
        """
        self.job_id = job_id
        self.bedrock_da_client = boto3.client('bedrock-data-automation', region_name="us-east-1")
        self.bedrock_da_runtime_client = boto3.client('bedrock-data-automation-runtime', region_name="us-east-1")

    def _get_blueprints(self) -> list[dict[str, str]]:
        """
            Fetches available Bedrock Data Automation blueprint ARNs from DynamoDB.

            Retrieves all blueprints created by the 'System' or the current user.

            Returns:
                list[dict[str, str]]: A list of dictionaries, where each dictionary
                                    contains a "blueprintArn" key.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        try:
            table = dynamodb.Table(AppConfig.CLASSIFICATIONS_TABLE)
            
            filter_expression = Attr('CreatedBy').eq('System') | Attr('CreatedBy').eq(AppConfig.USER)
            
            response = table.scan(
                FilterExpression=filter_expression,
                ProjectionExpression="BlueprintArn"
            )

            blueprints = [
                item["BlueprintArn"] 
                for item in response.get("Items", []) 
                if item and "BlueprintArn" in item
            ]
            
            # Handle paginated results if the table is large
            while 'LastEvaluatedKey' in response:
                response = table.scan(
                    FilterExpression=filter_expression,
                    ProjectionExpression="BlueprintArn",
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                blueprints.extend([
                item["BlueprintArn"] 
                for item in response.get("Items", []) 
                if item and "BlueprintArn" in item
            ])
                
            print(f"Successfully fetched {len(blueprints)} blueprints for user '{AppConfig.USER}'.")
            return [{"blueprintArn": blueprint} for blueprint in blueprints]

        except ClientError as e:
            print(f"Error fetching blueprints from DynamoDB: {e}")
            raise e
        
    def export_job_project_creation(self) -> dict[str, str]:
        """
            Creates a new Bedrock Data Automation project for the current job.

            The project is configured with all available blueprints for custom
            document extraction.

            Returns:
                dict[str, str]: A dictionary containing the 'ProjectName' and 'ProjectArn'
                                of the newly created project.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        project_name = f"project-{self.job_id}"
        project_blueprints = self._get_blueprints()
        print(f"Blueprint fetched: {project_blueprints}")

        project_config = {
            'projectName': project_name,
            'projectDescription': f'Project for IDP Application for the Extraction Job: {self.job_id}',
            'projectStage': 'LIVE',
            'standardOutputConfiguration': {
                'document': {
                    'extraction': {
                        'granularity': {
                            'types': ['PAGE', 'ELEMENT', 'WORD']
                        },
                        'boundingBox': {
                            'state': 'ENABLED'
                        }
                    },
                    'generativeField': {
                        'state': 'ENABLED'
                    },
                    'outputFormat': {
                        'textFormat': {
                            'types': ['CSV', 'MARKDOWN', 'HTML']
                        },
                        'additionalFileFormat': {
                            'state': 'ENABLED'
                        }
                    }
                }
            },
            'customOutputConfiguration': {
                'blueprints': project_blueprints
            },
            'overrideConfiguration': {
                'document': {
                    'splitter': {
                        'state': 'ENABLED'
                    }
                }
            }
        }

        try:
            project_creation_response = self.bedrock_da_client.create_data_automation_project(**project_config)
            print(f"Project: {project_name} created")
        except Exception as e:
            print(f"Failed to create Project: {project_name}.\n Error: {str(e)}")
            raise e

        return {
            "ProjectName": project_name,
            "ProjectArn": project_creation_response.get("projectArn")
        }
        
    def export_job_project_deletion(self, project_arn: str):
        """
            Deletes a Bedrock Data Automation project.

            This is used as a cleanup step after all extraction jobs are complete.

            Args:
                project_arn (str): The ARN of the project to be deleted.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        try:
            self.bedrock_da_client.delete_data_automation_project(projectArn=project_arn)
            print(f"Project: {project_arn} deleted")
        except Exception as e:
            print(f"Failed to delete Project: {project_arn}.\n Error: {str(e)}")
            raise e
    
    def data_automation_extraction(self, file_key: str, project_arn: str) -> dict[str, str]:
        """
            Invokes a Bedrock Data Automation job and polls for its completion.

            Args:
                file_key (str): The S3 key of the document to process.
                project_arn (str): The ARN of the Bedrock DA project to use for extraction.

            Returns:
                dict[str, str]: A dictionary containing the job status, output configuration,
                                and invocation ARN.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        bucket = AppConfig.DOCVAULTS_BUCKET
        input_s3_uri = f"s3://{bucket}/{file_key}"
        output_s3_uri = f"s3://{AppConfig.INTER_BUCKET}/bda"

        invoke_config = {
           'dataAutomationProfileArn':AppConfig.DATA_AUTOMATION_PROFILE,
            'dataAutomationConfiguration':{
                'dataAutomationProjectArn': project_arn
            },
            'inputConfiguration': {
                's3Uri':input_s3_uri
           },
            'outputConfiguration': {
                's3Uri': output_s3_uri
            }
        }
        
        try:
            invocation_arn = self.bedrock_da_runtime_client.invoke_data_automation_async(**invoke_config)["invocationArn"]
            print(f"Invoked Bedrock Data Automation for s3://{bucket}/{file_key} with JobId: {self.job_id}. InvocationARN: {invocation_arn}")

            start_time = time.time()
            while time.time() - start_time < AppConfig.MAX_WAIT_TIME:
                try:
                    automation_status_check_response = self.bedrock_da_runtime_client.get_data_automation_status(invocationArn=invocation_arn)
                    status = automation_status_check_response['status']

                    print(f"Bedrock Data Automation extraction status: {status}")

                    if status == 'Success':
                        return {
                            'status': 'COMPLETED',
                            'output': automation_status_check_response.get('outputConfiguration', {}),
                            "InvocationArn": invocation_arn
                        }
                    elif status.endswith("Error"):
                        return {
                            'status': 'FAILED',
                            'error': automation_status_check_response.get('errorMessage', 'Unknown error'),
                            "InvocationArn": invocation_arn
                        }
                    elif status in ['InProgress', 'Created']:
                        time.sleep(10)  # Wait 10 seconds before checking again
                    else:
                        print(f"Unknown status: {status}")
                        break
                
                except ClientError as e:
                    print(f"Error checking analysis status: {e}")
                    break

        except Exception as e:
            print(f"Failed to invoke Bedrock Data Automation for s3://{bucket}/{file_key} with JobId: {self.job_id}.\n Error: {str(e)}")
            raise e

    def _get_schema_for_classification(self, classification_name: str) -> Optional[dict]:
        """
            Fetches a descriptive schema from S3 based on a document classification.

            It queries a DynamoDB table to find the S3 location of the schema
            associated with the given classification name.

            Args:
                classification_name (str): The name of the classification (e.g., "Invoice").

            Returns:
                Optional[dict]: The parsed JSON schema as a dictionary, or None if not found.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        if not classification_name:
            print("Cannot fetch schema: Classification name is missing.")
            return None

        item = None
        try:
            table = dynamodb.Table(AppConfig.CLASSIFICATIONS_TABLE)

            # Step 1: Try to find a schema matching the username and classification name.
            print(f"Querying for schema '{classification_name}' for user '{AppConfig.USER}'...")
            response = table.query(
                KeyConditionExpression=Key("ClassificationName").eq(classification_name)
            )
            items = response.get("Items", [])

            if items:
                item = items[0]
            else:
                # Step 2: If not found, try to find a SYSTEM schema with that name.
                print(f"User-specific schema not found. Querying for SYSTEM schema '{classification_name}'...")
                response = table.query(
                    KeyConditionExpression=Key("ClassificationName").eq(classification_name)
                )
                items = response.get("Items", [])
                if items:
                    item = items[0]

            # --- Proceed if an item was found from either query ---
            if not item:
                print(f"Schema not found for '{classification_name}' for either user or SYSTEM.")
                return None

            s3_key = item.get("SchemaS3Location")    
            if s3_key:
                s3_response = s3.get_object(Bucket=AppConfig.CLASSIFICATION_BUCKET, Key=s3_key)
                schema = json.loads(s3_response["Body"].read())

                print(f"Successfully fetched schema for '{classification_name}' from s3://{AppConfig.CLASSIFICATION_BUCKET}/{s3_key}")
                return schema
            else:
                print(f"Found classification item, but it's missing the S3 key.")
                return None

        except ClientError as e:
            print(f"A DynamoDB or S3 error occurred while fetching schema for '{classification_name}'. Error: {e}")
            return None

    def consolidate_bda_outupt(self, docvault_id: str, file_key: str, invocation_arn: str) -> str:
        """
            Consolidates and parses BDA output from S3 into a final JSON object.

            This method peeks at the BDA output to determine the document's classification,
            fetches the corresponding schema, and then merges the per-page results into
            a single, structured JSON file.

            Args:
                docvault_id (str): The ID of the document vault.
                file_key (str): The original S3 key of the processed file.
                invocation_arn (str): The ARN of the BDA job invocation.

            Returns:
                Any: If a custom blueprint was matched, returns a dictionary with the
                    'OutputKey' and 'Classification'. If no blueprint was matched,
                    returns the string "AUTO-CLASSIFIED". Returns an empty string on error.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        file_name = os.path.basename(file_key).split(".")[0]
        BUCKET = AppConfig.INTER_BUCKET
        BASE_PREFIX = f"bda/{invocation_arn.split('/')[-1]}/0/custom_output/"
        OUTPUT_PREFIX = f"{AppConfig.BDA_OUTPUT_KEY.format(docvault_id, file_name)}-results.json"
        classification_name = None

        # Check if the custom output from BDA exists. If not, the classification doesn't exist, hence auto-classified by the model.  
        try:
            print("base-prefix", BASE_PREFIX, "output-prefix", OUTPUT_PREFIX)
            response = s3.list_objects_v2(Bucket=BUCKET, Prefix=BASE_PREFIX, MaxKeys=1)
            if "Contents" in response:
                print("Custom output from BDA exists. Proceeding with classification and schema fetching.")
            else:
                print("Custom output from BDA doesn't exist. Auto classified by the model.")
                return "AUTO-CLASSIFIED"
        except ClientError as e:
            print(f"Error checking for custom output from BDA. Error: {e}")

        # --- CHANGE: Fetch schema dynamically within the function ---
        descriptive_schema = None
        try:
            # 1. Peek at the first file to get the classification
            first_result_key = f"{BASE_PREFIX}0/result.json"
            print(f"Peeking at first result file: {first_result_key}")
            response = s3.get_object(Bucket=BUCKET, Key=first_result_key)
            first_data_object = json.loads(response['Body'].read())
            classification_name = first_data_object.get('matched_blueprint', {}).get('name')

            # 2. Fetch the schema based on the classification
            descriptive_schema = self._get_schema_for_classification(classification_name)

        except ClientError as e:
            print(f"Could not read the first result file to determine classification. Error: {e}")
            # Depending on requirements, you might want to exit or handle this differently
            return "" # Exit if we can't determine the document type

        if not descriptive_schema:
            print("Could not retrieve a valid schema. Aborting consolidation.")
            return ""

        # --- Proceed with merging, now that we have the schema ---
        combined_output = {}
        is_first_page = True
        paginator = s3.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=BUCKET, Prefix=BASE_PREFIX, Delimiter='/')

        print("Entering the result merging process with the correct schema.")
        for page in pages:
            for folder in page.get('CommonPrefixes', []):
                s3_file_key = f"{folder.get('Prefix')}result.json"
                try:
                    response = s3.get_object(Bucket=BUCKET, Key=s3_file_key)
                    data_object = json.loads(response['Body'].read())
                    parsed_data = self._parse_bedrock_output(data_object, descriptive_schema)

                    if is_first_page:
                        combined_output = parsed_data
                        is_first_page = False
                    else:
                        new_extracted_data = parsed_data.get("extracted_data", {})
                        for key, new_value_obj in new_extracted_data.items():
                            if (key not in combined_output["extracted_data"] or
                                new_value_obj["confidence"] > combined_output["extracted_data"][key]["confidence"]):
                                combined_output["extracted_data"][key] = new_value_obj
                except Exception as e:
                    print(f"Could not process file {s3_file_key}. Error: {e}")
        
        if combined_output:
            print("Uploading the final merged result to the bucket.")
            s3.put_object(
                Bucket=AppConfig.DOCVAULTS_BUCKET,
                Key=OUTPUT_PREFIX,
                Body=json.dumps(combined_output, indent=2),
                ContentType='application/json'
            )
        else:
            print("No data was processed to upload.")

        return {
            "OutputKey": OUTPUT_PREFIX,
            "Classification": classification_name,
        }
    
    def _parse_bedrock_output(self, bedrock_data: dict, descriptive_schema: dict) -> dict:
        """
            Dynamically parses raw Bedrock Data Automation JSON output using a descriptive schema.

            This method recursively traverses the raw output and the schema to build a
            clean, structured dictionary that preserves the nesting defined in the schema.

            Args:
                bedrock_data (Dict): The raw JSON object from a BDA result file.
                descriptive_schema (Dict): The corresponding schema for the document type.

            Returns:
                dict: A clean, parsed dictionary containing the extracted data.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        inference_data = bedrock_data.get('inference_result', {})
        explainability_data = bedrock_data.get('explainability_info', [{}])[0]
        
        # This will be populated with the correct nested structure
        extracted_data = {}

        # --- CHANGE: The function now takes an 'output_level' argument ---
        def process_level(schema_level, inference_level, explainability_level, output_level):
            """
                Recursively processes one level of the schema and raw data to build a clean output.

                This is a nested helper function that compares a level of the descriptive schema
                against the corresponding levels of the inference and explainability data from
                Bedrock Data Automation. It populates the `output_level` dictionary with a clean,
                structured format.

                Args:
                    schema_level (dict): The current dictionary level of the descriptive schema.
                    inference_level (dict): The current dictionary level of the inference result.
                    explainability_level (dict): The current dictionary level of the explainability data.
                    output_level (dict): The dictionary level of the final output to populate.
            """

            # Getting the current function name
            function_name = CURRENT_FUNC_NAME()
            LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

            for key, description in schema_level.items():
                if key not in inference_level:
                    continue

                # If the schema value is a dict, it's a nested group. Recurse.
                if isinstance(description, dict):
                    # --- CHANGE: Create a nested dictionary in the output ---
                    nested_output = output_level.setdefault(key, {})
                    process_level(
                        description,
                        inference_level.get(key, {}),
                        explainability_level.get(key, {}),
                        nested_output  # Pass the new nested dict for the next level
                    )
                # Otherwise, it's a standard field to be extracted.
                else:
                    value = inference_level.get(key)
                    try:
                        confidence = explainability_level.get(key, {}).get('confidence', 0.0)
                    except Exception as e:
                        confiednce = 0.0
                    
                    output_level[key] = {
                        "value": value,
                        "confidence": round(confidence, 2) if isinstance(confidence, float) else 0.0
                    }

        # Start the recursive extraction at the top level
        process_level(descriptive_schema, inference_data, explainability_data, extracted_data)

        # Assemble the final structure
        parsed_output = {
            "job_id": datetime.now().strftime('%Y%m%d-%H%M%S'),
            "document_summary": {
                "classification": bedrock_data.get('matched_blueprint', {}).get('name', ''),
                "classification_confidence": round(bedrock_data.get('matched_blueprint', {}).get('confidence', 0.0), 2)
            },
            "extracted_data": {key:value for key, value in extracted_data.items() if value}
        }
        
        return parsed_output

def bedrock_data_automation_flow(docvault_id: str, file_key: str, job_id: str, project_arn: str) -> dict[str, str]:
    """
        Orchestrates the main workflow for a Bedrock Data Automation extraction.

        This function serves as a high-level wrapper that:
        1. Instantiates the BedrockDataAutomation client.
        2. Invokes an extraction job for a specific file.
        3. Waits for the job to complete and then consolidates the results.

        Args:
            docvault_id (str): The unique identifier for the document vault.
            file_key (str): The S3 object key for the file to be processed.
            job_id (str): A unique identifier for this specific processing job.
            project_arn (str): The ARN of the Bedrock Data Automation project to use.

        Returns:
            dict[str, str]: A dictionary containing the S3 key of the consolidated
                            output file and the determined document classification.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    bedrock_da = BedrockDataAutomation(job_id)
    try:
        invocation_arn = bedrock_da.data_automation_extraction(file_key, project_arn)["InvocationArn"]
        return bedrock_da.consolidate_bda_outupt(docvault_id, file_key, invocation_arn)
    except Exception as e:
        print(f"Failed to extract file: s3://{AppConfig.DOCVAULTS_BUCKET}/{file_key} with JobId: {job_id}.\n Error: {str(e)}")
        raise e

class OutputComparer:
    """
        Fetches, compares, and merges two document extraction outputs.

        This class is designed to consolidate the results from two different
        extraction pipelines (e.g., a Bedrock Data Automation flow and a custom
        model flow). It intelligently merges the data based on confidence scores
        and a predefined schema, producing a single, unified output file.
    """

    def _get_schema_for_classification(self, classification_name: str) -> Optional[dict]:
        """
            Fetches a descriptive schema from S3 based on a document classification.

            It queries a DynamoDB table to find the S3 location of the schema
            associated with the given classification name for either the current
            user or the system.

            Args:
                classification_name (str): The name of the classification (e.g., "Invoice").

            Returns:
                Optional[dict]: The parsed JSON schema as a dictionary, or None if not found.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        if not classification_name:
            print("Cannot fetch schema: Classification name is missing.")
            return None

        item = None
        try:
            table = dynamodb.Table(AppConfig.CLASSIFICATIONS_TABLE)

            # Step 1: Try to find a schema matching the username and classification name.
            print(f"Querying for schema '{classification_name}' for user '{AppConfig.USER}'...")
            response = table.query(
                KeyConditionExpression=Key("ClassificationName").eq(classification_name)
            )
            items = response.get("Items", [])

            if items:
                item = items[0]
            else:
                # Step 2: If not found, try to find a SYSTEM schema with that name.
                print(f"User-specific schema not found. Querying for SYSTEM schema '{classification_name}'...")
                response = table.query(
                    KeyConditionExpression=Key("ClassificationName").eq(classification_name)
                )
                items = response.get("Items", [])
                if items:
                    item = items[0]

            # --- Proceed if an item was found from either query ---
            if not item:
                print(f"Schema not found for '{classification_name}' for either user or SYSTEM.")
                return None

            s3_key = item.get("SchemaS3Location")    
            if s3_key:
                s3_response = s3.get_object(Bucket=AppConfig.CLASSIFICATION_BUCKET, Key=s3_key)
                schema = json.loads(s3_response["Body"].read())

                print(f"Successfully fetched schema for '{classification_name}' from s3://{AppConfig.CLASSIFICATION_BUCKET}/{s3_key}")
                return schema
            else:
                print(f"Found classification item, but it's missing the S3 key.")
                return None

        except ClientError as e:
            print(f"A DynamoDB or S3 error occurred while fetching schema for '{classification_name}'. Error: {e}")
            return None

    def compare_outputs(self, output1: dict, output2: dict) -> dict[str, Any]:
        """
            Compares and merges two extraction output dictionaries based on a schema.

            This method validates that both outputs share the same classification,
            fetches the relevant schema, and then recursively merges the extracted data.
            For conflicting fields, it prioritizes the value with the higher confidence
            score. If values differ, it flags them for review.

            Args:
                output1 (dict): The first extraction output object (e.g., from BDA).
                output2 (dict): The second extraction output object (e.g., from a custom model).

            Returns:
                dict[str, Any]: A single, consolidated dictionary containing the merged data
                                or an error message if classifications mismatch or schema is not found.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        bda_summary = output1.get('document_summary', {})
        model_summary = output2.get('document_summary', {})

        # 1. Validate that classifications match
        bda_classification = bda_summary.get('classification')
        model_classification = model_summary.get('classification')
        if bda_classification != model_classification:
            return {"error": "Document classifications do not match."}

        # --- CHANGE: Fetch schema internally instead of receiving it as an argument ---
        if not bda_classification:
            return {"error": "Classification name is missing from the document summary."}
        
        schema = self._get_schema_for_classification(bda_classification)
        
        if not schema:
            return {"error": f"Could not retrieve a valid schema for classification '{bda_classification}'."}

        # --- Comparison logic proceeds as before ---
        bda_data = output1.get('extracted_data', {})
        model_data = output2.get('extracted_data', {})

        def _recursive_compare(schema_level, bda_level, model_level):
            """
                Recursively compares and merges two levels of extraction data against a schema.

                This nested helper function walks through a schema and the corresponding data
                from two different extraction sources (BDA and a custom model). It normalizes
                values for accurate comparison, merges fields that match, flags fields that
                conflict, and includes fields present in only one source.

                Args:
                    schema_level (dict): The current dictionary level of the descriptive schema.
                    bda_level (dict): The current dictionary level of the BDA extraction data.
                    model_level (dict): The current dictionary level of the custom model's data.

                Returns:
                    dict: A new dictionary representing the merged data for the current level.
            """

            # Getting the current function name
            function_name = CURRENT_FUNC_NAME()
            LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")
            
            if isinstance(bda_level, list) or isinstance(model_level, list):
                return {}

            merged_level = {}

            def _normalize_value(value):
                """Attempts to convert a value into a float for comparison."""
                # If it's already a number, do nothing.
                if isinstance(value, (int, float)):
                    return value
                # If it's a string, try to convert it.
                if isinstance(value, str):
                    try:
                        # Remove commas and convert to float
                        return float(value.replace(',', '').strip())
                    except (ValueError, TypeError):
                        # If conversion fails, it's a non-numeric string.
                        return value.strip()
                # Return other types as-is
                return value

            for key, description in schema_level.items():
                is_nested = isinstance(description, dict)
                bda_item = bda_level.get(key)
                model_item = model_level.get(key)

                if is_nested:
                    nested_result = _recursive_compare(description, bda_item or {}, model_item or {})
                    if nested_result:
                        merged_level[key] = nested_result
                    continue
                
                bda_has_value = bda_item and bda_item.get("value") not in [None, ""]
                model_has_value = model_item and model_item.get("value") not in [None, ""]

                # Case 1: Both outputs have a non-empty value.
                if bda_has_value and model_has_value:
                    bda_value = bda_item["value"]
                    model_value = model_item["value"]

                    # --- CHANGE: Normalize values before comparing ---
                    norm_bda_value = _normalize_value(bda_value)
                    norm_model_value = _normalize_value(model_value)

                    if norm_bda_value == norm_model_value:
                        # If values are semantically equal, merge them.
                        # Prefer storing the actual number type (int/float) if available.
                        final_value = bda_value if isinstance(bda_value, (int, float)) else model_value
                        
                        merged_level[key] = {
                            "value": final_value,
                            "confidence": max(bda_item.get("confidence", 0.0), model_item.get("confidence", 0.0))
                        }
                    else:
                        # If values are truly different, show both.
                        merged_level[key] = {"bda": bda_item, "model": model_item}
                
                # Case 2: Only the BDA output has a non-empty value.
                elif bda_has_value:
                    bda_item["value"] = _normalize_value(bda_item["value"])
                    merged_level[key] = bda_item

                # Case 3: Only the Model output has a non-empty value.
                elif model_has_value:
                    model_item["value"] = _normalize_value(model_item["value"])
                    merged_level[key] = model_item
                    
            return merged_level

        compared_data = _recursive_compare(schema, bda_data, model_data)
        
        bda_conf = bda_summary.get('classification_confidence', 0.0)
        model_conf = model_summary.get('classification_confidence', 0.0)

        final_summary = {
            "classification": model_classification,
            "classification_confidence": max(bda_conf, model_conf)
        }

        return {
            "job_id": output1.get('job_id'),
            "document_summary": final_summary,
            "compared_data": compared_data
        }

    def fetch_and_compare_from_s3(self, bda_key: str, model_key: str) -> dict[str, str]:
        """
            Fetches two output files from S3, compares them, and saves the result.

            This is the main public method that orchestrates the entire comparison process.
            It downloads the specified files, runs the comparison logic, and uploads
            the final consolidated JSON to a destination in S3.

            Args:
                bda_key (str): The S3 key of the Bedrock Data Automation output file.
                model_key (str): The S3 key of the custom model output file.

            Returns:
                Optional[dict[str, str]]: A dictionary containing the S3 location and classification
                                        of the final output file, or None on failure.
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        bucket = AppConfig.DOCVAULTS_BUCKET
        print("Fetching output files from S3...")
        print(f"Bucket: {bucket}")
        print(f"BDA Key: {bda_key}")
        print(f"Model Key: {model_key}")
        bda_obj = s3.get_object(Bucket=bucket, Key=bda_key)
        model_obj = s3.get_object(Bucket=bucket, Key=model_key)
        
        output1 = json.loads(bda_obj['Body'].read())
        output2 = json.loads(model_obj['Body'].read())
        
        print("Files fetched. Running comparison...")
        comparison_result = self.compare_outputs(output1, output2)
        classification = comparison_result['document_summary']['classification']

        if "error" in comparison_result:
            print(f"Comparison failed: {comparison_result['error']}. Not saving to S3.")
            return None

        try:
            docvault_id = bda_key.split('/')[1]
            file_name = bda_key.split('/')[-1].split('.')[0].rsplit('-', 1)[0]
            dest_key = f"{AppConfig.FINAL_OUTPUT_KEY.format(docvault_id, file_name)}.json"
            print(f"Saving final comparison to s3://{AppConfig.DOCVAULTS_BUCKET}/{dest_key}")
            s3.put_object(
                Bucket=AppConfig.DOCVAULTS_BUCKET,
                Key=dest_key,
                Body=json.dumps(comparison_result, indent=2),
                ContentType='application/json'
            )
            # Return the S3 key of the saved file
            return {
                "ExtractionS3Location": dest_key,
                "Classification": classification
            }
            
        except Exception as e:
            print(f"Failed to save final result to S3. Error: {e}")
            return None

def create_metadata_file(object_key: str , docvault_id: str, classification: str) -> None:
    """
        Creates and uploads a companion metadata JSON file for a given S3 object.

        This function generates a JSON object containing metadata attributes and uploads
        it to the same S3 location as the original object, but with a
        `.metadata.json` suffix appended to the key.

        Args:
            object_key (str): The S3 object key of the primary file for which to
                            create metadata.
            docvault_id (str): The unique identifier of the document vault.
            classification (str): The document classification type (e.g., "Invoice").
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    metadata = {
        "metadataAttributes": {
            'DocVaultId': docvault_id,
            'Classification': classification,
        }
    }
    metadata_key = f"{object_key}.metadata.json"
    try:
        s3.put_object(
            Bucket=AppConfig.DOCVAULTS_BUCKET,
            Key=metadata_key,
            Body=json.dumps(metadata, indent=2),
            ContentType='application/json'
        )
        print(f"Successfully created metadata for {object_key}")
    except Exception as e:
        print(f"Failed to create metadata for {object_key}: {str(e)}")


def check_user_docvault_access(username: str, docvault_id: str) -> bool:
    """
    Checks if a user has modification access to a DocVault.

    Access is granted if:
    1. The user is the creator of the DocVault.
    2. The user has an explicit "EDITOR" role in the access control table.

    Args:
        username: The username to check.
        docvault_id: The ID of the DocVault.

    Returns:
        True if the user has access, False otherwise.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    # 1. Check if the DocVault exists and if the user is the creator.
    docvaults_table = dynamodb.Table(AppConfig.DOCVAULTS_TABLE)
    docvault_response = docvaults_table.get_item(
        Key={"DocVaultId": docvault_id}
    )

    # If the DocVault doesn't exist, deny access.
    if "Item" not in docvault_response:
        return False
    
    # If the user is the creator, grant access immediately.
    if docvault_response["Item"].get("CreatedBy") == username:
        return True

    # 2. If not the creator, check the dedicated access table for an EDITOR role.
    access_table = dynamodb.Table(AppConfig.ACCESS_TABLE)
    access_response = access_table.get_item(
        Key={"Username": username, "DocVaultId": docvault_id}
    )

    # Check if an access record exists and if the type is "EDITOR".
    if "Item" in access_response and access_response["Item"].get("AccessType") == "EDITOR":
        print(f"User {username} has EDITOR access to DocVault {docvault_id}")
        return True

    # If neither of the above conditions are met, deny access.
    return False


def start_extraction_job(event: dict) -> dict:
    """
    Creates a BDA project and prepares the job for parallel execution.

    Args:
        event (dict): The input event from the Step Function.

    Returns:
        dict: The payload for the next step in the state machine.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    try:
        job_id = datetime.now().strftime("%Y%m%d-%H%M%S")
        bedrock_da = BedrockDataAutomation(job_id)
        project_info = bedrock_da.export_job_project_creation()
        project_arn = project_info.get("ProjectArn")

        docvault_id = event.get("DocVaultId", "")
        file_keys = event.get("FileKeys", [])
        user = event.get("User", "")

        return {
            "Task": "Parallel Extraction",
            "DocVaultId": docvault_id,
            "FileKeys": file_keys,
            "JobId": job_id,
            "ProjectArn": project_arn,
            "User": user
        }
    
    except Exception as e:
        print(f"Failed to start extraction job. Error: {str(e)}")
        files_table = dynamodb.Table(AppConfig.FILES_TABLE)
        for file_key in event.get("FileKeys", []):
            files_table.update_item(
                Key={"DocVaultId": docvault_id, "FileName": file_key.split("/")[-1]},
                UpdateExpression="SET #status = :status, #last_modified_by = :user, #last_modification_time = :time",
                ExpressionAttributeNames={"#status": "ExtractStatus", "#last_modified_by": "LastModifiedBy", "#last_modification_time": "LastModifiedAt"},
                ExpressionAttributeValues={":status": "Failed", ":user": AppConfig.USER, ":time": datetime.now().isoformat()}
            )
        raise e

def parallel_extraction_task(event: dict) -> dict:
    """
    Executes a single extraction task (either BDA or Model) for one file.

    Args:
        event (dict): The input event for a single iteration of the Map state.

    Returns:
        dict: The result of the extraction, including output key and classification.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")
    
    job_id = event.get("JobId", "")
    project_arn = event.get("ProjectArn", "")
    docvault_id = event.get("DocVaultId", "")
    extraction = event.get("Extraction", "Model")
    file_key = event.get("FileKey", "")
    AppConfig.USER = event.get("User", "")

    print(f"JobId: {job_id}, ProjectArn: {project_arn}, DocVaultId: {docvault_id}, Extraction: {extraction}, FileKey: {file_key}")

    try:
        if extraction == "BDA":
            try:
                bda_output = bedrock_data_automation_flow(docvault_id, file_key, job_id, project_arn)
                if bda_output == "AUTO-CLASSIFIED":
                    print(f"File: s3://{AppConfig.DOCVAULTS_BUCKET}/{file_key} with JobId: {job_id} was auto-classified. Skipping extraction.")
                    return {
                        "DocVaultId": docvault_id,
                        "JobId": job_id,
                        "FileKey": file_key,
                        "OutputKey": None,
                        "Classification": "AUTO-CLASSIFIED",
                        "ProjectArn": project_arn,
                        "Extraction": "BDA",
                        "User": AppConfig.USER
                    }

                return {
                    "DocVaultId": docvault_id,
                    "JobId": job_id,
                    "FileKey": file_key,
                    "OutputKey": bda_output["OutputKey"],
                    "Classification": bda_output["Classification"],
                    "ProjectArn": project_arn,
                    "Extraction": "BDA",
                    "User": AppConfig.USER
                }
            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f"Failed to extract file: s3://{AppConfig.DOCVAULTS_BUCKET}/{file_key} with JobId: {job_id}.\n Error: {str(e)}")
                raise e
        if extraction == "Model":
            try:
                model_output = asyncio.run(model_flow(docvault_id, file_key, job_id))
                return {
                    "DocVaultId": docvault_id,
                    "JobId": job_id,
                    "FileKey": file_key,
                    "OutputKey": model_output["OutputKey"],
                    "Classification": model_output["Classification"],
                    "ProjectArn": project_arn,
                    "Extraction": "Model",
                    "User": AppConfig.USER
                }
            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f"Failed to extract file: s3://{AppConfig.DOCVAULTS_BUCKET}/{file_key} with JobId: {job_id}.\n Error: {str(e)}")
                raise e
    except Exception as e:
        files_table = dynamodb.Table(AppConfig.FILES_TABLE)
        files_table.update_item(
            Key={"DocVaultId": docvault_id, "FileName": file_key.split("/")[-1]},
            UpdateExpression="SET #status = :status, #last_modified_by = :user, #last_modification_time = :time",
            ExpressionAttributeNames={"#status": "ExtractStatus", "#last_modified_by": "LastModifiedBy", "#last_modification_time": "LastModifiedAt"},
            ExpressionAttributeValues={":status": "Failed", ":user": AppConfig.USER, ":time": datetime.now().isoformat()}
        )
        raise e

def delete_project_task(event: dict) -> dict:
    """
    Gathers map state results and deletes the BDA project.

    Args:
        event (dict): The input event, containing the output of the Map state.

    Returns:
        dict: A formatted list of file keys for the final comparison step.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")
    
    try:
        bda_map_output = event.get("MapStateOutput", None)[0]
        model_map_output = event.get("MapStateOutput", None)[1]
        docvault_id = bda_map_output[0].get("DocVaultId", None)
        project_arn = bda_map_output[0].get("ProjectArn", None)
        job_id = bda_map_output[0].get("JobId", None)
        AppConfig.USER = bda_map_output[0].get("User", None)

        files_key_list = []

        for bda_item, model_item in zip(bda_map_output, model_map_output):
            files_key_list.append({
                "Original": bda_item.get("FileKey", None),
                "BDA": bda_item.get("OutputKey", None),
                "Model": model_item.get("OutputKey", None)
            })

        bedrock_da = BedrockDataAutomation(job_id)
        print(f"Deleting project: {project_arn}")
        bedrock_da.export_job_project_deletion(project_arn)

        return {
            "DocVaultId": docvault_id,
            "FilesKeyList": files_key_list,
            "User": AppConfig.USER
        }
    except Exception as e:
        print(f"Failed to delete project. Error: {str(e)}")
        files_table = dynamodb.Table(AppConfig.FILES_TABLE)
        for file_keys in files_key_list:
            original_file_key = file_keys["Original"]
            files_table.update_item(
                Key={"DocVaultId": docvault_id, "FileName": original_file_key.split("/")[-1]},
                UpdateExpression="SET #status = :status, #last_modified_by = :user, #last_modification_time = :time",
                ExpressionAttributeNames={"#status": "ExtractStatus", "#last_modified_by": "LastModifiedBy", "#last_modification_time": "LastModifiedAt"},
                ExpressionAttributeValues={":status": "Failed", ":user": AppConfig.USER, ":time": datetime.now().isoformat()}
            )
        raise e


def output_comparison_task(event: dict) -> dict:
    """
    Compares BDA and Model outputs, saves the final result, and updates databases.

    Args:
        event (dict): The input event for a single file comparison.

    Returns:
        dict: A summary of the final output location and classification.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    docvault_id = event.get("DocVaultId", "")
    files_key_dict = event.get("FilesKeyDictionary", {})
    bda_key = files_key_dict.get("BDA")
    model_key = files_key_dict.get("Model")
    original_key = files_key_dict.get("Original", "")
    AppConfig.USER = event.get("User", "")

    final_output = None 

    if not bda_key:
        print(f"BDA output for {original_key} was auto-classified. Promoting Model output directly.")
        
        try:
            # 1. Fetch the Model's output file from S3
            model_obj = s3.get_object(Bucket=AppConfig.DOCVAULTS_BUCKET, Key=model_key)
            model_json = json.loads(model_obj['Body'].read())

            # 2. Reformat the model's output for structural consistency in the final bucket.
            promoted_json = {
                "job_id": model_json.get("job_id"),
                "document_summary": model_json.get("document_summary", {}),
                "compared_data": model_json.get("extracted_data", {}) # Use extracted_data as the main data block
            }
            classification = promoted_json["document_summary"].get("classification", "Unknown")

            # 3. Determine the final destination key
            file_name = original_key.split('/')[-1].split('.')[0]
            dest_key = f"{AppConfig.FINAL_OUTPUT_KEY.format(docvault_id, file_name)}.json"
            
            # 4. Save the promoted JSON to the final S3 location
            print(f"Saving promoted output to s3://{AppConfig.DOCVAULTS_BUCKET}/{dest_key}")
            s3.put_object(
                Bucket=AppConfig.DOCVAULTS_BUCKET,
                Key=dest_key,
                Body=json.dumps(promoted_json, indent=2),
                ContentType='application/json'
            )
            
            # 5. Populate the final_output variable so the rest of the function can proceed
            final_output = {
                "ExtractionS3Location": dest_key,
                "Classification": classification
            }

        except Exception as e:
            print(f"Error promoting model output for {model_key}: {e}")
            raise e # Fail the execution if promotion fails

    else:
        # If a BDA key exists, proceed with the standard comparison logic
        print(f"Both BDA and Model outputs found for {original_key}. Running comparison.")
        output_comparison = OutputComparer()
        final_output = output_comparison.fetch_and_compare_from_s3(
            bda_key,
            model_key
        )

    # --- The rest of the logic is now common to both paths ---
    if not final_output:
        # This ensures the step function fails if neither comparison nor promotion succeeds
        raise Exception("Failed to produce a final output document for comparison/promotion.")

    extracted_file_name = final_output["ExtractionS3Location"].split('/')[-1]
    extraction_table = dynamodb.Table(AppConfig.EXTRACTED_FILES_TABLE)
    extraction_table.put_item(
        Item={
            "DocVaultId": docvault_id,
            "ExtractedFileName": extracted_file_name,
            "FileName": original_key.split('/')[-1],
            "ExtractionS3Location": final_output["ExtractionS3Location"],
            "ClassificationName": final_output["Classification"],
            "CreatedBy": AppConfig.USER,
            "CreatedAt": datetime.now().isoformat(),
            "LastModifiedBy": AppConfig.USER,
            "LastModifiedAt": datetime.now().isoformat()
        }
    )

    files_table = dynamodb.Table(AppConfig.FILES_TABLE)
    files_table.update_item(
        Key={"DocVaultId": docvault_id, "FileName": original_key.split('/')[-1]},
        UpdateExpression="SET #status = :status, #last_modified_by = :user, #last_modification_time = :time",
        ExpressionAttributeNames={"#status": "ExtractStatus", "#last_modified_by": "LastModifiedBy", "#last_modification_time": "LastModifiedAt"},
        ExpressionAttributeValues={":status": "Processed", ":user": AppConfig.USER, ":time": datetime.now().isoformat()}
    )

    s3_location = final_output["ExtractionS3Location"]
    classification = final_output["Classification"]

    print("Creating metadata file for the final output file.")
    create_metadata_file(s3_location, docvault_id, classification)

    return {
        "Task": "Update DynamoDB",
        "DocVaultId": docvault_id,
        "Extraction S3 Location": final_output["ExtractionS3Location"],
        "Classification": final_output["Classification"],
        "Original S3 Key": original_key,
        "User": AppConfig.USER
    }


def handle_api_gateway_invocations(event: dict) -> dict:
    """
        Handles an incoming request from API Gateway to start an extraction workflow.

        This function is responsible for:
        1.  Authorizing the user against the DocVault.
        2.  Filtering out files that have already been processed.
        3.  Updating the status of new files to "Processing" in DynamoDB.
        4.  Starting the Step Function execution for the files that need processing.

        Args:
            event (dict): The API Gateway Lambda proxy integration event.

        Returns:
            dict: A standard API Gateway response object.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    cognito_claims = event.get("requestContext", {}).get("authorizer", {}).get("claims", {})
    AppConfig.USER = cognito_claims["preferred_username"]
    print(f"User: {AppConfig.USER}")

    path_params = event.get("pathParameters", {})
    docvault_id = path_params.get("docvault-id", "")
    print(f"Docvault ID: {docvault_id}")
    
    if not check_user_docvault_access(AppConfig.USER, docvault_id):
        print(f"User {AppConfig.USER} is not authorized to perform extraction in this DocVault.")
        return {
            "statusCode": 403,
            "body": json.dumps({"Message": f"{AppConfig.USER} is not authorized to perform extraction in this DocVault."}),
            "headers": AppConfig.CORS_HEADERS
        }

    body = json.loads(event.get("body", {}))
    files = body.get("FileNames", [])
    files = [file.strip() for file in files if file.strip()]
    print(f"Files: {files}")

    # --- KEY LOGIC CHANGE ---
    # 1. Check the status of each file before starting the extraction job
    files_to_process = []
    already_processed_files = []
    files_table = dynamodb.Table(AppConfig.FILES_TABLE)

    for file_name in files:
        try:
            response = files_table.get_item(
                Key={"DocVaultId": docvault_id, "FileName": file_name},
                ProjectionExpression="ExtractStatus"
            )
            item = response.get("Item")
            # If the item exists and its status is "Processed", skip it
            if item and item.get("ExtractStatus") == "Processed":
                already_processed_files.append(file_name)
            else:
                files_to_process.append(file_name)
        except Exception as e:
            # If there's an error (e.g., table not found), log it and proceed
            print(f"Could not check status for {file_name}: {e}. Assuming it needs processing.")
            files_to_process.append(file_name)

    print(f"Files to process: {files_to_process}")
    print(f"Already processed files: {already_processed_files}")


    # 2. If all requested files have already been processed, stop here
    if not files_to_process:
        message = "No new files to process. All requested files have already been completed."
        return {
            'statusCode': 200,
            'body': json.dumps({"Message": message, "SkippedFiles": already_processed_files}),
            "headers": AppConfig.CORS_HEADERS
        }

    # 3. Proceed with the extraction flow ONLY for the files that need processing
    file_keys = []
    for file_name in files_to_process:
        files_table.update_item(
            Key={"DocVaultId": docvault_id, "FileName": file_name},
            UpdateExpression="SET #status = :status, #last_modified_by = :user, #last_modification_time = :time",
            ExpressionAttributeNames={"#status": "ExtractStatus", "#last_modified_by": "LastModifiedBy", "#last_modification_time": "LastModifiedAt"},
            ExpressionAttributeValues={":status": "Processing", ":user": AppConfig.USER, ":time": datetime.now().isoformat()}
        )
        file_keys.append(AppConfig.ORIGINAL_FILE_KEY.format(docvault_id, file_name))

    # 4. Start the Step Function with the filtered list of file keys
    step_function_input = {
            "Task": "Start Extraction Job",
            "DocVaultId": docvault_id,
            "FileKeys": file_keys,
            "User": AppConfig.USER
        }
    step_function.start_execution(
        stateMachineArn=AppConfig.EFP_STEP_FUNCTION_ARN,
        input=json.dumps(step_function_input)
    )

    # 5. Return a more informative response
    response_message = f"Extraction started for {len(files_to_process)} file(s)."
    if already_processed_files:
        response_message += f" Skipped {len(already_processed_files)} already processed file(s)."

    return {
        'statusCode': 200,
        'body': json.dumps({
            "Message": response_message
        }),
        "headers": AppConfig.CORS_HEADERS
    }

def lambda_handler(event: dict, context: dict) -> dict:
    """Main Lambda handler function."""

    # Getting the Lambda Name
    global LAMBDA_NAME
    LAMBDA_NAME = context.function_name

    if "httpMethod" in event:
        return handle_api_gateway_invocations(event)

    else:
        task = event.get("Task", "")
        print(f"Task: {task}")

        if task == "Start Extraction Job":
            return start_extraction_job(event)

        elif task == "Parallel Extraction":
            return parallel_extraction_task(event)

        elif task == "Delete Project":
            return delete_project_task(event)
        
        elif task == "Output Comparison":
            return output_comparison_task(event)

    return {
        'statusCode': 500,
        'body': json.dumps('Should not have reached here.')
    }