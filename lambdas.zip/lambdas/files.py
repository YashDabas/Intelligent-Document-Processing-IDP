import json
import boto3
import os
import logging
import copy
import uuid
import re
import urllib.parse
import io
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
from googleapiclient.errors import HttpError
import requests
from boto3.dynamodb.conditions import Key
from datetime import datetime, timedelta
from IDPutils import paginate_list, VALID_FILE_SORT_KEYS, VALID_EXTRACT_SORT_KEYS, get_item, update_item, delete_item, response, query_items, get_current_time, generate_presigned_url
from GoogleUtils.auth import refresh_google_token

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

DOCVAULTS_BUCKET = os.environ.get('DOCVAULTS_BUCKET')
FILES_TABLE = os.environ.get('FILES_TABLE')
EXTRACTED_FILES_TABLE = os.environ.get('EXTRACTED_FILES_TABLE')
TOKENS_TABLE = os.environ.get('TOKENS_TABLE')
ACCESS_TABLE = os.environ.get('ACCESS_TABLE')
DOCVAULTS_TABLE = os.environ.get('DOCVAULTS_TABLE')
USERS_TABLE = os.environ.get('USERS_TABLE')
SENDER_EMAIL = os.environ['SENDER_EMAIL']
EXPORT_QUEUE_URL = os.environ['EXPORT_QUEUE_URL']
MAX_RETRIES = 3
CLIENT_ID = json.loads(os.environ.get('DRIVE_CLIENT_ID'))
CLIENT_SECRET = json.loads(os.environ.get('DRIVE_CLIENT_SECRET'))
API_KEY = json.loads(os.environ.get('DRIVE_API_KEY'))
REDIRECT_URI = json.loads(os.environ.get('CALL_BACK_URL'))

FILE_NAME_INDEX = os.environ.get("EXTRACTED_FILES_TABLE_INDEX1")
CLASSIFICATION_NAME_INDEX = os.environ.get("EXTRACTED_FILES_TABLE_INDEX2")

S3_CLIENT = boto3.client('s3')
SES_CLIENT = boto3.client('ses')
DYNAMODB = boto3.resource('dynamodb')
SECRETS_CLIENT = boto3.client("secretsmanager")
SQS_CLIENT = boto3.client('sqs')
EXTRACTED_FILES_TABLE_RESOURCE = DYNAMODB.Table(EXTRACTED_FILES_TABLE)


HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Content-Type": "application/json"
}

def validate_access(docvault_id, username , file_names , file_type):
    """
    Validates whether the given user has access to the specified files in a DocVault.

    Parameters:
        docvault_id (str): The ID of the DocVault.
        username (str): The username of the user requesting access.
        file_names (list): A list of file names for which access is being requested.
        file_type (str): The type of files ("original" or "extracted").

    Returns:
        bool: True if the user has access to all specified files, False otherwise.
        dict (if error): Error response with HTTP status and message.
    """
    try:
        access = get_item(ACCESS_TABLE,key={'Username': username, 'DocVaultId': docvault_id})
        docvault = get_item(DOCVAULTS_TABLE,key={'DocVaultId': docvault_id})
        if not access and docvault.get('CreatedBy') != username:
            return False
        for file_name in file_names:
            file = {}
            if file_type == 'original':
                file = get_item(FILES_TABLE,key={'FileName': file_name, 'DocVaultId': docvault_id})
            elif file_type == 'extracted':
                file = get_item(EXTRACTED_FILES_TABLE,key={'ExtractedFileName': file_name, 'DocVaultId': docvault_id})
            if not file:
                LOGGER.error("In IDP-Files-Lambda.validate_access File %s not found in docvault %s", file_name, docvault_id)
                return response(404, {'error':f'File {file_name} not found'})
            if docvault.get('CreatedBy') != username and file.get('CreatedBy') != username:
                LOGGER.error("In IDP-FilesLambda.validate_access Access denied for file %s by user %s", file_name, username)
                return False
        return True
    except Exception as e:
        return response(400, {'error':str(e)})

def get_google_drive_credentials_with_refresh(username):
    """
    Retrieves Google Drive credentials for a user and refreshes the token if expired.

    Steps:
    1. Retrieves a reference to the token from the DynamoDB table based on the provided username.
    2. Uses the token reference to retrieve the full token details from AWS Secrets Manager.
    3. Checks whether the token is expired and refreshes it if necessary.
    4. Returns a valid `google.auth.credentials.Credentials` object.

    Args:
        username (str): Username for which the Google Drive credentials are to be retrieved.

    Returns:
        Credentials: A valid Google credentials object for API access.

    Raises:
        Exception: If no token is found or token refresh fails.
    """
    try:
        # 1. Get token reference from DynamoDB
        item = get_item(TOKENS_TABLE,key={'Username': username})
        if not item:
            raise Exception("No Google token found for user")
        # 2. Get actual tokens from Secrets Manager
        secret = SECRETS_CLIENT.get_secret_value(SecretId=item['SecretARN'])
        token_data = json.loads(secret['SecretString'])
        # LOGGER.info(f"Token data: {token_data}")

        # LOGGER.info(f"Creds: {CLIENT_ID} , {CLIENT_SECRET}")
        # 3. Check if token needs refresh
        # expires_at = datetime.fromisoformat(token_data.get('expires_at'))
        expires_at = datetime.fromisoformat(item.get('ExpiresAt'))
        if datetime.now() >= expires_at:
            LOGGER.info("Refreshing expired Google token for user: %s", username)
            token_data['access_token'] = refresh_google_token(item,token_data,CLIENT_ID,CLIENT_SECRET,TOKENS_TABLE)['access_token']
        # 4. Return credentials
        return Credentials(
            token=token_data['access_token'],
            refresh_token=token_data['refresh_token'],
            token_uri='https://oauth2.googleapis.com/token',
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET
        )
    except Exception as e:
        LOGGER.error("In IDP-Files-Lambda.get_gdrive_credentials_with_refresh Failed to get credentials for user %s: %s", username, str(e))
        raise

def get_valid_access_token(username):
    """
    Retrieve and validate the Google access token for a user.

    This function checks if a valid Google access token exists for the given username.
    If the token has expired, it refreshes the token and returns the new access token.

    Parameters:
        username (str): The username associated with the Google OAuth token.

    Returns:
        str: A valid Google access token.

    Raises:
        Exception: If no token is found for the specified user.
    """
    LOGGER.info("Retrieving access token for user: %s", username)

    item = get_item(TOKENS_TABLE,key={'Username': username})
    secret = SECRETS_CLIENT.get_secret_value(SecretId=item["SecretARN"])
    old_tokens = json.loads(secret['SecretString'])
    if not item:
        LOGGER.error("In IDP-Files-Lambda.get_valid_access_token , No token found for user: %s", username)
        raise Exception("No token found for user")
    if datetime.fromisoformat(item['ExpiresAt']) <= datetime.now():
        LOGGER.info("Token expired for user: %s, refreshing...", username)
        return refresh_google_token(item,old_tokens,CLIENT_ID,CLIENT_SECRET,TOKENS_TABLE)['access_token']

    LOGGER.info("Token valid for user: %s", username)
    secret = SECRETS_CLIENT.get_secret_value(SecretId=item["SecretARN"])
    tokens = json.loads(secret['SecretString'])
    return tokens['access_token']

def handle_download(docvault_id , file_names , file_type):
    """
    Generate pre-signed URLs for downloading a list of files from S3.

    Parameters:
        docvault_id (str): Identifier of the DocVault the files belong to.
        file_names (list): List of filenames to be downloaded.
        file_type (str): Type of the files, either 'original' or 'extracted'.

    Returns:
        dict: A response dict containing the HTTP status code, headers, and a JSON body 
              with pre-signed URLs for each file and their individual statuses.
    
    Raises:
        Exception: If an error occurs during URL generation or table retrieval.
    """
    try:
        LOGGER.info("Downloading file:%s" ,file_names)
        result = []
        for file_name in file_names:
            try:
                file_obj = None
                s3_key = f"final-{file_type}/{docvault_id}/{file_name}"
                if file_type == 'original':
                    file_obj = get_item(FILES_TABLE,key={'FileName': file_name, 'DocVaultId': docvault_id})
                elif file_type == 'extracted':
                    file_obj = get_item(EXTRACTED_FILES_TABLE,key={'ExtractedFileName': file_name, 'DocVaultId': docvault_id})

                if not file_obj:
                    raise Exception(f"File {file_name} not found")
                file_pre_signed_url = generate_presigned_url(DOCVAULTS_BUCKET, s3_key, 3600, 'get_object','application/json')
                result.append({"FileName":file_name,"FilePreSignedUrl":file_pre_signed_url , "Status" : "Success"})
            except Exception as e:
                LOGGER.error("In IDP-Files-Lambda.handle_download, Error generating preSignedUrl for %s : %s" , file_name , str(e))
                result.append({"FileName" : file_name , "FilePresignedUrl" : "" , "Status" : "Failed" , "Reason" : str(e)})
        return response(
            200,
            result
        )
    except Exception as e:
        LOGGER.error("In IDP-Files-Lambda.handle_download, Download failed:%s " , str(e))
        raise Exception(f"Download failed: {str(e)}")

def handle_export_to_drive(docvault_id, username, file_names , file_type , folder_id):
    """
        Handles file exports to Google Drive
        Parameters:
            docvault_id : identifier of the docvault to which the files belong
            filenames : list of file names to be exported
            folder_id : Folder to which the file goes
            file_type: Type of file(original/extracted)
            username: Unique identifier of the requester

        Returns:
            list: a list of file data(filename, upload status, drive id, drive url)
    """
    try:
        # Validate input
        if len(file_names) > 100:
            return response(
                400,
                {'error': 'Maximum 100 files per export request'}
            )
        # Queue each file for export
        for file_name in file_names:
            s3_key = f"final-{file_type}/{docvault_id}/{file_name}"
            SQS_CLIENT.send_message(
                QueueUrl=EXPORT_QUEUE_URL,
                MessageBody=json.dumps({
                    's3_key': s3_key,
                    'username': username,
                    'folder_id': folder_id,
                    'retry_count': 0
                })
            )
        return response(
            200,
            {
                'Message': f'{len(file_names)} files getting exported'
            }
        )
    except Exception as e:
        LOGGER.error("In IDP-Files-Lambda.handle_export_to_drive, Export initiation failed: %s" , str(e))
        return response(
            500,{'error': 'Export initialization failed'}
        )

def handle_sqs(records):
    """
    Process SQS messages for individual file exports to Google Drive.

    Each message in the SQS records contains the S3 key of the file to export, 
    the associated DocVault ID, the username of the requester, the retry count, 
    and the Google Drive folder ID. The function attempts to export the file to 
    the user's Google Drive. On success, the message is deleted from the queue. 
    If the export fails and retry attempts remain, the visibility timeout is extended.
    If retries are exhausted, the message is deleted and marked as failed.

    Args:
        records (list): A list of SQS message records.

    Returns:
        dict: A response containing HTTP status code, headers, and the result of each export attempt.
    """
    try:
        for record in records:
            message = json.loads(record['body'])
            s3_key = message['s3_key']
            username = message['username']
            retry_count = message['retry_count']
            folder_id = message['folder_id']
            results = []
            try:
                result = export_file_to_drive(s3_key, username , folder_id)
                results.append(result)
                if result['status'] == 'success':
                    SQS_CLIENT.delete_message(
                        QueueUrl=EXPORT_QUEUE_URL,
                        ReceiptHandle=record['receiptHandle']
                    )
            except Exception as e:
                LOGGER.error("In IDP-Files-Lamdba.handle_sqs, Export failed for %s : %s" , s3_key , str(e))
                if retry_count < MAX_RETRIES:
                    SQS_CLIENT.change_message_visibility(
                        QueueUrl=EXPORT_QUEUE_URL,
                        ReceiptHandle=record['receiptHandle'],
                        VisibilityTimeout=30 * (retry_count + 1)
                    )
                else:
                    SQS_CLIENT.delete_message(
                        QueueUrl=EXPORT_QUEUE_URL,
                        ReceiptHandle=record['receiptHandle']
                    )
                    results.append({
                        's3_key': s3_key,
                        'status': 'failed',
                        'error': str(e)
                    })
        return response(
            200,
            {'results': results}
        )
    except Exception as e:
        LOGGER.error("In IDP-Files-Lamda.handle_sqs, Export processing failed: %s" , str(e))
        raise

def export_file_to_drive(s3_key, username, folder_id):
    """
    Export a single file from S3 to Google Drive using streaming.

    This function:
    - Retrieves user credentials for Google Drive.
    - Fetches file metadata from S3.
    - Prepares Google Drive metadata.
    - Uploads the file to Google Drive using resumable upload for large files.

    Args:
        s3_key (str): The key of the file in the S3 bucket.
        docvault_id (str): The ID of the DocVault the file belongs to.
        username (str): The username of the authenticated user.
        folder_id (str): The ID of the destination folder in Google Drive.

    Returns:
        dict: A dictionary containing the upload status, S3 key, and Google Drive file ID and name.

    Raises:
        Exception: If any step in the process fails.
    """
    try:
        LOGGER.info("Starting export of %s to Google Drive" , s3_key)
        # 1. Get credentials
        creds = get_google_drive_credentials_with_refresh(username)
        service = build('drive', 'v3', credentials=creds)
        # 2. Get file metadata from S3
        s3_meta = S3_CLIENT.head_object(
            Bucket=DOCVAULTS_BUCKET,
            Key=s3_key
        )
        file_name = s3_meta['Metadata'].get('original-filename', os.path.basename(s3_key))
        content_type = s3_meta.get('ContentType', 'application/octet-stream')
        file_size = s3_meta['ContentLength']
        # 3. Prepare Google Drive file metadata
        if folder_id:
            folder = service.files().get(
                fileId=folder_id,
                fields='id,mimeType'
            ).execute()
            if folder.get('mimeType') != 'application/vnd.google-apps.folder':
                raise ValueError("Specified ID is not a folder")
        # Rest of your existing implementation...
        file_metadata = {
            'name': os.path.basename(s3_key),
            'mimeType': 'application/octet-stream'
        }
        # 4. Handle based on file size
        if file_size > 5 * 1024 * 1024:  # 5MB threshold for resumable upload
            LOGGER.info("Large file (%s bytes), using resumable upload" , file_size)
            # Create a BytesIO buffer for streaming
            file_buffer = io.BytesIO()
            # Download from S3 to memory buffer
            S3_CLIENT.download_fileobj(
                DOCVAULTS_BUCKET,
                s3_key,
                file_buffer
            )
            file_buffer.seek(0)
            # Create media upload
            media = MediaIoBaseUpload(
                file_buffer,
                mimetype=content_type,
                chunksize=5 * 1024 * 1024,
                resumable=True
            )
            # Execute upload
            request = service.files().create(
                body=file_metadata,
                media_body=media,
                fields='id,name,size'
            )
            chunk_response = None
            while chunk_response is None:
                status, chunk_response = request.next_chunk()
                if status:
                    LOGGER.info("Uploaded %s" , int(status.progress() * 100))
        else:
            LOGGER.info("Small file (%s bytes), using simple upload" , file_size)
            # Download file content directly
            file_obj = io.BytesIO()
            S3_CLIENT.download_fileobj(
                DOCVAULTS_BUCKET,
                s3_key,
                file_obj
            )
            file_obj.seek(0)
            media = MediaIoBaseUpload(
                file_obj,
                mimetype=content_type
            )
            file_creation_response = service.files().create(
                body=file_metadata,
                media_body=media,
                fields='id,name,size'
            ).execute()
        LOGGER.info("Successfully exported %s to Google Drive" , file_name)
        return {
            'status': 'success',
            's3_key': s3_key
        }
    except Exception as e:
        LOGGER.error("In IDP-Files-Lambda.export_file_to_drive, Export failed for %s : %s" , s3_key , str(e))
        raise Exception(f"Export failed: {str(e)}")

def send_email_with_attachments(recipient_email, subject, body, attachments):
    """
    Sends an email with attachments to the specified recipient.

    Parameters:
        recipient_email (str): Email address of the recipient.
        subject (str): Subject of the email.
        body (str): Body content of the email.
        attachments (list): List of tuples, each containing:
            - file_name (str): Name of the file attachment.
            - file_content (bytes): Content of the file.
            - mime_type (str): MIME type of the file.
    
    Raises:
        Exception: If the email fails to send.
    """
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = SENDER_EMAIL
    msg['To'] = recipient_email
    msg.attach(MIMEText(body, 'plain'))

    for file_name, file_content, mime_type in attachments:
        part = MIMEApplication(file_content)
        part.add_header('Content-Disposition', 'attachment', filename=file_name)
        part.add_header('Content-Type', mime_type)
        msg.attach(part)

    try:
        send_email_response = SES_CLIENT.send_raw_email(
            Source=SENDER_EMAIL,
            Destinations=[recipient_email],
            RawMessage={'Data': msg.as_string()}
        )
        LOGGER.info("Email sent! Message ID: %s" , send_email_response['MessageId'])
    except Exception as e:
        LOGGER.error("In IDP-Files-Lambda.send_email_with_attachments, Failed to send email: %s" , str(e))
        raise Exception(f"Failed to send email: {str(e)}")

def handle_send_to_email(docvault_id , file_names , recipient_email , file_type):
    """
        Handles email ingestion
        Parameters:
            docvault_id(str) : identifier of the docvault to which the files belong
            file_names(list) : list of names of the files to be exported

        Returns:
            list: list of names of the files that are exported
    """
    try:
        LOGGER.info("Handling send to email")
        attachments = []

        total_files = len(file_names)

        if total_files > 20:
            raise ValueError("Too many files. Maximum 5 files allowed.")

        results = []
        for file_name in file_names:
            try:
                file_obj = None
                if file_type == 'original':
                    file_obj = get_item(
                        FILES_TABLE,
                        key = {
                            "FileName" : file_name,
                            "DocVaultId" : docvault_id
                        }
                    )
                elif file_type == 'extracted':
                    file_obj = get_item(
                        EXTRACTED_FILES_TABLE,
                        key = {
                            "ExtractedFileName" : file_name,
                            "DocVaultId" : docvault_id
                        }
                    )

                if not file_obj:
                    raise Exception(f"File {file_name} not found")
                s3_key = f"final-{file_type}/{docvault_id}/{file_name}"
                s3_obj = S3_CLIENT.get_object(
                    Bucket=DOCVAULTS_BUCKET,
                    Key=s3_key
                )

                file_content = s3_obj['Body'].read()
                mime_type = s3_obj.get('ContentType', 'application/octet-stream')
                attachments.append((file_name, file_content, mime_type))

                LOGGER.info("Added %s to attachments" , file_name)
            except Exception as e:
                LOGGER.error("In IDP-Files-Lambda.handle_send_to_email, Failed to get %s from S3: %s" , file_name , str(e))
                results.append({
                    'file_name': file_name,
                    'status': 'failed',
                    'error': str(e)
                })
        try:
            if attachments:
                total_size = sum(len(file_content) for file_content, _, _ in attachments)
                if total_size > 20 * 1024 * 1024:
                    raise ValueError("Total attachments exceed 20MB limit")
                subject = f"Your documents from {docvault_id}"
                body = f"Please find attached {len(attachments)} document(s)."
                send_email_with_attachments(recipient_email, subject , body , attachments)
                return response(
                    200,
                    {
                        "FilesAttached" : [file_name for file_name, _, _ in attachments],
                        "FilesFailed" : results
                    }
                )
            else:
                return response(
                    404,
                    {
                        'message': 'No attachments found'
                    }
                )
        except Exception as e:
            LOGGER.error("In IDP-Files-Lambda.handle_send_to_email, Failed to send email: %s" , str(e))
            results.append({
                'file_name': " ",
                'status': 'failed',
                'error': str(e)
            })

    except Exception as e:
        LOGGER.error("In IDP-Files-Lamdba.handle_send_to_email, Error: %s", str(e))
        return response(
            500,
            {
                'error': f'Internal Server Error: {str(e)}'
            }
        )

def get_original_files_in_docvault(docvault_id, username):
    """
    Retrieve all original files from a specific docvault if the user has access.

    Args:
        docvault_id (str): The ID of the docvault to query
        username (str): Username of the requesting user

    Returns:
        dict: {
            "data": list of files (can be empty),
            "error": optional error message (str)
        }
    """
    try:
        LOGGER.info("In filesLambda.get_original_files_in_docvault, Getting original files in docvault %s", docvault_id)

        # Check access
        resp =query_items(
            DOCVAULTS_TABLE,
            key_condition_expression=Key('DocVaultId').eq(docvault_id)
        )
        if not resp:
            LOGGER.warning("In filesLambda.get_original_files_in_docvault, Docvault %s does not exist", docvault_id)
            return response(404, {"error": "Docvault does not exist."})
        if username != resp[0].get("CreatedBy"):
            LOGGER.info("In filesLambda.get_original_files_in_docvault, User %s is not the owner of docvault %s", username, docvault_id)
            access_response = query_items(
                ACCESS_TABLE,
                key_condition_expression=Key('Username').eq(str(username)) & Key('DocVaultId').eq(str(docvault_id))
            )
            if not access_response:
                LOGGER.warning("In filesLambda.get_original_files_in_docvault, Access denied: User %s does not have access to DocVault %s", username, docvault_id)
                return response(403,{"error": "Access denied. You do not have permission to view this DocVault."})
        

        # Fetch files
        resp = query_items(
            FILES_TABLE,
            key_condition_expression=Key('DocVaultId').eq(docvault_id)
        )

        files = [{
            'FileName': item.get('FileName'),
            'CreatedBy': item.get('CreatedBy'),
            'CreatedAt': item.get('CreatedAt'),
            'LastModifiedBy': item.get('LastModifiedBy'),
            'LastModifiedAt': item.get('LastModifiedAt'),
            'ExtractStatus': item.get('ExtractStatus'),
            'Message': item.get('Message'),
            'UploadStatus': item.get('UploadStatus'),
            'Source': item.get('Source')
        } for item in resp]

        return files

    except Exception as error:
        LOGGER.error("In filesLambda.get_original_files_in_docvault, Error getting original files in docvault %s: %s", docvault_id, error)
        return response(500,{"error": str(error)})


def get_extracted_files_in_docvault(docvault_id,username):
    """
    Retrieve all extracted files from a specific docvault.
    
    Args:
        docvault_id (str): The ID of the docvault to query
        
    Returns:
        list: List of dictionaries containing extracted file metadata or error response
    """
    LOGGER.info("In filesLambda.get_extracted_files_in_docvault, Getting extracted files in docvault %s", docvault_id)

    try:
        # Check access
        resp =query_items(
            DOCVAULTS_TABLE,
            key_condition_expression=Key('DocVaultId').eq(docvault_id)
        )
        if not resp:
            LOGGER.warning("In filesLambda.get_extracted_files_in_docvault, Docvault %s does not exist", docvault_id)
            return response(404, {"error": "Docvault does not exist."})
        if username != resp[0].get("CreatedBy"):
            LOGGER.info("In filesLambda.get_extracted_files_in_docvault, User %s is not the owner of docvault %s", username, docvault_id)
            access_response = query_items(
                ACCESS_TABLE,
                key_condition_expression=Key('Username').eq(str(username)) & Key('DocVaultId').eq(str(docvault_id))
            )
            if not access_response:
                LOGGER.warning("In filesLambda.get_extracted_files_in_docvault, Access denied: User %s does not have access to DocVault %s", username, docvault_id)
                return response(403, {"error": "Access denied. You do not have permission to view this DocVault."})

        # Fetch files
        resp = query_items(
            EXTRACTED_FILES_TABLE,
            key_condition_expression=Key('DocVaultId').eq(docvault_id)
        )
        
        files = [{
            'ExtractedFileName': item.get('ExtractedFileName'),
            'FileName': item.get('FileName'),
            'CreatedBy': item.get('CreatedBy'),
            'CreatedAt': item.get('CreatedAt'),
            'LastModifiedBy': item.get('LastModifiedBy'),
            'LastModifiedAt': item.get('LastModifiedAt'),
            'ClassificationName': item.get('ClassificationName'),
            'LowConfidenceFlag': item.get('LowConfidenceFlag',False),
            'FraudFlag': item.get('FraudFlag', False),
            'FraudMessage': item.get('FraudMessage',{})
        } for item in resp]

        return files
        
    except Exception as error:
        LOGGER.error("In filesLambda.get_extracted_files_in_docvault, Error getting extracted files in docvault %s: %s", docvault_id, error)
        return response(500, {"error": str(error)})

def get_file_of_classification(docvault_id, classification_name,username):
    """
    Retrieve extracted files of a specific classification from a docvault.
    
    Args:
        docvault_id (str): The ID of the docvault
        classification_name (str): The classification name to filter by
        
    Returns:
        list: List of dictionaries containing file metadata with extracted data or error response
    """
    LOGGER.info("In filesLambda.get_file_of_classification, Getting extracted files of classification %s in docvault %s", classification_name, docvault_id)

    try:
        # Check access
        resp =query_items(
            DOCVAULTS_TABLE,
            key_condition_expression=Key('DocVaultId').eq(docvault_id)
        )
        if not resp:
            LOGGER.warning("In filesLambda.get_file_of_classification, Docvault %s does not exist", docvault_id)
            return response(404,{"Error": "Docvault does not exist."})
        if username != resp[0].get("CreatedBy"):
            LOGGER.info("In filesLambda.get_file_of_classification, User %s is not the owner of docvault %s", username, docvault_id)
            return response (403, {"Error": "Access denied. You do not have permission to view a particular classification."})

        #fetch files
        resp = query_items(
            EXTRACTED_FILES_TABLE,
            index_name=CLASSIFICATION_NAME_INDEX,
            key_condition_expression=Key('DocVaultId').eq(docvault_id) & 
                                 Key('ClassificationName').eq(classification_name)
        )
        
        files = []
        for item in resp:
            extracted_fields = get_extracted_data(docvault_id, item.get('FileName'))
            files.append({
                'ExtractedFileName': item.get('ExtractedFileName'),
                'FileName': item.get('FileName'),
                'CreatedBy': item.get('CreatedBy'),
                'CreatedAt': item.get('CreatedAt'),
                'LastModifiedBy': item.get('LastModifiedBy'),
                'LastModifiedAt': item.get('LastModifiedAt'),
                'ExtractedFields': extracted_fields if extracted_fields else []
            })

        return files

    except Exception as error:
        LOGGER.error("In filesLambda.get_file_of_classification, Error getting extracted files of classification %s in docvault %s: %s", classification_name, docvault_id, error)
        return response(500,{"Error": str(error)})


def delete_files(docvault_id, file_names, file_type, username):
    """
    Delete files (original or extracted) from a docvault.
    
    Args:
        docvault_id (str): The ID of the docvault
        file_names (list): List of file names to delete
        file_type (str): Type of files to delete ('original' or 'extracted')
        username (str): Username of the user attempting the deletion
        
    Returns:
        dict: Status of the operation or error response
    """
    LOGGER.info("In filesLambda.delete_files, User %s attempting to delete files %s in docvault %s", 
               username, file_names, docvault_id)
    
    try:
        # check if the docvault exists and get owner info
        docvault_response = query_items(
            DOCVAULTS_TABLE,
            key_condition_expression=Key('DocVaultId').eq(docvault_id)
        )
        if not docvault_response or not isinstance(docvault_response, list) or len(docvault_response) == 0:
            LOGGER.warning("In filesLambda.delete_files, Docvault %s does not exist", docvault_id)
            return response(404, {'Error': 'Docvault does not exist'})
        
        # Assuming query_items returns a list, take the first item
        docvault_item = docvault_response[0]
        docvault_owner = docvault_item.get('CreatedBy')
        is_owner = (username == docvault_owner)
        
        if file_type not in ['original', 'extracted']:
            LOGGER.error("In filesLambda.delete_files, Invalid file type: %s", file_type)
            return response(400, {"Error": "Invalid file type"})

        for file_name in file_names:
            if file_type == 'original':
                # First check if user has permission to delete this original file
                file_response = get_item(
                    FILES_TABLE,
                    key={'DocVaultId': docvault_id, 'FileName': file_name})
                
                if not file_response:
                    LOGGER.warning("In filesLambda.delete_files, Original file %s not found in docvault %s", 
                                  file_name, docvault_id)
                    return response(404, {"Error": f"{file_name} not found in the current docvault"})
                
                file_creator = file_response.get('CreatedBy')
                
                # Only owner can delete original files not created by them
                if not is_owner and file_creator != username:
                    LOGGER.warning("In filesLambda.delete_files, User %s not authorized to delete original file %s", 
                                 username, file_name)
                    return response(403, {"Error": "You can only delete files you uploaded"})
                
                # Delete all extracted files related to the original file
                extracted_items = query_items(
                    EXTRACTED_FILES_TABLE,
                    index_name=FILE_NAME_INDEX,
                    key_condition_expression=Key('DocVaultId').eq(docvault_id) & 
                                      Key('FileName').eq(file_name)
                )
                
                if extracted_items and isinstance(extracted_items, list):
                    LOGGER.info("In filesLambda.delete_files, Found %d extracted files for %s", 
                              len(extracted_items), file_name)

                    # Batch delete extracted files
                    with EXTRACTED_FILES_TABLE_RESOURCE.batch_writer() as batch:
                        for item in extracted_items:
                            try:
                                # For extracted files, check creator if user is not owner
                                if not is_owner and item.get('CreatedBy') != username:
                                    LOGGER.warning("In filesLambda.delete_files, User %s not authorized to delete extracted file %s", 
                                                 username, item.get('ExtractedFileName'))
                                    continue
                                    
                                batch.delete_item(
                                    Key={
                                        'DocVaultId': item.get('DocVaultId'),
                                        'ExtractedFileName': item.get('ExtractedFileName')
                                    }
                                )
                                S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f'final-extracted/{docvault_id}/{item.get("ExtractedFileName")}')
                                S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f'pii/{docvault_id}/pii_{item.get("ExtractedFileName")}')
                                S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f'final-extracted/{docvault_id}/{item.get("ExtractedFileName")}.metadata.json')
                                LOGGER.info("In filesLambda.delete_files, Extracted file %s deleted successfully", 
                                          item.get('ExtractedFileName'))
                            except Exception as error:
                                LOGGER.error("In filesLambda.delete_files, Error deleting extracted file %s in docvault %s: %s", 
                                            item.get('ExtractedFileName'), docvault_id, error)

                # Delete from raw files table and S3
                delete_item(FILES_TABLE, key={'DocVaultId': docvault_id, 'FileName': file_name})
                S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f'original/{docvault_id}/{file_name}')
                LOGGER.info("In filesLambda.delete_files, Original file %s deleted successfully", file_name)
                
            elif file_type == 'extracted':
                # Check extracted file details and creator
                extracted_response = get_item(
                    EXTRACTED_FILES_TABLE,
                    key={'DocVaultId': docvault_id, 'ExtractedFileName': file_name})
                
                if not extracted_response:
                    LOGGER.warning("In filesLambda.delete_files, Extracted file %s not found in docvault %s", 
                                 file_name, docvault_id)
                    return response(404, {"Error": f"{file_name} not found in the current docvault"})

                extracted_creator = extracted_response.get('CreatedBy')
                
                # Only owner can delete extracted files not created by them
                if not is_owner and extracted_creator != username:
                    LOGGER.warning("In filesLambda.delete_files, User %s not authorized to delete extracted file %s",
                                 username, file_name)
                    return response(403, {"Error": "You can only delete extracted files you created"})

                # Delete from extracted files table and S3
                delete_item(EXTRACTED_FILES_TABLE, key={'DocVaultId': docvault_id, 'ExtractedFileName': file_name})
                S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f'final-extracted/{docvault_id}/{file_name}')
                S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f'pii/{docvault_id}/pii_{file_name}')
                S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f'final-extracted/{docvault_id}/{file_name}.metadata.json')
                LOGGER.info("In filesLambda.delete_files, Extracted file %s deleted successfully", file_name)

                # Update the parent file status
                parent_file_name = extracted_response.get('FileName')
                if parent_file_name:
                    update_item(
                        FILES_TABLE,
                        key={'DocVaultId': docvault_id, 'FileName': parent_file_name},
                        update_expression='SET LastModifiedBy = :un, LastModifiedAt = :tm, ExtractStatus = :status',
                        expression_attributes={
                            ':un': username, 
                            ':tm': datetime.utcnow().isoformat(), 
                            ':status': 'Unprocessed'
                        }
                    )

        return response(200, {'Message': 'Files deleted successfully'})

    except Exception as error:
        LOGGER.error("In filesLambda.delete_files, Error deleting files %s in docvault %s: %s",
                   file_names, docvault_id, str(error))
        return response(500, {"Error": str(error)})

def get_extracted_data(docvault_id, file_name):
    """
    Retrieve and flatten extracted data from S3 for a specific file using dot notation in keys.
    Returns just the array of extracted fields without HTTP response wrapping.
    """
    try:
        LOGGER.info("In filesLambda.get_extracted_data, Getting extracted data for %s in docvault %s", file_name, docvault_id)

        # Check original file existence
        file_response = get_item(
            FILES_TABLE,
            key={'DocVaultId': docvault_id, 'FileName': file_name}
        )
        if not file_response:
            return None  # Or empty list if preferred

        # Check extracted file existence
        resp = query_items(
            EXTRACTED_FILES_TABLE,
            index_name=FILE_NAME_INDEX,
            key_condition_expression=Key('DocVaultId').eq(docvault_id) & Key('FileName').eq(file_name)
        )

        items = resp
        if not items:
            return None

        item = items[0]
        s3_location = item.get('ExtractionS3Location')
        if not s3_location:
            return None

        # Parse S3 location
        s3_response = S3_CLIENT.get_object(Bucket=DOCVAULTS_BUCKET, Key=s3_location)
        extracted_data = json.loads(s3_response['Body'].read().decode('utf-8'))

        result = []

        # Add classification field
        classification = extracted_data.get("document_summary", {}).get("classification")
        if classification:
            result.append({
                "key": "Classification",
                "value": classification,
                "confidence": extracted_data.get("document_summary", {}).get("classification_confidence", 1.0),
                "pii_detected": False,
                "pii_types": []
            })

        def flatten_fields(prefix, fields):
            flat = []
            for k, v in fields.items():
                key = f"{prefix}.{k}" if prefix else k
                if isinstance(v, dict) and "value" in v:
                    flat.append({
                        "key": key,
                        "value": v.get("value"),
                        "confidence": v.get("confidence", 1.0),
                        "pii_detected": v.get("pii_detected", False),
                        "pii_types": [key.lower()] if v.get("pii_detected", False) else []
                    })
                elif isinstance(v, dict):
                    flat.extend(flatten_fields(key, v))  # Recurse
            return flat

        compared_data = extracted_data.get("compared_data", {})
        result.extend(flatten_fields("", compared_data))

        return result

    except Exception as error:
        LOGGER.error("In filesLambda.get_extracted_data, Error in get_extracted_data: %s", str(error))
        return None




def get_extracted_data_using_key(s3_key):
    """
    Retrieve extracted data directly from an S3 key.
    
    Args:
        s3_key (str): The S3 key pointing to the extracted data JSON file
        
    Returns:
        dict: Dictionary containing classification and compared data or error response
    """
    try:
        # Get data from S3
        LOGGER.info("In filesLambda.get_extracted_data_using_key, extracted data for %s", s3_key)
        s3_response = S3_CLIENT.get_object(Bucket=DOCVAULTS_BUCKET, Key=s3_key)
        data = json.loads(s3_response['Body'].read().decode('utf-8'))

        # Extract the required information from the new format
        if isinstance(data, dict):
            response_data = {
                "classification": data.get("document_summary", {}).get("classification"),
                "compared_data": data.get("compared_data", {})
            }
            return response_data

        # If not in expected format, return empty dict
        LOGGER.error("In filesLambda.get_extracted_data_using_key, Unexpected data format in S3")
        return {}

    except Exception as error:
        LOGGER.error("In filesLambda.get_extracted_data_using_key, Error retrieving extracted fields from S3: %s", str(error))
        return {}

def get_specific_file(docvault_id, file_name, file_type, username):
    """
    Retrieve specific file information with authorization checks.
    
    Authorization Rules:
    - For original files: Only file uploader or docvault owner can access
    - For extracted files:
      - Owner or file creator gets full access (original URL + extracted fields)
      - All others get only PII-redacted extracted fields
    
    Args:
        docvault_id (str): The ID of the docvault
        file_name (str): The name of the file to retrieve
        file_type (str): Type of file ('original' or 'extracted')
        username (str): Username of the requesting user
        
    Returns:
        dict: File information with appropriate access or error response
    """
    LOGGER.info("In filesLambda.get_specific_file, User %s requesting file %s in docvault %s (type: %s)", username, file_name, docvault_id, file_type)
    try:
        if file_type not in ['original', 'extracted']:
            return response(400,{'Error': 'Invalid file type'})

        # Get docvault info to check ownership
        docvault_response = get_item(
            DOCVAULTS_TABLE,
            key={'DocVaultId': docvault_id}
        )
        if not docvault_response:
            LOGGER.warning("In filesLambda.get_specific_file, Docvault %s not found", docvault_id)
            return response(404,{'Error': 'Docvault not found'})

        docvault_owner = docvault_response['CreatedBy']
        is_owner = (username == docvault_owner)

        if not is_owner:
            LOGGER.info("In filesLambda.get_specific_file, User %s is not the owner of docvault %s", username, docvault_id)
            access_response = query_items(
                ACCESS_TABLE,
                key_condition_expression=Key('Username').eq(str(username)) & Key('DocVaultId').eq(str(docvault_id))
            )
            if not access_response:
                LOGGER.warning("In filesLambda.get_specific_file, Access denied: User %s does not have access to DocVault %s", username, docvault_id)
                return response(403,{'Error': 'Access denied to the DocVault'})

        # Prepare result structure
        result = {
            'FileName': file_name,
            'OriginalFilePresignedUrl': None,
            'ExtractedFields': {'Message': 'No extracted data available'},
            # Aditya's Change
            'CreatedBy': None
        }

        # Handle original files
        if file_type == 'original':
            # Check if original file exists
            file_response = get_item(
                FILES_TABLE,
                key={'DocVaultId': docvault_id, 'FileName': file_name}
            )
            if not file_response:
                LOGGER.warning("In filesLambda.get_specific_file, Original file %s not found", file_name)
                return response(404,{'Error': 'Original file not found'})

            # Authorization check for original files
            file_creator = file_response.get('CreatedBy')
            if not is_owner and username != file_creator:
                LOGGER.warning("In filesLambda.get_specific_file, User %s not authorized to access original file %s", username, file_name)
                return response(403,{'Error': 'Access denied to original file'})
            # Aditya's change
            result['CreatedBy'] = file_creator
            result['OriginalFileName'] = file_name

            # Generate presigned URL for original file
            original_key = f"original/{docvault_id}/{file_name}"
            try:
                S3_CLIENT.head_object(Bucket=DOCVAULTS_BUCKET, Key=original_key)
                result['OriginalFilePresignedUrl'] = S3_CLIENT.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': DOCVAULTS_BUCKET, 'Key': original_key},
                    ExpiresIn=3600
                )
            except Exception as error:
                LOGGER.error("In filesLambda.get_specific_file, Error generating presigned URL: %s", error)

            # Get extracted data for original file (if exists)
            extracted_response = query_items(
                EXTRACTED_FILES_TABLE,
                index_name=FILE_NAME_INDEX,
                key_condition_expression=Key('DocVaultId').eq(docvault_id) &
                                     Key('FileName').eq(file_name)
            )
            if extracted_response:
                extracted_item = extracted_response[0]
                s3_key = extracted_item.get('ExtractionS3Location')
                if s3_key:
                    extracted_data = get_extracted_data_using_key(s3_key)
                    if extracted_data:
                        result['ExtractedFields'] = extracted_data

        # Handle extracted files
        else:
            # Check if extracted file exists
            extracted_response = get_item(
                EXTRACTED_FILES_TABLE,
                key={'DocVaultId': docvault_id, 'ExtractedFileName': file_name}
            )
            if not extracted_response:
                LOGGER.warning("In filesLambda.get_specific_file, Extracted file %s not found", file_name)
                return response(
                    404,
                    {'Error': 'Extracted file not found'}
                )

            extracted_item = extracted_response
            extracted_creator = extracted_item.get('CreatedBy')
            is_creator = (username == extracted_creator)
            original_file_name = extracted_item.get('FileName')


            # Full access for owner or creator
            if is_owner or is_creator:
                # Generate presigned URL for original file
                if original_file_name:
                    result['OriginalFileName'] = original_file_name
                    LOGGER.info("In filesLambda.get_specific_file, Original file name: %s", original_file_name)
                    original_key = f"original/{docvault_id}/{original_file_name}"
                    try:
                        S3_CLIENT.head_object(Bucket=DOCVAULTS_BUCKET, Key=original_key)
                        result['OriginalFilePresignedUrl'] = S3_CLIENT.generate_presigned_url(
                            'get_object',
                            Params={'Bucket': DOCVAULTS_BUCKET, 'Key': original_key},
                            ExpiresIn=3600
                        )
                    except Exception as error:
                        LOGGER.error("In filesLambda.get_specific_file, Error generating presigned URL: %s", error)

                # Get full extracted data
                s3_key = extracted_item.get('ExtractionS3Location')
                if s3_key:
                    extracted_data = get_extracted_data_using_key(s3_key)
                    if extracted_data:
                        result['ExtractedFields'] = extracted_data
            else:
                # For others, get only PII-redacted extracted fields
                pii_key = f"pii/{docvault_id}/pii_{file_name}"
                try:
                    s3_response = S3_CLIENT.get_object(Bucket=DOCVAULTS_BUCKET, Key=pii_key)
                    extracted_data = json.loads(s3_response['Body'].read().decode('utf-8'))
                    result['ExtractedFields'] = extracted_data
                except Exception as error:
                    LOGGER.error("In filesLambda.get_specific_file, Error getting PII-redacted data: %s", error)
                    result['ExtractedFields'] = {'Message': 'PII-redacted data not available'}
        LOGGER.info("In filesLambda.get_specific_file, result: %s", result)
        return response(
            200,
            result
        )

    except Exception as error:
        LOGGER.error("In filesLambda.get_specific_file, Error in get_specific_file: %s", str(error))
        return response(
            500,
            {'Error': str(error)}
        )


def edit_extracted_fields(docvault_id, file_name, file_type, updates, username):
    """
    Edit values of extracted fields in a structured nested JSON (dot notation supported).
    Applies changes to both original and PII-redacted versions, if available.
    """
    LOGGER.info("In filesLambda.edit_extracted_fields, User %s editing extracted fields for %s in docvault %s", username, file_name, docvault_id)

    def update_nested_value(data, key_path, new_value):
        """
        Update a nested field in a dict using dot notation with array indices.
        Example: 'notes.points[3]' will access data['notes']['points'][3]['value']
        """
        parts = re.split(r'\.(?![^\[]*\])', key_path)  # split on dot, except inside brackets
        d = data
        for part in parts[:-1]:
            array_match = re.match(r'(\w+)\[(\d+)\]', part)
            if array_match:
                key, index = array_match.groups()
                d = d.get(key, [])
                if isinstance(d, list) and len(d) > int(index):
                    d = d[int(index)]
                else:
                    return False
            else:
                d = d.get(part, {})
                if not isinstance(d, dict):
                    return False

        final_part = parts[-1]
        array_match = re.match(r'(\w+)\[(\d+)\]', final_part)
        if array_match:
            key, index = array_match.groups()
            d = d.get(key, [])
            if isinstance(d, list) and len(d) > int(index):
                d[int(index)]['value'] = new_value
                return True
        else:
            if final_part in d and isinstance(d[final_part], dict):
                d[final_part]['value'] = new_value
                return True

        return False

    def get_pii_mapping(compared_data, parent_key=''):
        """
        Recursively builds a map of all keys (including array indices) to their `pii_detected` status.
        """
        mapping = {}
        for k, v in compared_data.items():
            full_key = f"{parent_key}.{k}" if parent_key else k
            if isinstance(v, dict):
                if 'value' in v:
                    mapping[full_key] = v.get('pii_detected', False)
                else:
                    mapping.update(get_pii_mapping(v, full_key))
            elif isinstance(v, list):
                for idx, item in enumerate(v):
                    item_key = f"{full_key}[{idx}]"
                    if isinstance(item, dict) and 'value' in item:
                        mapping[item_key] = item.get('pii_detected', False)
                    elif isinstance(item, dict):
                        mapping.update(get_pii_mapping(item, item_key))
        return mapping


    try:
        if file_type not in ['original', 'extracted']:
            return response(
                400,
                {'Error': 'Invalid file type'}
            )

        docvault_response = get_item(DOCVAULTS_TABLE,key={'DocVaultId': docvault_id})
        if not docvault_response:
            return response(
                404,
                {'Error': 'Docvault not found'}
            )

        docvault_owner = docvault_response['CreatedBy']
        is_owner = (username == docvault_owner)

        if file_type == 'original':
            items = query_items(
                EXTRACTED_FILES_TABLE,
                index_name=FILE_NAME_INDEX,
                key_condition_expression=Key('DocVaultId').eq(docvault_id) & Key('FileName').eq(file_name)
            )
            if not items:
                return response(
                    404,
                    {'Error': 'No extracted files found for this original file'}
                )
            extracted_file_name = items[0]['ExtractedFileName']
        else:
            extracted_file_name = file_name

        extracted_response = get_item(
            EXTRACTED_FILES_TABLE,
            key={'DocVaultId': docvault_id, 'ExtractedFileName': extracted_file_name}
        )
        if not extracted_response:
            return response(
                404,
                {'Error': 'Extracted file not found'}
            )

        extracted_item = extracted_response
        extracted_creator = extracted_item.get('CreatedBy')
        if not is_owner and username != extracted_creator:
            return response(
                403,
                {'Error': 'Only owner or file creator can edit'}
            )

        s3_location = extracted_item['ExtractionS3Location']
        pii_key = f"pii/{docvault_id}/pii_{file_name}"

        original_data = json.loads(S3_CLIENT.get_object(Bucket=DOCVAULTS_BUCKET, Key=s3_location)['Body'].read().decode('utf-8'))
        pii_data = None
        try:
            pii_data = json.loads(S3_CLIENT.get_object(Bucket=DOCVAULTS_BUCKET, Key=pii_key)['Body'].read().decode('utf-8'))
        except Exception as e:
            LOGGER.info("In filesLambda.edit_extracted_fields, No PII-redacted version available: %s", str(e))

        if 'compared_data' not in original_data:
            return response(
                500,
                {'Error': 'Invalid structure in original data'}
            )

        pii_map = get_pii_mapping(original_data['compared_data'])
        update_count = 0

        for update in updates:
            key_to_update = update.get('key')
            new_value = update.get('value')
            if not key_to_update or new_value is None:
                continue

            if update_nested_value(original_data['compared_data'], key_to_update, new_value):
                update_count += 1

            if pii_data and not pii_map.get(key_to_update, True):
                update_nested_value(pii_data['compared_data'], key_to_update, new_value)

        if update_count == 0:
            return response(
                400,
                {'Error': 'No valid fields were updated'}
            )

        S3_CLIENT.put_object(
            Bucket=DOCVAULTS_BUCKET,
            Key=s3_location,
            Body=json.dumps(original_data),
            ContentType='application/json'
        )

        if pii_data:
            S3_CLIENT.put_object(
                Bucket=DOCVAULTS_BUCKET,
                Key=pii_key,
                Body=json.dumps(pii_data),
                ContentType='application/json'
            )

        update_item(
            EXTRACTED_FILES_TABLE,
            key={'DocVaultId': docvault_id, 'ExtractedFileName': extracted_file_name},
            update_expression='SET LastModifiedBy = :un, LastModifiedAt = :tm',
            expression_attributes={':un': username, ':tm' : datetime.utcnow().isoformat()}
        )

        LOGGER.info("In filesLambda.edit_extracted_fields, Successfully updated %s fields in %s", update_count, extracted_file_name)
        return response(
            200,
            {'Message': f'Successfully updated {update_count} fields'}
        )

    except Exception as error:
        LOGGER.error("In filesLambda.edit_extracted_fields, Error updating extracted fields for %s: %s", file_name, str(error))
        return response(
            500,
            {'Error': str(error)}
        )

def select_key_versions(docvault_id, file_name, file_type, username, selections):
    """
    Select which key versions to use (either bda or model) in case of a mismatch between model and bda
    """
    LOGGER.info("In filesLambda.select_key_versions, User %s selecting key versions for %s in docvault %s", username, file_name, docvault_id)
    try:
        if file_type not in ['original', 'extracted']:
            return response(
                400,
                {'Error': 'Invalid file type'}
            )

        docvault_response = get_item(DOCVAULTS_TABLE,key={'DocVaultId': docvault_id})
        if not docvault_response:
            return response(
                404,
                {'Error': 'Docvault not found'}
            )

        docvault_owner = docvault_response['CreatedBy']
        is_owner = (username == docvault_owner)

        if file_type == 'original':
            resp = query_items(
                EXTRACTED_FILES_TABLE,
                index_name=FILE_NAME_INDEX,
                key_condition_expression=Key('DocVaultId').eq(docvault_id) & Key('FileName').eq(file_name)
            )
            items = resp
            if not items:
                return response(
                    404,
                    {'Error': 'No extracted files found for this original file'}
                )
            extracted_file_name = items[0]['ExtractedFileName']
        else:
            extracted_file_name = file_name

        extracted_response = get_item(
            EXTRACTED_FILES_TABLE,
            key={'DocVaultId': docvault_id, 'ExtractedFileName': extracted_file_name}
        )
        if not extracted_response:
            return response(
                404,
                {'Error': 'Extracted file not found'}
            )

        extracted_item = extracted_response
        extracted_creator = extracted_item.get('CreatedBy')
        if not is_owner and username != extracted_creator:
            return response(
                403,
                {'Error': 'Only owner or file creator can edit'}
            )

        s3_location = extracted_item['ExtractionS3Location']
        pii_key = f"pii/{docvault_id}/pii_{file_name}"

        original_data = json.loads(S3_CLIENT.get_object(Bucket=DOCVAULTS_BUCKET, Key=s3_location)['Body'].read().decode('utf-8'))
        pii_data = None
        try:
            pii_data = json.loads(S3_CLIENT.get_object(Bucket=DOCVAULTS_BUCKET, Key=pii_key)['Body'].read().decode('utf-8'))
        except Exception as e:
            LOGGER.info("In filesLambda.select_key_versions, No PII-redacted version available: %s", str(e))

        if 'compared_data' not in original_data:
            return response(
                500,
                {'Error': 'Invalid structure in original data'}
            )

        def apply_selection(data, dotted_key, selected_version):
            keys = dotted_key.split('.')
            current = data
            for k in keys[:-1]:
                if k not in current or not isinstance(current[k], dict):
                    return
                current = current[k]

            final_key = keys[-1]
            if final_key not in current or not isinstance(current[final_key], dict):
                return

            selected_data = current[final_key].get(selected_version)
            if not selected_data:
                return

            # Replace with selected version data
            current[final_key] = selected_data


        update_count = 0
        for selection in selections:
            key = selection.get("key")
            selected_version = selection.get("selected_version")
            if not key or selected_version not in ["bda", "model"]:
                continue

            before = json.dumps(original_data['compared_data'])
            apply_selection(original_data['compared_data'], key, selected_version)
            if pii_data and 'compared_data' in pii_data:
                apply_selection(pii_data['compared_data'], key, selected_version)

            after = json.dumps(original_data['compared_data'])
            if before != after:
                update_count += 1

        S3_CLIENT.put_object(
            Bucket=DOCVAULTS_BUCKET,
            Key=s3_location,
            Body=json.dumps(original_data),
            ContentType='application/json'
        )

        if pii_data:
            S3_CLIENT.put_object(
                Bucket=DOCVAULTS_BUCKET,
                Key=pii_key,
                Body=json.dumps(pii_data),
                ContentType='application/json'
            )

        update_item(
            EXTRACTED_FILES_TABLE,
            key={'DocVaultId': docvault_id, 'ExtractedFileName': extracted_file_name},
            update_expression='SET LastModifiedBy = :un, LastModifiedAt = :tm',
            expression_attributes={':un': username, ':tm' : datetime.utcnow().isoformat()}
        )

        LOGGER.info("In filesLambda.select_key_versions, Successfully updated %s fields in %s", update_count, extracted_file_name)
        return response(
            200,
            {'Message': f'Successfully updated {update_count} fields'}
        )

    except Exception as e:
        LOGGER.error("In filesLambda.select_key_versions, Error in select_key_versions: %s", str(e))
        return response(
            500,
            {'Error': f'Unexpected error occurred: {str(e)}'}
        )


def unflag_file(docvault_id, file_name,username):
    """
    Unflags a file within a docvault, specifically removing the 'LowConfidenceFlag'.
    Only the docvault owner or the original file uploader can unflag a file.
    The function checks if the file exists, if it's currently flagged, and then updates its status.

    Args:
        docvault_id (str): The unique identifier of the docvault.
        file_name (str): The name of the extracted file to unflag.
        username (str): The username of the user attempting to unflag the file.

    Returns:
        A dictionary containing the HTTP status code, headers, and a JSON body
        indicating success or the specific error encountered.
    """
    LOGGER.info(f"In IDPFilesLambda.unflag_file, Unflagging file: {file_name} in docvault: {docvault_id}")
    #checking if the extracted file exists
    try:
        extracted_file=get_item(EXTRACTED_FILES_TABLE,key={'DocVaultId':docvault_id,'ExtractedFileName':file_name})
    except Exception as e:
        return response(500, {"Error":f"Error in fetching extracted file: {e}"})
    if not extracted_file:
        return response(404, {"Error":"Extracted file not found"})

    original_file_name=extracted_file.get('FileName')
    LOGGER.info(f"In IDPFilesLambda.unflag_file, Original file name: {original_file_name}")

    original_file_uploader=get_item(FILES_TABLE, key={'DocVaultId':docvault_id,'FileName':original_file_name}).get('CreatedBy')
    LOGGER.info(f"In IDPFilesLambda.unflag_file, Original file uploader: {original_file_uploader}")

    #only docvault owner and document uploader can unflag the file
    docvault_owner=get_item(DOCVAULTS_TABLE, {'DocVaultId':docvault_id}).get('CreatedBy')
    LOGGER.info(f"In IDPFilesLambda.unflag_file, Docvault owner: {docvault_owner}")

    if docvault_owner==username or original_file_uploader==username:
        #check if the file is flagged for lowconfidence
        if not extracted_file.get('LowConfidenceFlag'):
            return response(400, {"Error":"File is unflagged already or not flagged in the first place to unflag now"})

        update_expression = "SET LastModifedBy = :last_modified_by, LastModifiedAt = :last_modified_at, LowConfidenceFlag = :is_low_confidence"
        expression_values = {':is_low_confidence': False,
                        ':last_modified_at': get_current_time(),
                        ':last_modified_by': username
                    }
        try:
            update_item(EXTRACTED_FILES_TABLE,key={'DocVaultId': docvault_id,'ExtractedFileName':file_name},update_expression=update_expression,expression_attributes=expression_values)
        except Exception as e:
            return response(500, {"Error":f"Error in updating file to unflag: {e}"})

        return response(200, {"Message":"File unflagged successfully"})
    else:
        return response(403, {"Error":"You are not authorized to unflag this file"})
        

def lambda_handler(event, context):
    """
    AWS Lambda handler function for processing file-related requests.
    
    Handles requests for:
    - Getting original/extracted files
    - Deleting files
    - Updating extracted fields
    - Exporting files (download, email, Google Drive)
    
    Args:
        event (dict): AWS Lambda event containing request data
        context (object): AWS Lambda context object
        
    Returns:
        dict: Response containing status code and body
    """
    LOGGER.info("In filesLambda.lambda_handler, Event received: %s", json.dumps(event))

    if 'Records' in event and event['Records'][0]['eventSource'] == 'aws:sqs':
        return handle_sqs(event['Records'])
    username = event.get("requestContext", {}).get("authorizer", {}).get("claims",{}).get("preferred_username",{})
    LOGGER.info("In filesLambda.lambda_handler, Username is %s", username)
    if not username:
        return response(
            401,
            {"Error": "Unauthorized, no username found"}
        )
    user = get_item(USERS_TABLE,key={'Username': username})
    if not user:
        return response(
            401,
            {"Error": "Unauthorized, user not found"}
        )
    # Extract request details
    http_method = event.get('httpMethod')
    resource = event.get('resource')
    path_parameters = event.get('pathParameters',{})
    query_string_parameters = event.get('queryStringParameters', {})

    # Extract pagination parameters
    limit_param = query_string_parameters.get('limit')
    sort_by = query_string_parameters.get('sort-by')
    offset_param = query_string_parameters.get('offset')

    try:
        limit = int(limit_param) if limit_param else 30
        offset = int(offset_param) if offset_param else 0
    except ValueError:
        return response(
            400,
            {"Error": "Offset and limit must be integers."}
        )

    docvault_id = path_parameters.get('docvault-id')
    LOGGER.info("In filesLambda.lambda_handler, Received request for docvault: %s", docvault_id)
    if not docvault_id:
        return response(
            400,
            {"Error": "Missing docvault-id in path parameters"}
        )

    # Route requests based on HTTP method and resource path
    try:
        # Get all extracted files
        if (http_method == 'GET' and resource == '/docvaults/{docvault-id}/files' and query_string_parameters.get('action') == 'get-extracted-files'):
            if query_string_parameters.get('classification') is not None:
                classification_name = query_string_parameters.get('classification')
                files = get_file_of_classification(docvault_id, classification_name,username)
                if "error" in files:
                    return response(403, {"Error": files["error"]})
                paginated_files = paginate_list("ExtractedFiles", files, VALID_EXTRACT_SORT_KEYS, offset, limit, sort_by)

                return response(200, paginated_files)
            else:
                files = get_extracted_files_in_docvault(docvault_id,username)
                if "error" in files:
                    return response(403, {"Error": files["error"]})
                paginated_files = paginate_list("ExtractedFiles", files, VALID_EXTRACT_SORT_KEYS, offset, limit, sort_by)

                return response(200, paginated_files)

        # Get all original files
        elif (http_method == 'GET' and resource == '/docvaults/{docvault-id}/files'):
            files = get_original_files_in_docvault(docvault_id, username)
            if "error" in files:
                return response(403, {"Error": files["error"]})
            paginated_files = paginate_list("Files", files, VALID_FILE_SORT_KEYS, offset, limit, sort_by)
            LOGGER.info("In filesLambda.lambda_handler, Paginated files: %s", paginated_files)
            return response(200, paginated_files)
            
        # Delete files
        elif (http_method == 'POST' and resource == '/docvaults/{docvault-id}/files' and query_string_parameters.get('action') == 'delete'):
            file_names = json.loads(event['body']).get('FileNames')
            file_type = query_string_parameters.get('file-type')
            
            if not file_names or not file_type:
                return response(
                    400,
                    {"Error": "File names and file type are required"}
                )
                
            return delete_files(docvault_id, file_names, file_type, username)
            
        # Get specific file
        elif (http_method == 'GET' and resource == '/docvaults/{docvault-id}/files/{file-name}'):
            file_name = path_parameters.get('file-name')
            file_type = query_string_parameters.get('file-type')
            
            if not file_type:
                return response(
                    400,
                    {"Error": "File type is required"}
                )
                
            return get_specific_file(docvault_id, file_name, file_type,username)

        # Update extracted fields
        elif (http_method == 'PUT' and resource == '/docvaults/{docvault-id}/files/{file-name}'):
            if query_string_parameters.get('action'):
                if query_string_parameters.get('action')=='unflag':
                    file_name = path_parameters.get('file-name')
                    return unflag_file(docvault_id, file_name, username)
                else:
                    return response(
                        400,
                        {"Error": "Invalid action"}
                    )
            elif query_string_parameters.get('type')== 'select-version':
                file_name = path_parameters.get('file-name')
                body = json.loads(event['body'])
                selection = body.get('Updates')
                file_type = query_string_parameters.get('file-type')
                if not selection:
                    return response(
                        400,
                        {"Error": "Missing selection in request body"}
                    )

                return select_key_versions(docvault_id, file_name, file_type, username, selection)
            elif query_string_parameters.get('type')=='update':
                file_name = path_parameters.get('file-name') 
                body = json.loads(event['body'])
                updates = body.get('Updates')
                file_type = query_string_parameters.get('file-type')
                
                if not updates:
                    return response(
                        400,
                        {"Error": "Missing updates in request body"}
                    )

                return edit_extracted_fields(docvault_id, file_name, file_type, updates, username)
            else:
                return response(
                    400,
                    {"Error": "Invalid request query string parameter must be passed"}
                )
        elif event.get('resource') == '/docvaults/{docvault-id}/files/exports':
            token_details=event['requestContext']['authorizer']['claims']
            if not token_details:
                return response(401, {"Error" : 'Token not provided'})
            user_details = {
                'username' : token_details.get('preferred_username'),
                'email' : token_details.get('email'),
                'email_verified' : token_details.get('email_verified')
            }

            user = get_item(
                USERS_TABLE,
                key = {
                    'Username' : username
                }
            )

            if not user:
                return response(404, {"Error":'User not found'})
            http_method = event.get('httpMethod' , '')
            resource = event.get('resource')
            path_params = event.get('pathParameters', {})
            query_params = event.get('queryStringParameters', {})

            if not path_params or not query_params:
                return response(400, {"Error":'Invalid request'})

            if 'docvault-id' not in path_params:
                return response(400, {"Error":'docvault id is required'})
            if 'action' not in query_params:
                return response(400, {"Error":'Action query string parameter is required'})
            if 'file-type' not in query_params:
                return response(400, {"Error":'Type query string parameter is required'})
            request_body_str = event.get('body')
            body = {}
            if request_body_str: 
                try:
                    body = json.loads(request_body_str)
                except json.JSONDecodeError:
                    LOGGER.error("In filesLambda.lambda_handler, Failed to parse request body as JSON: %s", request_body_str)
            body = json.loads(event['body'])
            action = query_params.get('action')
            file_type = query_params.get('file-type')
            file_names = body.get('FileNames', [])
            docvault_id = path_params.get('docvault-id')

            docvault = get_item(DOCVAULTS_TABLE,key={'DocVaultId': docvault_id})

            if not docvault:
                return response(404, {"Error":'DocVault not found'})

            has_access = validate_access(docvault_id , user_details['username'] , file_names , file_type)
                
            if not has_access:
                return response(403, {"Error":'Access denied'})

            if http_method == 'POST':
                if action == 'download':
                    LOGGER.info("In filesLambda.lambda_handler, Handling download")
                    return handle_download(docvault_id, file_names , file_type)
                if action == 'export-to-drive':
                    folder_id = body.get('GoogleFolderId', None)
                    return handle_export_to_drive(docvault_id, user_details['username'], file_names, file_type , folder_id)
                if action == 'send-to-email':
                    recipient_email = body.get('RecipientEmail', None)
                    if not recipient_email:
                        recipient_email = user_details.get('email')
                    return handle_send_to_email(docvault_id , file_names , recipient_email , file_type)
        # Invalid request
        else:
            LOGGER.error("In filesLambda.lambda_handler, Invalid request: %s %s", http_method, resource)
            return response(
                400,
                {"Error": "Invalid request"}
            )
        
    except Exception as error:
        LOGGER.error("In filesLambda.lambda_handler, Error in lambda_handler: %s", str(error))
        return response(
            500,
            {"Error": str(error)}
        )
