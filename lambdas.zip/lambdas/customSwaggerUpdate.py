"""
Update the swagger file
"""
import os
import json
import boto3
import logging
import requests

# Setting up the logger.
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

S3_CLIENT = boto3.client("s3")
CORE_BUCKET = os.environ["CoreBucket"]
SWAGGER_FILE_KEY = os.environ["SwaggerFileKey"]

COGNITO_USER_POOL_ARN = os.environ["USER_POOL_ARN"]
COGNITO_AUTHORIZER_NAME = os.environ["COGNITO_AUTHORIZER_NAME"]

LAMBDA_ARNS = json.loads(os.environ["LAMBDA_ARNS"])

def lambda_handler(event, context):
    """
    Main handler for the CloudFormation custom resource.
    Processes Create, Update, and Delete events.
    """
    try:
        LOGGER.info(f"Received event: {json.dumps(event)}")
        
        request_type = event["RequestType"]
        
        # On Delete, do nothing but send a SUCCESS response
        if request_type == "Delete":
            send_response(event, context, "SUCCESS")
            return {"statusCode": 200}

        # Validate required parameters
        if not all([CORE_BUCKET, SWAGGER_FILE_KEY, COGNITO_USER_POOL_ARN, LAMBDA_ARNS]):
            raise ValueError("BucketName, SwaggerKey, and CognitoUserPoolArn, LambdaArns are required parameters.")
        
        # Main logic
        swagger_string = download_swagger_file()
        LOGGER.info("Successfully downloaded swagger template.")
        
        updated_swagger = update_swagger_content(swagger_string)
        LOGGER.info("Successfully updated swagger content in memory.")
        
        upload_swagger_file(updated_swagger)
        LOGGER.info("Successfully uploaded modified swagger file to S3.")
        
        send_response(event, context, "SUCCESS")
        
    except Exception as e:
        LOGGER.error(f"Error: {str(e)}")
        # Send a FAILED response to CloudFormation
        send_response(event, context, "FAILED", reason=str(e))
    
    return {"statusCode": 200}


def download_swagger_file():
    """Downloads the swagger file from S3 and returns its content as a string."""
    try:
        response = S3_CLIENT.get_object(Bucket=CORE_BUCKET, Key=SWAGGER_FILE_KEY)
        return response["Body"].read().decode("utf-8")
    except Exception as e:
        LOGGER.error(f"Error downloading Swagger file: {str(e)}")
        raise


def update_swagger_content(swagger_string):
    """
        Updates the swagger content by replacing Lambda ARN placeholders and
        adding the Cognito User Pool authorizer definition.
    """
    # First, perform string replacement for all Lambda ARN placeholders
    for placeholder, arn in LAMBDA_ARNS.items():
        swagger_string = swagger_string.replace(f"%%{placeholder}%%", arn)
    
    # Second, replace the Cognito Authorizer Name
    swagger_string = swagger_string.replace(f"%%CognitoAuthorizerName%%", COGNITO_AUTHORIZER_NAME)
    
    # Third, replace the Cognito User Pool Arn
    swagger_string = swagger_string.replace(f"%%CognitoUserPoolArn%%", COGNITO_USER_POOL_ARN)
    
    return json.loads(swagger_string)


def upload_swagger_file(swagger_content):
    """Uploads the updated swagger dictionary back to S3 as a JSON file."""
    try:
        # Convert dictionary to a nicely formatted JSON string
        content = json.dumps(swagger_content, indent=2)
        S3_CLIENT.put_object(
            Bucket=CORE_BUCKET,
            Key=SWAGGER_FILE_KEY,
            Body=content,
            ContentType="application/json"
        )
    except Exception as e:
        LOGGER.error(f"Error uploading Swagger file: {str(e)}")
        raise


def send_response(event, context, response_status, reason=None):
    """Sends a response back to the CloudFormation service."""
    response_url = event["ResponseURL"]
    
    response_body = {
        "Status": response_status,
        "Reason": reason or f"See CloudWatch Log Stream: {context.log_stream_name}",
        "PhysicalResourceId": event.get("PhysicalResourceId") or context.log_stream_name,
        "StackId": event["StackId"],
        "RequestId": event["RequestId"],
        "LogicalResourceId": event["LogicalResourceId"],
    }
    
    json_response_body = json.dumps(response_body)
    
    headers = {
        "content-type": "application/json",
        "content-length": str(len(json_response_body))
    }
    
    try:
        response = requests.put(
            url=response_url,
            data=json_response_body,
            headers=headers
        )
        LOGGER.info(f"CloudFormation response status: {response.status_code}")
    except Exception as e:
        LOGGER.error(f"Error sending response to CloudFormation: {str(e)}")
        raise
