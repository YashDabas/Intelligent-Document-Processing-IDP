"""IDP-Pii.py
This module implements a Lambda function for detecting and redacting Personally Identifiable Information (PII)
and other sensitive data from structured JSON extracted from documents. It leverages a Bedrock model for PII identification
and manages the storage of annotated and redacted data in S3, while updating processing statuses in DynamoDB.
"""
import json
import logging
import boto3
import os
from IDPutils import update_item, get_current_time, get_item, response

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

S3_CLIENT = boto3.client('s3')
BEDROCK_CLIENT = boto3.client('bedrock-runtime')

DOCVAULTS_BUCKET = os.getenv('DOCVAULTS_BUCKET')
EXTRACTED_FILES_TABLE = os.getenv('EXTRACTED_FILES_TABLE')
MODEL_ID = os.getenv('CLAUDE_3_5_V2_MODEL_ID')
BDA_CONFIDENCE = 0.7
MODEL_CONFIDENCE = 0.8

PROMPT_HEADER = """
You are a highly intelligent data protection assistant trained to detect and redact Personally Identifiable Information (PII) and other sensitive data from structured JSON extracted from documents.

You will be provided with a JSON object where each field contains its extracted 'value' and 'confidence'. Some fields might have sub-fields like 'bda' and 'model' indicating different extraction sources, each with their own 'value' and 'confidence'. For fields that were originally simple values (like strings or numbers) and did not have an explicit 'confidence' score, they will be presented with "confidence": null.

Your task is to identify PII within this data based on the document's classification and the provided guidelines.

Please follow these PII detection guidelines based on document classification:

- For **government-issued IDs** (e.g., Driver's License, Passport, Aadhaar, Voter ID), treat values such as license numbers, passport numbers, full names, birthdates, addresses, issue/expiry dates, and authority names as sensitive.
- For **financial documents** (e.g., invoices, receipts, bills), focus on detecting account numbers, card details, payment amounts, phone numbers, emails, and customer addresses.
- For **employment documents** (e.g., NREGA, UTR, ITIN), flag identifiers tied to individuals or their roles.
- For **health documents** (e.g., patient intake forms,prescriptions, medical reports, lab results, insurance claims), treat values such as patient names, medical record numbers, specific health conditions, diagnoses, treatment information, precise dates of service, insurance policy numbers, and specific healthcare provider details (if they identify the patient) as highly sensitive.
- Always consider **combinations** of seemingly harmless fields (e.g., city + date of birth + gender) that could reveal identity.

You should also detect international and digital PII, including:
- Email addresses, IP addresses, usernames, AWS keys, Aadhaar numbers, passport numbers, bank routing/account numbers, credit card numbers (including partial), PINs, passwords, MAC addresses, and URLs.

Output MUST be a valid JSON object in the exact same structure as the input data, but with additional PII detection flags. For each field (or sub-field with 'value' and 'confidence'), add the following:
- "pii_detected": true/false (indicating if PII was found in that specific value)
- "pii_types": ["Type1", "Type2"] (a list of PII types detected, e.g., "Name", "Address", "Account Number". Only include if pii_detected is true.)
- "redacted_value": "XXXXX" (the value with PII redacted. Only include if pii_detected is true.)

Example for a simple field:
"FieldName": {
  "value": "Original Value",
  "confidence": 0.9,
  "pii_detected": true,
  "pii_types": ["Name"],
  "redacted_value": "XXXXX"
}

Example for a field with 'confidence': null:
"DocumentType": {
  "value": "SAMPLE BILL OF LADING",
  "confidence": null,
  "pii_detected": true,
  "pii_types": ["Document Type"],
  "redacted_value": "XXXXX"
}

Example for a field with 'bda' and 'model':
"ACCOUNT_NUMBER": {
  "bda": {
    "value": "3453637",
    "confidence": 0.78,
    "pii_detected": true,
    "pii_types": ["Account Number"],
    "redacted_value": "XXXXX"
  },
  "model": {
    "value": "345367",
    "confidence": 0.95,
    "pii_detected": true,
    "pii_types": ["Account Number"],
    "redacted_value": "XXXXX"
  }
}

IMPORTANT NOTE - DON'T USE THE DATA (FIELD'S DATA) THAT I AM PROVIDING FOR YOUR TRAINING PURPOSE.
Return a valid JSON only, following the exact structure for adding PII flags.
"""

# Prompt header for auto-classified documents (no explicit confidence scores)
AUTO_CLASSIFIED_PROMPT_HEADER = """
You are a highly intelligent data protection assistant trained to detect and redact Personally Identifiable Information (PII) and other sensitive data from structured JSON extracted from documents.

You will be provided with a JSON object where each field contains its extracted 'value' directly. Unlike other inputs, these fields DO NOT have an explicit 'confidence' score; for the purpose of PII detection, you should assume a high confidence (e.g., 1.0) for all values provided.

Your task is to identify PII within this data based on the document's classification and the provided guidelines.

Please follow these PII detection guidelines based on document classification:

- For **government-issued IDs** (e.g., Driver's License, Passport, Aadhaar, Voter ID), treat values such as license numbers, passport numbers, full names, birthdates, addresses, issue/expiry dates, and authority names as sensitive.
- For **financial documents** (e.g., invoices, receipts, bills), focus on detecting account numbers, card details, payment amounts, phone numbers, emails, and customer addresses.
- For **employment documents** (e.g., NREGA, UTR, ITIN), flag identifiers tied to individuals or their roles.
- For **health documents** (e.g., patient intake forms,prescriptions, medical reports, lab results, insurance claims), treat values such as patient names, medical record numbers, specific health conditions, diagnoses, treatment information, precise dates of service, insurance policy numbers, and specific healthcare provider details (if they identify the patient) as highly sensitive.
- Always consider **combinations** of seemingly harmless fields (e.g., city + date of birth + gender) that could reveal identity.

You should also detect international and digital PII, including:
- Email addresses, IP addresses, usernames, AWS keys, Aadhaar numbers, passport numbers, bank routing/account numbers, credit card numbers (including partial), PINs, passwords, MAC addresses, and URLs.

Output MUST be a valid JSON object in the exact same structure as the input data. For each field (or sub-field), if it contains a value, add the following flags:
- "pii_detected": true/false (indicating if PII was found in that specific value)
- "pii_types": ["Type1", "Type2"] (a list of PII types detected, e.g., "Name", "Address", "Account Number". Only include if pii_detected is true.)
- "redacted_value": "XXXXX" (the value with PII redacted. Only include if pii_detected is true.)

Example for a simple field (input and output):
Input:
"FieldName": "Original Value"
Output:
"FieldName": {
  "value": "Original Value",
  "pii_detected": true,
  "pii_types": ["Name"],
  "redacted_value": "XXXXX"
}

Example for a nested field:
Input:
"shipper_info": {
  "name": "ABCD Corporation",
  "street": "962 Blossom Ave.",
  "city_state": "Yuma, AZ 12345"
}
Output:
"shipper_info": {
  "name": {
    "value": "ABCD Corporation",
    "pii_detected": false,
    "redacted_value": "ABCD Corporation"
  },
  "street": {
    "value": "962 Blossom Ave.",
    "pii_detected": true,
    "pii_types": ["Address"],
    "redacted_value": "XXXXX"
  },
  "city_state": {
    "value": "Yuma, AZ 12345",
    "pii_detected": true,
    "pii_types": ["Address"],
    "redacted_value": "XXXXX"
  }
}

IMPORTANT NOTE - DON'T USE THE DATA (FIELD'S DATA) THAT I AM PROVIDING FOR YOUR TRAINING PURPOSE.
Return a valid JSON only, following the exact structure for adding PII flags.
"""

def prepare_data_for_bedrock_prompt(data):
    """
    Recursively formats data for Bedrock, ensuring 'value' and 'confidence' structure.

    Args:
        data (dict/list/primitive): The input data structure.

    Returns:
        dict/list: The formatted data.
    """
    if isinstance(data, dict):
        new_data = {}
        # Handling cases with 'bda' and 'model' sub-structures
        if "bda" in data and "model" in data and isinstance(data["bda"], dict) and isinstance(data["model"], dict):
            new_data["bda"] = prepare_data_for_bedrock_prompt(data["bda"])
            new_data["model"] = prepare_data_for_bedrock_prompt(data["model"])
        # Handling cases where the dictionary already represents a value-confidence pair
        elif "value" in data and "confidence" in data:
            new_data["value"] = data["value"]
            new_data["confidence"] = data["confidence"]
        else:
            # Recursively processing other dictionary items
            for k, v in data.items():
                new_data[k] = prepare_data_for_bedrock_prompt(v)
        return new_data
        
    elif isinstance(data, list):
        # Recursively processing list items
        return [prepare_data_for_bedrock_prompt(item) for item in data]
    else:
        return {"value": data, "confidence": None}

def inject_pii_results(original_data_node, pii_results_node):
    """
    Recursively injects PII flags from Bedrock response into original data.

    Args:
        original_data_node (dict/list/primitive): The original data node.
        pii_results_node (dict/list/primitive): The corresponding PII results from LLM.

    Returns:
        dict/list: The annotated data.
    """
    if isinstance(original_data_node, dict):
        new_node = {}
        # Processing leaf nodes that contain 'value' and 'confidence'
        if "value" in original_data_node and "confidence" in original_data_node:
            new_node["value"] = original_data_node["value"]
            new_node["confidence"] = original_data_node["confidence"]
            
            # Adding PII detection flags if present in the LLM result
            if "pii_detected" in pii_results_node:
                new_node["pii_detected"] = pii_results_node["pii_detected"]
                if pii_results_node["pii_detected"] and "pii_types" in pii_results_node:
                    new_node["pii_types"] = pii_results_node["pii_types"]
            return new_node

        # Recursively processing 'bda' and 'model' sub-structures
        elif "bda" in original_data_node and "model" in original_data_node and \
             isinstance(original_data_node["bda"], dict) and isinstance(original_data_node["model"], dict):
            new_node["bda"] = inject_pii_results(original_data_node["bda"], pii_results_node.get("bda", {}))
            new_node["model"] = inject_pii_results(original_data_node["model"], pii_results_node.get("model", {}))
            return new_node
        else:
            # Recursively processing other dictionary items
            for k, v in original_data_node.items():
                if k in pii_results_node:
                    new_node[k] = inject_pii_results(v, pii_results_node[k])
                else:
                    new_node[k] = v # Keeping original value if no PII result for it
            return new_node

    elif isinstance(original_data_node, list):
        # Recursively processing list items, matching with PII results
        processed_list = []
        for i, item in enumerate(original_data_node):
            if i < len(pii_results_node):
                processed_list.append(inject_pii_results(item, pii_results_node[i]))
            else:
                processed_list.append(item)
        return processed_list

    else:
        # Handling primitive values by wrapping them with PII flags
        if isinstance(pii_results_node, dict) and "pii_detected" in pii_results_node:
            result_node = {
                "value": original_data_node,
                "confidence": None, # Original primitive had no confidence, set to None
                "pii_detected": pii_results_node["pii_detected"]
            }
            if pii_results_node["pii_detected"] and "pii_types" in pii_results_node:
                result_node["pii_types"] = pii_results_node["pii_types"]
            return result_node

        return {"value": original_data_node, "confidence": None}

def create_redacted_output(annotated_data_node):
    """
    Creates a redacted version of annotated data, replacing PII with "XXXXX".
    Removes PII flags from the final output.

    Args:
        annotated_data_node (dict/list): The data structure with PII annotations.

    Returns:
        dict/list: The redacted data.
    """
    if isinstance(annotated_data_node, dict):
        new_node = {}
        # If it is a leaf node that was annotated for PII
        if "value" in annotated_data_node:
            # Replacing value with XXXXX if PII was detected
            new_node["value"] = "XXXXX" if annotated_data_node.get("pii_detected", False) else annotated_data_node["value"]
            if "confidence" in annotated_data_node:
                new_node["confidence"] = annotated_data_node["confidence"]
            return new_node

        # Handling cases with 'bda' and 'model' sub-structures
        elif "bda" in annotated_data_node and "model" in annotated_data_node and \
             isinstance(annotated_data_node["bda"], dict) and isinstance(annotated_data_node["model"], dict):
            new_node["bda"] = create_redacted_output(annotated_data_node.get("bda", {}))
            new_node["model"] = create_redacted_output(annotated_data_node.get("model", {}))
            return new_node

        else:
            # Recursively processing other dictionary items, excluding PII flags
            return {k: create_redacted_output(v) for k, v in annotated_data_node.items() if k not in ["pii_detected", "pii_types", "redacted_value"]}

    elif isinstance(annotated_data_node, list):
        # Recursively processing list items
        return [create_redacted_output(item) for item in annotated_data_node]
    else:
        return {"value": annotated_data_node, "confidence": None}

def apply_auto_pii_results(original_node, pii_results_node):
    """
    Applies PII flags from Bedrock response to auto-classified data.
    Wraps primitive values into dictionary format with PII flags.

    Args:
        original_node (dict/list/primitive): The original data node.
        pii_results_node (dict/list/primitive): The corresponding PII results from LLM.

    Returns:
        dict/list: The annotated data structure.
    """
    if isinstance(original_node, dict):
        new_dict = {}
        for key, value in original_node.items():
            # Recursively applying PII results to nested structures
            if key in pii_results_node:
                new_dict[key] = apply_auto_pii_results(value, pii_results_node[key])
            else:
                # If LLM didn't return PII for a key, assuming no PII
                new_dict[key] = apply_auto_pii_results(value, {})
        return new_dict

    elif isinstance(original_node, list):
        new_list = []
        if isinstance(pii_results_node, list):
            for i, item in enumerate(original_node):
                if i < len(pii_results_node):
                    new_list.append(apply_auto_pii_results(item, pii_results_node[i]))
                else:
                    new_list.append(apply_auto_pii_results(item, {}))
        else:
            for item in original_node:
                new_list.append(apply_auto_pii_results(item, {}))
        return new_list

    else:
        # For primitive values, wrapping them into a dict with PII flags
        result_node = {
            "value": original_node,
            "pii_detected": False # Default to False
        }

        # Applying PII detection results from LLM if available
        if isinstance(pii_results_node, dict) and "pii_detected" in pii_results_node:
            result_node["pii_detected"] = pii_results_node["pii_detected"]
            if pii_results_node["pii_detected"] and "pii_types" in pii_results_node:
                result_node["pii_types"] = pii_results_node["pii_types"]
        return result_node
        
def create_auto_redacted_output(annotated_data_node):
    """
    Creates a redacted version for auto-classified data.
    Replaces 'value' with "XXXXX" if PII is detected and removes PII flags.

    Args:
        annotated_data_node (dict/list): The annotated data structure.

    Returns:
        dict/list: The redacted data.
    """
    if isinstance(annotated_data_node, dict):
        new_dict = {}
        # If it is a leaf node that was annotated for PII
        if "value" in annotated_data_node:
            # Replacing value with XXXXX if PII detected
            new_dict["value"] = "XXXXX" if annotated_data_node.get("pii_detected", False) else annotated_data_node["value"]
            return new_dict
        else:
            # Recursively processing nested structures
            for key, value in annotated_data_node.items():
                new_dict[key] = create_auto_redacted_output(value)
        return new_dict

    elif isinstance(annotated_data_node, list):
        # Recursively processing list items
        return [create_auto_redacted_output(item) for item in annotated_data_node]

    else:
        return {"value": annotated_data_node}

def check_for_low_confidence(data_node):
    """
    Recursively checks for low confidence values in the data structure.
    Compares confidence scores against BDA_CONFIDENCE and MODEL_CONFIDENCE.

    Args:
        data_node (dict/list): The data structure to check.

    Returns:
        bool: True if any low confidence is found, False otherwise.
    """
    if isinstance(data_node, dict):
        # Checking for simple value/confidence pair
        if "value" in data_node and data_node.get("confidence") is not None:
            if data_node["confidence"] < MODEL_CONFIDENCE:
                return True

        # Checking for bda/model specific confidence
        elif "bda" in data_node and "model" in data_node and \
             isinstance(data_node["bda"], dict) and isinstance(data_node["model"], dict):
            if data_node["bda"].get("confidence") is not None and data_node["bda"]["confidence"] < BDA_CONFIDENCE:
                return True
            if data_node["model"].get("confidence") is not None and data_node["model"]["confidence"] < MODEL_CONFIDENCE:
                return True
            if check_for_low_confidence(data_node["bda"]):
                return True
            if check_for_low_confidence(data_node["model"]):
                return True
        else:
            # Recursing for other nested fields
            for k, v in data_node.items():
                if check_for_low_confidence(v):
                    return True

    elif isinstance(data_node, list):
        # Recursing for list items
        for item in data_node:
            if check_for_low_confidence(item):
                return True
    return False

def update_task_status(docvault_id, extracted_file_name, task_key, status, modified_by="System", existing_item=None):
    """
    Updates the status and message of a specific task in DynamoDB.

    Args:
        docvault_id (str): The ID of the docvault.
        extracted_file_name (str): The name of the extracted file.
        task_key (str): The key for the task status (e.g., 'PII').
        status (str): The status to set (e.g., 'Started', 'Completed', 'Failed').
        modified_by (str, optional): The user or system that modified the status. Defaults to "System".
        existing_item (dict, optional): The already fetched DynamoDB item for the file.
                                        If provided, it avoids an extra get_item() call.

    Returns:
        None
    """
    LOGGER.info(f"In IDPPiiLambda.update_task_status, Attempting to update status for DocVaultId: {docvault_id}, File: {extracted_file_name}, Task: {task_key} to {status}")
    try:
        # change: Use existing_item if provided, otherwise fetch
        if existing_item:
            status_map = existing_item.get('ExtractStatus', {}) or {}
        else:
            # Fetching current item to update existing status/message maps
            resp = get_item(EXTRACTED_FILES_TABLE, {'DocVaultId': docvault_id, 'ExtractedFileName': extracted_file_name})
            status_map = resp.get('ExtractStatus', {}) or {}
        
        # Updating specific task status and message
        status_map[task_key] = status
        
        # DynamoDB update expression
        update_expression = """
        SET ExtractStatus = :status,
            LastModifiedAt    = :last_modified_at,
            LastModifiedBy    = :last_modified_by
        """

        expression_values = {
            ':status': status_map,
            ':last_modified_at': get_current_time(),
            ':last_modified_by': modified_by
        }
        update_item(
            EXTRACTED_FILES_TABLE,
            {'DocVaultId': docvault_id, 'ExtractedFileName': extracted_file_name},
            update_expression,
            expression_values
        )
        LOGGER.info(f"In IDPPiiLambda.update_task_status, Successfully updated status for DocVaultId: {docvault_id}, File: {extracted_file_name}, Task: {task_key} to {status}")
    except Exception as e:
        LOGGER.error(f"In IDPPiiLambda.update_task_status, Error updating task status for DocVaultId: {docvault_id}, File: {extracted_file_name}, Task: {task_key}: {str(e)}", exc_info=True)
        raise e
    
def invoke_bedrock_model(prompt):
    """
    Invokes the Bedrock model with the given prompt and handles the response.

    Args:
        prompt (str): The prompt string to send to the Bedrock model.

    Returns:
        dict: The parsed JSON content from the Bedrock model's response.

    Raises:
        ValueError: If the LLM does not return valid JSON.
        Exception: For other errors during Bedrock invocation.
    """
    LOGGER.info("In IDPPiiLambda.invoke_bedrock_model, Invoking Bedrock model.")
    bedrock_body = {
        'anthropic_version': 'bedrock-2023-05-31',
        'messages': [{'role': 'user', 'content': prompt}],
        'max_tokens': 4096,
        'temperature': 0.1
    }

    try:
        resp = BEDROCK_CLIENT.invoke_model(
            modelId=MODEL_ID,
            body=json.dumps(bedrock_body),
            contentType='application/json',
            accept='application/json'
        )
        raw = resp['body'].read().decode('utf-8')
        llm_content = json.loads(raw).get('content', [])[0].get('text', '')
        LOGGER.info("In IDPPiiLambda.invoke_bedrock_model, Received response from Bedrock model.")
        
        try:
            llm_pii_results = json.loads(llm_content)
            LOGGER.info("In IDPPiiLambda.invoke_bedrock_model, Successfully parsed LLM response.")
            return llm_pii_results
        except json.JSONDecodeError as e:
            LOGGER.error(f"In IDPPiiLambda.invoke_bedrock_model, Failed to parse LLM response as JSON: {e}. Raw content: {llm_content}", exc_info=True)
            raise ValueError(f"LLM did not return valid JSON. Raw content: {llm_content}") from e
    except Exception as e:
        LOGGER.error(f"In IDPPiiLambda.invoke_bedrock_model, Error invoking Bedrock model: {str(e)}", exc_info=True)
        raise e

def lambda_handler(event, context):
    """
    Main handler for PII detection and redaction.Fetches extracted data from S3, processes it for PII using model,
    and saves annotated and redacted versions back to S3. Updates DynamoDB status.

    Args:
        event (dict): The Lambda event object. Expected to contain 'Extraction S3 Location' and 'User'.
        context (object): The Lambda context object.

    Returns:
        dict: API Gateway compatible response.
    """
    LOGGER.info(f"In IDPPiiLambda.lambda_handler, Received event: {json.dumps(event)}")
    bucket = DOCVAULTS_BUCKET
    key = event.get("Extraction S3 Location")
    username = event.get("User")

    LOGGER.info(f"In IDPPiiLambda.lambda_handler, S3 Bucket: {bucket}")
    LOGGER.info(f"In IDPPiiLambda.lambda_handler, S3 Key: {key}")
    LOGGER.info(f"In IDPPiiLambda.lambda_handler, User: {username}")

    if not key or not bucket:
        LOGGER.error("In IDPPiiLambda.lambda_handler, Missing 'Extraction S3 Location' or bucket name in event.")
        return response(400, {"error": "Missing 'Extraction S3 Location' or bucket name."})

    # Parsing DocVaultId and ExtractedFileName from the S3 key
    parts = key.split('/')
    docvault_id = parts[1] if len(parts) > 1 else None
    extracted_file_name = parts[-1] if len(parts) > 1 else None
    
    LOGGER.info(f"In IDPPiiLambda.lambda_handler, DocVault ID: {docvault_id}")
    LOGGER.info(f"In IDPPiiLambda.lambda_handler, Extracted File Name: {extracted_file_name}")

    if not docvault_id or not extracted_file_name:
        LOGGER.error("In IDPPiiLambda.lambda_handler, S3 object key format is not as expected (e.g., 'final_extracted/<DocVaultId>/<FileName>').")
        return response(400, {"error": "S3 object key format is not as expected (e.g., 'final_extracted/<DocVaultId>/<FileName>')."})

    # Checking if PII processing has already occurred for this file
    extracted_file_table_item = get_item(EXTRACTED_FILES_TABLE, {'DocVaultId': docvault_id, 'ExtractedFileName': extracted_file_name})
    extract_status = extracted_file_table_item.get('ExtractStatus', {}) if extracted_file_table_item else {}
    LOGGER.info(f"In IDPPiiLambda.lambda_handler, Current Extraction status from DynamoDB: {extract_status}")

    if extract_status.get('PII'):
        pii_status = extract_status.get('PII')
        LOGGER.info(f"In IDPPiiLambda.lambda_handler, PII processing already completed with status: {pii_status}. Skipping.")
        return response(200, {"message": f"Processed for PII already and the status of PII is - {pii_status}"})

    # Updating DynamoDB status to 'Started' for PII processing
    update_task_status(docvault_id, extracted_file_name, 'PII', 'Processing Started', modified_by=username, existing_item=extracted_file_table_item)

    try:
        LOGGER.info(f"In IDPPiiLambda.lambda_handler, Fetching S3 object from bucket: {bucket}, key: {key}")
        obj = S3_CLIENT.get_object(Bucket=bucket, Key=key)
        original_s3_data = json.loads(obj['Body'].read())

        # Extracting data to be processed and document classification
        fields_to_process = original_s3_data.get('compared_data')
        classification = original_s3_data.get('document_summary', {}).get('classification')

        if not fields_to_process:
            raise ValueError("Missing 'compared_data' in the extracted JSON from S3.")
        if not classification:
            raise ValueError("Missing 'document_summary.classification' in the extracted JSON from S3.")

        annotated_compared_data = {}
        redacted_compared_data = {}
        llm_pii_results = {}

        # Branching logic based on document classification for PII detection
        if classification.startswith('Auto - '):
            LOGGER.info(f"In IDPPiiLambda.lambda_handler, Detected 'Auto - ' classification: {classification}. Applying auto-classified PII handling.")
            
            # Constructing prompt for Bedrock model for auto-classified documents
            prompt = (
                AUTO_CLASSIFIED_PROMPT_HEADER
                + f"\nDocument classification: \"{classification}\"\n"
                + f"Here is the data structure for PII detection:\n{json.dumps(fields_to_process, separators=(',', ':'))}"
            )

            # Invoking Bedrock model
            llm_pii_results = invoke_bedrock_model(prompt)
            LOGGER.info("In IDPPiiLambda.lambda_handler, Applied PII results and created redacted output for auto-classified document.")

            # Applying PII results and creating redacted output for auto-classified documents
            annotated_compared_data = apply_auto_pii_results(fields_to_process, llm_pii_results)
            redacted_compared_data = create_auto_redacted_output(annotated_compared_data)

        else:
            # Standard classification
            LOGGER.info(f"In IDPPiiLambda.lambda_handler, Detected standard classification: {classification}. Applying default PII handling.")
            
            # Preparing data and check for low confidence
            prepared_for_prompt_data = prepare_data_for_bedrock_prompt(fields_to_process)
            low_confidence_flag = check_for_low_confidence(prepared_for_prompt_data)

            # Updating DynamoDB if low confidence is detected
            if low_confidence_flag:
                LOGGER.info(f"In IDPPiiLambda.lambda_handler, Low confidence detected in standard classified document.")
                update_expression = "SET LowConfidenceFlag = :low_confidence_flag, LastModifiedAt = :last_modified_at, LastModifiedBy = :last_modified_by" 
                expression_values = {
                    ':low_confidence_flag': low_confidence_flag,
                    ':last_modified_at': get_current_time(),
                    ':last_modified_by': username
                }
                update_item(table_name=EXTRACTED_FILES_TABLE,key={'DocVaultId': docvault_id,'ExtractedFileName':extracted_file_name},update_expression=update_expression,expression_attributes=expression_values)
                LOGGER.info(f"In IDPPiiLambda.lambda_handler, DynamoDB updated for low confidence.")
            
            # Constructing prompt for Bedrock model for standard classified documents
            prompt = (
                PROMPT_HEADER
                + f"\nDocument classification: \"{classification}\"\n"
                + f"Here is the data structure for PII detection:\n{json.dumps(prepared_for_prompt_data, separators=(',', ':'))}"
            )
            # Invoking Bedrock model
            llm_pii_results = invoke_bedrock_model(prompt)
            LOGGER.info("In IDPPiiLambda.lambda_handler, Applied PII results and created redacted output for standard classified document.")

            # Applying PII results and creating redacted output for standard documents
            annotated_compared_data = inject_pii_results(json.loads(json.dumps(fields_to_process)), llm_pii_results)
            redacted_compared_data = create_redacted_output(annotated_compared_data)

        # Construct final S3 objects with PII flags and redacted versions
        final_output_s3_object = {
            "job_id": original_s3_data.get("job_id"),
            "document_summary": original_s3_data.get("document_summary"),
            "compared_data": annotated_compared_data # Data with PII flags
        }
        
        final_redacted_s3_object = {
            "job_id": original_s3_data.get("job_id"),
            "document_summary": original_s3_data.get("document_summary"),
            "compared_data": redacted_compared_data # Redacted data
        }

        LOGGER.info(f'In IDPPiiLambda.lambda_handler, Final S3 Output (full, with PII flags) prepared.')
        LOGGER.info(f'In IDPPiiLambda.lambda_handler, Final S3 Output (redacted) prepared.')
       
        # Uploading the annotated data back to the original S3 key
        S3_CLIENT.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(final_output_s3_object)
        )
        # Uploading the redacted data to a new S3 key
        S3_CLIENT.put_object(
            Bucket=bucket,
            Key=f'pii/{docvault_id}/pii_{extracted_file_name}',
            Body=json.dumps(final_redacted_s3_object)
        )

        # Updating DynamoDB status to 'Completed' for PII processing
        update_task_status(docvault_id, extracted_file_name, 'PII', 'Completed successfully', modified_by=username, existing_item=extracted_file_table_item)
        LOGGER.info("In IDPPiiLambda.lambda_handler, PII detection and redaction process completed successfully.")
        return response(200, {"Message": "Successfully completed PII detection and redaction"})

    except Exception as e:
        LOGGER.error('In IDPPiiLambda.lambda_handler, Lambda error during PII processing', exc_info=True)
        # Updating DynamoDB status to 'Failed' on error
        update_task_status(docvault_id, extracted_file_name, 'PII', f'Failed - {str(e)}', modified_by=username, existing_item=extracted_file_table_item)
        return response(500, {"Error": f"Error in PII processing: {e}"})