import os
import json
import boto3
import logging
import requests

# Setting up the logger.
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

CLUSTER_ARN = os.environ["DatabaseClusterArn"]
SECRET_ARN = os.environ["SecretArn"]
DATABASE = os.environ["DatabaseName"]
TABLE_NAME = os.environ['TableName']

RDS_DATA_CLIENT = boto3.client('rds-data')

def send_response(event, context, response_status):
    """
        Send response to cloudformation.
    """
    response_url = event["ResponseURL"]
    response_body = {
        "Status": response_status,
        "Reason": f"See CloudWatch Log Stream: {context.log_stream_name}",
        "PhysicalResourceId": context.log_stream_name,
        "StackId": event["StackId"],
        "RequestId": event["RequestId"],
        "LogicalResourceId": event["LogicalResourceId"],
    }
    json_response_body = json.dumps(response_body)
    headers = {
        "content-type": "application/json",
        "content-length": str(len(json_response_body))
    }
    try:
        response = requests.put(
            url=response_url,
            data=json_response_body,
            headers=headers
        )
        LOGGER.info(f"CloudFormation response status: {response.status_code}")
    except Exception as e:
        LOGGER.error(f"Error sending response to CloudFormation: {str(e)}")

def lambda_handler(event, context):
    """
        Handle the creation of the RDS table
    """
    # Validate environment variables
    required_vars = ['DatabaseClusterArn', 'SecretArn', 'DatabaseName', 'TableName']
    missing_vars = [var for var in required_vars if not os.environ.get(var)]
    if missing_vars:
        error_msg = f"Missing required environment variables: {missing_vars}"
        LOGGER.error(error_msg)
        send_response(event, context, "FAILED")
        return {"statusCode": 400, "body": error_msg}
    
    # Log environment variables (without sensitive data)
    LOGGER.info(f"Database: {DATABASE}")
    LOGGER.info(f"Table: {TABLE_NAME}")
    LOGGER.info(f"Cluster ARN: {CLUSTER_ARN}")
    
    try:
        if event['RequestType'] == 'Create':
            # Add more detailed logging and error handling
            LOGGER.info(f"Starting table creation for {TABLE_NAME}")
            LOGGER.info(f"Using cluster: {CLUSTER_ARN}")
            LOGGER.info(f"Using database: {DATABASE}")
            
            # First, enable the pgvector extension with better error handling
            try:
                LOGGER.info("Attempting to create pgvector extension...")
                response = RDS_DATA_CLIENT.execute_statement(
                    resourceArn=CLUSTER_ARN,
                    secretArn=SECRET_ARN,
                    database=DATABASE,
                    sql='CREATE EXTENSION IF NOT EXISTS vector;',
                    includeResultMetadata=True
                )
                LOGGER.info(f'pgvector extension enabled successfully: {response}')
            except Exception as e:
                LOGGER.error(f"Error enabling pgvector extension: {str(e)}")
                LOGGER.error(f"Exception type: {type(e).__name__}")
                # Try to continue - extension might already exist
                LOGGER.info("Continuing despite extension error...")
            
            
            # Create the table with better error handling
            try:
                LOGGER.info("Attempting to create table...")
                response = RDS_DATA_CLIENT.execute_statement(
                    resourceArn=CLUSTER_ARN,
                    secretArn=SECRET_ARN,
                    database=DATABASE,
                    sql=f'CREATE TABLE IF NOT EXISTS "{TABLE_NAME}" (id uuid PRIMARY KEY, embedding vector(1024), chunks text, custom_metadata jsonb);',
                    includeResultMetadata=True
                )
                LOGGER.info(f'Table created successfully: {response}')
            except Exception as e:
                LOGGER.error(f"Error creating table: {str(e)}")
                LOGGER.error(f"Exception type: {type(e).__name__}")
                raise e
            
            # Create indexes with individual error handling
            indexes = [
                (f'CREATE INDEX IF NOT EXISTS "{TABLE_NAME}_embedding_idx" ON "{TABLE_NAME}" USING hnsw (embedding vector_cosine_ops);', 'Vector index'),
                (f'CREATE INDEX IF NOT EXISTS "{TABLE_NAME}_chunks_idx" ON "{TABLE_NAME}" USING gin (to_tsvector(\'simple\', chunks));', 'Text search index'),
                (f'CREATE INDEX IF NOT EXISTS "{TABLE_NAME}_metadata_idx" ON "{TABLE_NAME}" USING gin (custom_metadata);', 'Metadata index')
            ]
            
            for sql, description in indexes:
                try:
                    LOGGER.info(f"Creating {description}...")
                    response = RDS_DATA_CLIENT.execute_statement(
                        resourceArn=CLUSTER_ARN,
                        secretArn=SECRET_ARN,
                        database=DATABASE,
                        sql=sql,
                        includeResultMetadata=True
                    )
                    LOGGER.info(f'{description} created successfully: {response}')
                except Exception as e:
                    LOGGER.error(f"Error creating {description}: {str(e)}")
                    LOGGER.error(f"Exception type: {type(e).__name__}")
                    # Continue with other indexes even if one fails
                    continue
            
        LOGGER.info(f"Sending success response for {event['RequestType']}")
        send_response(event, context, "SUCCESS")
        
    except Exception as e:
        LOGGER.error(f"Error: {str(e)}")
        send_response(event, context, "FAILED")
    
    return {
        "statusCode": 200
    }