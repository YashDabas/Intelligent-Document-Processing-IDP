"""
Putting classification in s3 and dynamo
"""

import os
import json
import boto3
import logging
import requests
from datetime import datetime

# Setting up the logger.
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

S3_CLIENT = boto3.client("s3")
CORE_BUCKET = os.environ["ClassificationsBucket"]

DYNAMO_RESOURCE = boto3.resource("dynamodb")
CLASSIFICATIONS_TABLE_NAME = os.environ["CLASSIFICATIONS_TABLE_NAME"]
CLASSIFICATIONS_TABLE = DYNAMO_RESOURCE.Table(CLASSIFICATIONS_TABLE_NAME)

CLASSIFICATIONS = {
    "BANK-STATEMENT": {
        "ACCOUNT_HOLDER_NAME": "Name of the bank account holder",
        "ACCOUNT_HOLDER_ADDRESS": "Full address of the account holder including street, city, state and zip code",
        "ACCOUNT_NUMBER": "The account number for which the statement is prepared",
        "ACCOUNT_SUMMARY": {
            "OPENING_BALANCE": "Account balance at the start of the statement period",
            "CLOSING_BALANCE": "Account balance at the end of the statement period",
            "TOTAL_DEPOSITS": "Sum of all deposits/credits during the statement period",
            "TOTAL_WITHDRAWALS": "Sum of all withdrawals/debits during the statement period"
        },
        "ACCOUNT_TYPE": "Type of the bank account, such as 'Checking', 'Savings', etc.",
        "BANK_NAME": "Name of the financial institution",
        "BRANCH_TRANSIT_NUMBER": "The branch transit number",
        "STATEMENT_END_DATE": "End date for the statement in YYYY-MM-DD format",
        "STATEMENT_START_DATE": "Statement start date in YYYY-MM-DD format"
    },

    "INVOICE": {
        "BILLING_ADDRESS": {
            "CITY": "City",
            "STATE": "State",
            "STREET": "Street address",
            "ZIP_CODE": "Zip code"
        },
        "DISCOUNT_COUPON_CODE": "Discount coupon code applied to the invoice",
        "DISCOUNTED_AMOUNT": "Amount discounted from the total due to coupon code",
        "INVOICE_NUMBER": "Unique identifier for the invoice",
        "PAYMENT_INFORMATION": {
            "CARD_HOLDER": "Name of the card holder",
            "CARD_NUMBER": "Partial credit/debit card number used for payment",
            "PAYMENT_NUMBER": "Unique payment transaction number",
            "PAYMENT_TYPE": "Payment method used (e.g. Credit Card, Debit Card)"
        },
        "SELLER_ADDRESS": {
            "CITY": "City",
            "STATE": "State",
            "STREET": "Street address",
            "ZIP_CODE": "Zip code"
        },
        "SHIPPING_ADDRESS": {
            "CITY": "City",
            "STATE": "State",
            "STREET": "Street address",
            "ZIP_CODE": "Zip code"
        },
        "TAX_AMOUNT": "Total tax amount applied to the invoice",
        "TOTAL_AMOUNT": "Total amount due on the invoice before discounts and taxes",
        "TRANSACTION_DATE": "Date when the transaction took place"
    },

    "RECEIPT": {
        "ID": "Unique ID associated with the receipt. Can be under the name of 'ID' or 'Invoice Number' or 'Invoice #'",
        "DATE": "Date on which receipt was generated. Provide it in YYYY-MM-DD",
        "TIME": "Time of the day when the receipt was generated. Provide it in HH:MM:SS",
        "PAYMENT_DETAILS": {
            "AMOUNT_PAID": "Amount paid off in the receipt",
            "SUBTOTAL": "Sum of all the amounts from the line items table",
            "TAX": "List of amounts charged as taxes",
            "TOTAL": "Total receipt amount including taxes",
            "TIP_AMOUNT": "Amount of tip that was given."
        },
        "VENDOR_DETAILS": {
            "VENDOR_NAME": "Name of the vendor",
            "VENDOR_ADDRESS": "Full address of the vendor",
            "VENDOR_PHONE": "Phone number of the vendor"
        }
    },

    "US-DRIVER-LICENSE": {
        "ADDRESS_DETAILS": {
            "CITY": "The city name",
            "STATE": "The two letter code of the state",
            "STREET_ADDRESS": "The street address",
            "ZIP_CODE": "The zip code"
        },
        "CLASS": "The single letter class code, one of 'A', 'B','C', 'D', or 'M'",
        "COUNTY": "The county (if available, else empty string)",
        "DATE_OF_BIRTH": "The date of birth of the driver in YYYY-MM-DD format",
        "DATE_OF_ISSUE": "The date of issue in YYYY-MM-DD format",
        "ENDORSEMENTS": "The endorsement codes if any",
        "EXPIRATION_DATE": "The date of expiry in YYYY-MM-DD format",
        "ID_NUMBER": "The unique identification number of the driving license",
        "NAME_DETAILS": {
            "FIRST_NAME": "The first name",
            "LAST_NAME": "The last name of the driver",
            "MIDDLE_NAME": "The middle name or initial",
            "SUFFIX": "The suffix, such as PhD, MSc. etc"
        },
        "PERSONAL_DETAILS": {
            "EYE_COLOR": "Eye colour, unabbreviated"
        }
    },

    "US-PASSPORT": {
        "PASSPORT_DETAILS": {
            "PASSPORT_NUMBER": "The unique passport identification number",
            "PASSPORT_TYPE": "Type of passport document (e.g., 'P', etc)",
            "COUNTRY_CODE": "Three-letter country code (e.g., USA)",
            "ISSUED_DATE": "Date when the passport was issued in YYYY-MM-DD format",
            "EXPIRATION_DATE": "Date when the passport expires in YYYY-MM-DD format"
        },
        "PERSONAL_DETAILS": {
            "SURNAME": "Last name/family name of the passport holder",
            "GIVEN_NAMES": "First name and middle name(s) of the passport holder",
            "SEX": "Gender of the passport holder (M/F)",
            "DATE_OF_BIRTH": "Date of birth in YYYY-MM-DD format",
            "PLACE_OF_BIRTH": "City and country where the passport holder was born",
            "NATIONALITY": "Nationality of the passport holder"
        },
        "MRZ": {
            "MRZ_LINE_1": "First line of the machine readable zone",
            "MRZ_LINE_2": "Second line of the machine readable zone"
        },
        "ISSUING_AUTHORITY": "Authority that issued the passport",
        "ENDORSEMENTS": "Any special endorsements or restrictions on the passport"
    }
}

def send_response(event, context, response_status):
    """
        Send response to cf
    """
    response_url = event["ResponseURL"]
    
    response_body = {
        "Status": response_status,
        "Reason": f"See CloudWatch Log Stream: {context.log_stream_name}",
        "PhysicalResourceId": context.log_stream_name,
        "StackId": event["StackId"],
        "RequestId": event["RequestId"],
        "LogicalResourceId": event["LogicalResourceId"],
    }
    
    json_response_body = json.dumps(response_body)
    
    headers = {
        "content-type": "application/json",
        "content-length": str(len(json_response_body))
    }
    
    try:
        response = requests.put(
            url=response_url,
            data=json_response_body,
            headers=headers
        )
        LOGGER.error(f"CloudFormation response status: {response.status_code}")
    except Exception as e:
        LOGGER.error(f"Error sending response to CloudFormation: {str(e)}")

def lambda_handler(event, context):
    """
        handle s3 and dynamo put
    """
    try:
        if event["RequestType"] == "Create":
            LOGGER.info(f"Uploading Bank Statement Classification into S3 and Dynamo DB.")
            S3_CLIENT.put_object(
                Bucket=CORE_BUCKET,
                Key="schema/bank-statement.json",
                Body=json.dumps(CLASSIFICATIONS["BANK-STATEMENT"], indent=4).encode("utf-8")
                )
            CLASSIFICATIONS_TABLE.put_item(
                Item={
                    "ClassificationName": "BANK-STATEMENT",
                    "CreatedBy": "System",
                    "Description": "Classification for Bank Statements, primarily for US ones.",
                    "BlueprintArn": "arn:aws:bedrock:us-east-1:043309350924:blueprint/26580677953f",
                    "SchemaS3Location": "schema/bank-statement.json",
                    "CreatedAt": datetime.now().isoformat(),
                    "BatchId": "1"
                }
            )
            LOGGER.info(f"Finished uploading Bank Statement Classification into S3 and Dynamo DB.")

            LOGGER.info(f"Uploading Invoice Classification into S3 and Dynamo DB.")
            S3_CLIENT.put_object(
                Bucket=CORE_BUCKET,
                Key="schema/invoice.json",
                Body=json.dumps(CLASSIFICATIONS["INVOICE"], indent=4).encode("utf-8")
                )
            CLASSIFICATIONS_TABLE.put_item(
                Item={
                    "ClassificationName": "Invoice",
                    "CreatedBy": "System",
                    "Description": "Classification for Invoices, primarily for US ones.",
                    "BlueprintArn": "arn:aws:bedrock:us-east-1:043309350924:blueprint/cf2a0d77ecf8",
                    "SchemaS3Location": "schema/invoice.json",
                    "CreatedAt": datetime.now().isoformat(),
                    "BatchId": "1"
                }
            )
            LOGGER.info(f"Finished uploading Invoice Classification into S3 and Dynamo DB.")

            LOGGER.info(f"Uploading Receipt Classification into S3 and Dynamo DB.")
            S3_CLIENT.put_object(
                Bucket=CORE_BUCKET,
                Key="schema/receipt.json",
                Body=json.dumps(CLASSIFICATIONS["RECEIPT"], indent=4).encode("utf-8")
                )
            CLASSIFICATIONS_TABLE.put_item(
                Item={
                    "ClassificationName": "RECEIPT",
                    "CreatedBy": "System",
                    "Description": "Classification for Receipts, primarily for US ones.",
                    "BlueprintArn": "arn:aws:bedrock:us-east-1:043309350924:blueprint/6d6c9d4b776b",
                    "SchemaS3Location": "schema/receipt.json",
                    "CreatedAt": datetime.now().isoformat(),
                    "BatchId": "1"
                }
            )
            LOGGER.info(f"Finished uploading Receipt Classification into S3 and Dynamo DB.")

            LOGGER.info(f"Uploading US-Driver-License Classification into S3 and Dynamo DB.")
            S3_CLIENT.put_object(
                Bucket=CORE_BUCKET,
                Key="schema/us-driver-license.json",
                Body=json.dumps(CLASSIFICATIONS["US-DRIVER-LICENSE"], indent=4).encode("utf-8")
                )
            CLASSIFICATIONS_TABLE.put_item(
                Item={
                    "ClassificationName": "US-DRIVER-LICENSE",
                    "CreatedBy": "System",
                    "Description": "Classification for US Drivers Licenses.",
                    "BlueprintArn": "arn:aws:bedrock:us-east-1:043309350924:blueprint/0ca43a3f1a40",
                    "SchemaS3Location": "schema/us-driver-license.json",
                    "CreatedAt": datetime.now().isoformat(),
                    "BatchId": "1"
                }
            )
            LOGGER.info(f"Finished uploading US-Driver-LicenseClassification into S3 and Dynamo DB.")

            LOGGER.info(f"Uploading US-Passport Classification into S3 and Dynamo DB.")
            S3_CLIENT.put_object(
                Bucket=CORE_BUCKET,
                Key="schema/us-passport.json",
                Body=json.dumps(CLASSIFICATIONS["US-PASSPORT"], indent=4).encode("utf-8")
                )
            CLASSIFICATIONS_TABLE.put_item(
                Item={
                    "ClassificationName": "US-PASSPORT",
                    "CreatedBy": "System",
                    "Description": "Classification for US Passports",
                    "BlueprintArn": "arn:aws:bedrock:us-east-1:043309350924:blueprint/e3a4bdcb14be",
                    "SchemaS3Location": "schema/us-passport.json",
                    "CreatedAt": datetime.now().isoformat(),
                    "BatchId": "1"
                }
            )
            LOGGER.info(f"Finished uploading US-Passport Classification into S3 and Dynamo DB.")

            LOGGER.info(f"Sending success response for {event["RequestType"]}")
            send_response(event, context, "SUCCESS")

        if event["RequestType"] == 'Update' or event['RequestType'] == 'Delete':
            LOGGER.info(f"Sending success response for {event["RequestType"]}")
            send_response(event, context, "SUCCESS")
    
    except Exception as e:
        LOGGER.error(f"Error: {str(e)}")
        send_response(event, context, "FAILED")

    return {
        "statusCode": 200
    }
