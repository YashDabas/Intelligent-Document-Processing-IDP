"""
IDP Fraud Detection Lambda
This module defines an AWS Lambda function for detecting fraud in document images using Bedrock AI.
It analyzes the document image, compares extracted data against official registry data, and performs forensic checks.
It returns a structured response indicating whether the document is fraudulent, along with risk levels and reasons.
"""

import os
import json
import boto3
from datetime import datetime, date
import re
import io
import logging
import base64
from botocore.exceptions import ClientError

try:
    import fitz  # PyMuPDF

    PDF_SUPPORT_ENABLED = True
except ImportError:
    PDF_SUPPORT_ENABLED = False

try:
    from PIL import Image, ImageChops, ExifTags

    PILLOW_SUPPORT_ENABLED = True
except ImportError:
    PILLOW_SUPPORT_ENABLED = False

try:
    import numpy as np
    from skimage.restoration import estimate_sigma

    SCIKIT_IMAGE_SUPPORT_ENABLED = True
except ImportError:
    SCIKIT_IMAGE_SUPPORT_ENABLED = False


AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")
BEDROCK = boto3.client(service_name="bedrock-runtime", region_name=AWS_REGION)
S3_CLIENT = boto3.client("s3", region_name=AWS_REGION)
DYNAMODB = boto3.resource("dynamodb", region_name=AWS_REGION)

REGISTRY_TABLE_NAME = os.environ.get("REGISTRY_TABLE", "IDP-Document-Registry-Table")
EXTRACTED_FILES_TABLE_NAME = os.environ.get(
    "EXTRACTED_FILES_TABLE", "IDP-ExtractedFiles-Table"
)
DOCVAULTS_BUCKET = os.environ.get("DOCVAULTS_BUCKET", "idp-docvault-bucket")
BEDROCK_MODEL_ID = os.environ.get(
    "CLAUDE_3_5_V1_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0"
)
BEDROCK_REGION = os.environ.get("BEDROCK_REGION", "us-east-1")


DOCUMENTS_REGISTRY_TABLE = DYNAMODB.Table(REGISTRY_TABLE_NAME)
EXTRACTED_FILES_TABLE = DYNAMODB.Table(EXTRACTED_FILES_TABLE_NAME)

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)


def analyze_pdf_for_tampering(pdf_stream: io.BytesIO):
    """
    Analyzes a PDF document for signs of tampering using its metadata.

    This function inspects the 'producer' and 'creator' fields in the PDF's
    metadata for keywords related to common editing software.

    Args:
        pdf_stream (io.BytesIO): A byte stream of the PDF file to be analyzed.

    Returns:
        dict: A dictionary containing the analysis results, including:
              - 'pdf_metadata' (dict): The extracted metadata from the PDF.
              - 'is_suspicious' (bool): True if tampering is suspected, False otherwise.
              - 'reasons' (list): A list of strings explaining why the document is suspicious.
    """
    pdf_tamper_results = {
        "pdf_metadata": {},
        "is_suspicious": False,
        "reasons": [],
    }
    if not PDF_SUPPORT_ENABLED:
        pdf_tamper_results["reasons"].append(
            "PDF analysis skipped: PyMuPDF library not available."
        )
        return pdf_tamper_results

    try:
        pdf_stream.seek(0)
        pdf_document = fitz.open(stream=pdf_stream.read(), filetype="pdf")
        info = pdf_document.metadata
        LOGGER.error("PDF Metadata: %s", info)
        pdf_tamper_results["pdf_metadata"] = info
        if info:
            producer = info.get("producer", "").lower()
            creator = info.get("creator", "").lower()
            if re.search(
                r"photoshop|illustrator|gimp|coreldraw|canva|word|excel", producer
            ) or re.search(
                r"photoshop|illustrator|gimp|coreldraw|canva|word|excel", creator
            ):
                pdf_tamper_results["is_suspicious"] = True
                pdf_tamper_results["reasons"].append(
                    f"PDF metadata suggests creation by editing software (Producer: {info.get('producer')}, Creator: {info.get('creator')})."
                )
        pdf_document.close()
    except Exception as e:
        LOGGER.error(f"Error during PDF tampering analysis: {e}", exc_info=True)
        pdf_tamper_results["reasons"].append(f"Error during PDF internal analysis: {e}")
        pdf_tamper_results["is_suspicious"] = True
    return pdf_tamper_results


def analyze_image_metadata(image_obj: "Image.Image"):
    """
    Analyzes the image EXIF metadata for signs of tampering.

    This function checks for the presence of editing software tags and validates
    the 'DateTimeOriginal' field for logical consistency.

    Args:
        image_obj (Image.Image): A Pillow Image object to be analyzed.

    Returns:
        dict: A dictionary containing the analysis results, including:
              - 'is_suspicious' (bool): True if tampering is suspected, False otherwise.
              - 'reasons' (list): A list of strings explaining why the image is suspicious.
    """
    metadata_findings = {"reasons": [], "is_suspicious": False}
    if not PILLOW_SUPPORT_ENABLED:
        metadata_findings["reasons"].append(
            "EXIF analysis skipped: Pillow library not available."
        )
        return metadata_findings

    exif_data = image_obj.getexif()
    if not exif_data:
        return metadata_findings

    interpreted_exif = {
        ExifTags.TAGS.get(tag, tag): value for tag, value in exif_data.items()
    }
    software_used = interpreted_exif.get("Software")
    if software_used:
        if re.search(
            r"photoshop|gimp|pixelmator|corel|canva|fotor", str(software_used).lower()
        ):
            metadata_findings["is_suspicious"] = True
            metadata_findings["reasons"].append(
                f"Image EXIF data shows use of editing software: {software_used}."
            )

    date_time_original = interpreted_exif.get("DateTimeOriginal")
    if date_time_original:
        try:
            exif_date = datetime.strptime(
                str(date_time_original), "%Y:%m:%d %H:%M:%S"
            ).date()
            if exif_date > date.today() or exif_date.year < 1995:
                metadata_findings["is_suspicious"] = True
                metadata_findings["reasons"].append(
                    f"Suspicious EXIF original date found: {date_time_original}."
                )
        except (ValueError, TypeError):
            metadata_findings["is_suspicious"] = True
            metadata_findings["reasons"].append(
                f"Malformed or unusual EXIF date format: {date_time_original}."
            )
    return metadata_findings


def perform_ela(image_obj: "Image.Image", quality=90, threshold=15.0):
    """
    Performs Error Level Analysis (ELA) on an image to detect tampering.

    ELA works by re-saving the image at a specific JPEG quality and then
    finding the difference between the original and the re-saved version.
    Significant differences can indicate manipulation.

    Args:
        image_obj (Image.Image): The Pillow Image object to analyze.
        quality (int, optional): The JPEG quality level for re-compression. Defaults to 90.
        threshold (float, optional): The maximum difference threshold above which
        the image is considered suspicious. Defaults to 15.0.

    Returns:
        dict: A dictionary containing the ELA results, including:
              - 'is_suspicious' (bool): True if tampering is suspected, False otherwise.
              - 'reasons' (list): A list of strings explaining why the image is suspicious.
    """

    ela_results = {"is_suspicious": False, "reasons": []}
    if not PILLOW_SUPPORT_ENABLED:
        ela_results["reasons"].append("ELA skipped: Pillow library not available.")
        return ela_results

    try:
        original_image = image_obj.convert("RGB")
        buffer = io.BytesIO()
        original_image.save(buffer, format="JPEG", quality=quality)
        buffer.seek(0)
        resaved_image = Image.open(buffer)

        diff = ImageChops.difference(original_image, resaved_image)

        extrema = diff.getextrema()
        max_diff = max(extrema)[1]
        if max_diff > threshold:
            ela_results["is_suspicious"] = True
            ela_results["reasons"].append(
                f"Error Level Analysis failed: Max difference {max_diff:.2f} exceeds threshold {threshold}, suggesting tampering."
            )
    except Exception as e:
        LOGGER.error(f"Error performing ELA: {e}", exc_info=True)
        ela_results["is_suspicious"] = True
        ela_results["reasons"].append(f"ELA process failed with an error: {e}")
    return ela_results


def analyze_background_noise(
    image_obj: "Image.Image", block_size=16, noise_threshold=1.5
):
    """
    Analyzes the background noise of an image to detect inconsistencies.

    This method divides the image into blocks and compares the noise level of
    each block to the overall image noise level. Significant variations can
    indicate that parts of the image were pasted from different sources.

    Args:
        image_obj (Image.Image): The Pillow Image object to analyze.
        block_size (int, optional): The size of the square blocks to analyze. Defaults to 16.
        noise_threshold (float, optional): The allowed deviation from the overall noise
                                           level. Defaults to 1.5.

    Returns:
        dict: A dictionary containing the noise analysis results, including:
              - 'is_suspicious' (bool): True if inconsistencies are found, False otherwise.
              - 'reasons' (list): A list of strings explaining why the image is suspicious.
    """
    noise_results = {"is_suspicious": False, "reasons": []}
    if not SCIKIT_IMAGE_SUPPORT_ENABLED:
        noise_results["reasons"].append(
            "Noise analysis skipped: scikit-image/numpy not available."
        )
        return noise_results

    try:
        image_gray = image_obj.convert("L")
        image_np = np.array(image_gray, dtype=np.float64)
        overall_noise = estimate_sigma(image_np, channel_axis=None, average_sigmas=True)

        (h, w) = image_np.shape
        inconsistent_blocks = 0
        total_blocks = 0
        for y in range(0, h, block_size):
            for x in range(0, w, block_size):
                block = image_np[y : y + block_size, x : x + block_size]
                if block.size < block_size**2:
                    continue
                total_blocks += 1
                block_noise = estimate_sigma(
                    block, channel_axis=None, average_sigmas=True
                )
                if abs(block_noise - overall_noise) > noise_threshold:
                    inconsistent_blocks += 1

        inconsistency_ratio = (
            (inconsistent_blocks / total_blocks) if total_blocks > 0 else 0
        )
        if inconsistency_ratio > 0.1:
            noise_results["is_suspicious"] = True
            noise_results["reasons"].append(
                f"Inconsistent noise detected in {inconsistency_ratio:.2%} of the image, suggesting manipulation."
            )
    except Exception as e:
        LOGGER.error(f"Error during background noise analysis: {e}", exc_info=True)
        noise_results["is_suspicious"] = True
        noise_results["reasons"].append(f"Noise analysis failed with an error: {e}")
    return noise_results


def get_s3_object_as_bytestream(bucket: str, key: str) -> io.BytesIO:
    """
    Downloads an S3 object and returns it as an in-memory byte stream.

    Args:
        bucket (str): The name of the S3 bucket.
        key (str): The key of the object within the S3 bucket.

    Raises:
        FileNotFoundError: If the S3 object does not exist at the specified key.
        ClientError: For other Boto3 S3 client errors.

    Returns:
        io.BytesIO: An in-memory binary stream of the S3 object's content.
    """
    try:
        response = S3_CLIENT.get_object(Bucket=bucket, Key=key)
        return io.BytesIO(response["Body"].read())
    except ClientError as e:
        LOGGER.error(f"Failed to download s3://{bucket}/{key}. Error: {e}")
        if e.response["Error"]["Code"] == "NoSuchKey":
            raise FileNotFoundError(f"S3 object not found: s3://{bucket}/{key}") from e
        raise


def get_s3_json_as_dict(bucket: str, key: str) -> dict:
    """
    Retrieves a JSON object from S3 and parses it into a Python dictionary.

    Args:
        bucket (str): The name of the S3 bucket.
        key (str): The key of the JSON object in the S3 bucket.

    Raises:
        ValueError: If the object cannot be found or if the file content is not
                    valid JSON.

    Returns:
        dict: The parsed JSON data as a dictionary.
    """
    try:
        s3_object_stream = get_s3_object_as_bytestream(bucket, key)
        return json.load(s3_object_stream)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        LOGGER.error(f"Failed to get or parse JSON from s3://{bucket}/{key}: {e}")
        raise ValueError(f"Could not retrieve or parse S3 JSON data: {key}") from e


def _get_field_value(data: dict, field_name: str) -> any:
    """
    Extracts a 'value' from a nested dictionary structure.

    This helper is designed for dictionaries where a field's value is stored
    in a nested dictionary under the key 'value'.

    Args:
        data (dict): The dictionary to search within.
        field_name (str): The top-level key for the field of interest.

    Returns:
        any: The value of the nested 'value' key, or None if the field or
             the 'value' key does not exist.
    """
    field_obj = data.get(field_name)
    if isinstance(field_obj, dict):
        return field_obj.get("value")
    return None


def check_document_registry(doc_type: str, doc_number: str) -> dict:
    """
    Checks an official document registry in DynamoDB.

    Queries the DynamoDB registry table for a given document type and number to
    verify its existence and status.

    Args:
        doc_type (str): The type of the document (e.g., "PASSPORT", "DL").
        doc_number (str): The unique identification number of the document.

    Returns:
        dict: The item from the DynamoDB table if found. If the document is not
              found, or if an error occurs, returns a dictionary with an 'error' key.
    """
    if not doc_type or not doc_number:
        return {"error": "Missing info for registry check."}
    db_doc_type = {"DL": "DRIVER_LICENSE", "PASSPORT": "PASSPORT"}.get(doc_type)
    if not db_doc_type:
        return {"error": f"Unknown document type '{doc_type}' for registry lookup."}
    try:
        response = DOCUMENTS_REGISTRY_TABLE.get_item(
            Key={"DocumentType": doc_type, "DocumentNumber": doc_number}
        )
        item = response.get("Item")
        return item
    except ClientError as e:
        LOGGER.error(f"DynamoDB query failed for {db_doc_type}/{doc_number}: {e}")
        return {"error": f"DynamoDB query failed: {e.response['Error']['Message']}"}


def analyze_document_with_bedrock(
    image_bytes: bytes,
    file_type: str,
    extracted_data: dict,
    registry_data: dict,
    preliminary_flags: list,
) -> dict:
    """
    Analyzes a document image for fraud using a multimodal AI model.

    This function sends the document image, along with contextual data (extracted
    text, registry data, preliminary flags), to Amazon Bedrock for a comprehensive
    forensic analysis.

    Args:
        image_bytes (bytes): The document image encoded as bytes.
        file_type (str): The file extension of the image (e.g., "png", "jpeg").
        extracted_data (dict): Data previously extracted from the document image.
        registry_data (dict): Data retrieved from the official document registry, if any.
        preliminary_flags (list): A list of suspicious findings from earlier checks.

    Returns:
        dict: A structured dictionary from the AI model containing the fraud
              assessment, including 'is_fraud', 'risk_level', 'risk_score',
              and 'fraud_reasons'. Returns a default high-risk assessment on failure.
    """
    try:
        image_base64 = base64.b64encode(image_bytes).decode("utf-8")
        prompt = f"""
        You are a world-class forensic document fraud detection expert. Your task is to analyze the provided image of an official document ({file_type}) and determine if it is fraudulent.
        You have been given the following information from preliminary checks:
        1.  **Preliminary Forensic & Data Flags:** {json.dumps(preliminary_flags) if preliminary_flags else "None"}
        2.  **Data Extracted from Document Image:** {json.dumps(extracted_data, indent=2)}
        3.  **Official Registry Data for Comparison:** {json.dumps(registry_data, indent=2) if registry_data else "No registry data available."}
        
        Carefully perform the following analysis on the image:
        - **Visual Anomaly Detection:** Look for signs of digital tampering, such as inconsistent fonts, incorrect kerning/spacing, pixelation around text fields, unnatural lighting, flat or missing holograms, incorrect microprint, and artifacts from editing software.
        - **Data Consistency Check:** Cross-reference the data visible in the image against the 'Extracted Data' and 'Official Registry Data'. Note any mismatches.
        - **Holistic Assessment:** Combine the preliminary flags, your visual analysis, and the data consistency check to make a final judgment. The preliminary flags are especially important; consider them strong indicators.
        
        Based on your complete analysis, provide your response ONLY in the following JSON format. Do not include any text before or after the JSON object.
        {{
            "is_fraud": <true_or_false>,
            "risk_level": "<LOW, MEDIUM, or HIGH>",
            "risk_score": <an integer score from 0 to 100, where 100 is definitive fraud>,
            "fraud_reasons": [
                "<A clear, concise reason for your findings. Example: 'The date of birth on the document appears digitally altered, as the font does not match other fields.'>",
                "<Another reason, if applicable.>"
            ]
        }}
        """
        body = json.dumps(
            {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 4000,
                "temperature": 0.3,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": f"image/{file_type}",
                                    "data": image_base64,
                                },
                            },
                            {"type": "text", "text": prompt},
                        ],
                    }
                ],
            }
        )
        response = BEDROCK.invoke_model(
            body=body,
            modelId=BEDROCK_MODEL_ID,
            contentType="application/json",
            accept="application/json",
        )
        response_body = json.loads(response.get("body").read())
        return json.loads(response_body["content"][0]["text"])
    except (ClientError, json.JSONDecodeError) as e:
        LOGGER.error(f"Bedrock analysis failed: {e}", exc_info=True)
        return {
            "is_fraud": True,
            "risk_level": "HIGH",
            "risk_score": 90,
            "fraud_reasons": ["AI analysis failed, flagging for manual review."],
        }


def _update_extracted_files_table(
    docvault_id: str,
    extracted_file_name: str,
    is_fraud: bool,
    fraud_reasons: list = None,
):
    """
    Updates the ExtractedFiles table in DynamoDB with the fraud detection results.

    Args:
        docvault_id (str): The unique identifier for the document's parent folder/vault.
        extracted_file_name (str): The specific name of the file record to update.
        is_fraud (bool): The final fraud status (True or False).
        fraud_reasons (list, optional): A list of reasons for the fraud assessment.
                                       Defaults to None.

    Returns:
        None
    """
    try:
        if is_fraud:
            EXTRACTED_FILES_TABLE.update_item(
                Key={
                    "DocVaultId": docvault_id,
                    "ExtractedFileName": extracted_file_name,
                },
                UpdateExpression="SET #FraudFlag = :FraudFlag, #FraudMessage = :FraudMessage",
                ExpressionAttributeNames={
                    "#FraudFlag": "FraudFlag",
                    "#FraudMessage": "FraudMessage",
                },
                ExpressionAttributeValues={
                    ":FraudFlag": True,
                    ":FraudMessage": json.dumps(fraud_reasons),
                },
            )
        else:
            EXTRACTED_FILES_TABLE.update_item(
                Key={
                    "DocVaultId": docvault_id,
                    "ExtractedFileName": extracted_file_name,
                },
                UpdateExpression="SET #FraudFlag = :FraudFlag",
                ExpressionAttributeNames={"#FraudFlag": "FraudFlag"},
                ExpressionAttributeValues={":FraudFlag": False},
            )
        LOGGER.info(
            f"DynamoDB updated for {docvault_id}/{extracted_file_name}, FraudFlag: {is_fraud}"
        )
    except ClientError as e:
        LOGGER.error(
            f"Error updating DynamoDB for {docvault_id}/{extracted_file_name}: {e}",
            exc_info=True,
        )


def lambda_handler(event, context):
    """
    The main entry point for the AWS Lambda function.

    This function orchestrates the entire fraud detection workflow. It retrieves
    document data, performs a series of preliminary checks (metadata, ELA, noise,
    registry lookup), invokes an AI model for deep analysis, and records the
    final result in DynamoDB.

    Args:
        event (dict): The event data passed to the Lambda function, typically from
                      a Step Function, containing S3 keys for the original document
                      and its extracted data.
        context (object): The AWS Lambda runtime context object, providing information
                         about the invocation, function, and execution environment.

    Raises:
        ValueError: If required fields are missing from the event payload or if an
                    unsupported file type is submitted for analysis.

    Returns:
        dict: A standard API Gateway response dictionary containing the final
              fraud assessment in the body, along with the status code.
    """
    log_format = f"In {context.function_name}.%(funcName)s %(message)s"
    formatter = logging.Formatter(log_format)
    if LOGGER.handlers:
        LOGGER.handlers[0].setFormatter(formatter)
    LOGGER.info(f"Received event: {json.dumps(event)}")
    request_id = context.aws_request_id
    LOGGER.info(f"Starting fraud detection for Request ID: {request_id}")

    if "body" in event and isinstance(event.get("body"), str):
        try:
            event = json.loads(event["body"])
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Malformed JSON body"}),
            }

    response_body = {
        "is_fraud": False,
        "risk_score": 0,
        "risk_level": "LOW",
        "fraud_reasons": [],
        "error": None,
    }
    preliminary_flags = []

    original_key = event.get("Original S3 Key")
    extracted_key = event.get("Extraction S3 Location")

    docvault_id, extracted_file_name = None, None  # Initialize outside try for scope

    try:
        classification = event.get("Classification")
        if not all([original_key, extracted_key, classification]):
            raise ValueError(
                "Missing required fields: 'Original S3 Key', 'Extraction S3 Location', or 'Classification'."
            )

        docvault_id, extracted_file_name = (
            extracted_key.split("/")[-2],
            extracted_key.split("/")[-1],
        )
        LOGGER.info(
            f"Processing DocVaultID: {docvault_id}, File: {extracted_file_name}"
        )

        file_stream = get_s3_object_as_bytestream(DOCVAULTS_BUCKET, original_key)
        extracted_data = get_s3_json_as_dict(DOCVAULTS_BUCKET, extracted_key)
        compared_data = extracted_data.get("compared_data", {})

        doc_type, doc_number, name, dob_str, expiry_str = (None, None, None, None, None)
        if classification == "US-Passport":
            doc_type = "PASSPORT"
            details = compared_data.get("PASSPORT_DETAILS", {})
            doc_number = _get_field_value(details, "PASSPORT_NUMBER")
            name = _get_field_value(details, "NAME")
            dob_str = _get_field_value(details, "DATE_OF_BIRTH")
            expiry_str = _get_field_value(details, "EXPIRATION_DATE")
        elif classification == "US-Driver-License":
            doc_type = "DL"
            doc_number = _get_field_value(compared_data, "ID_NUMBER")
            name = _get_field_value(compared_data, "NAME")
            dob_str = _get_field_value(compared_data, "DATE_OF_BIRTH")
            expiry_str = _get_field_value(compared_data, "EXPIRATION_DATE")

        if dob_str and datetime.strptime(dob_str, "%Y-%m-%d").date() > date.today():
            preliminary_flags.append("Date of Birth is in the future.")
        if (
            expiry_str
            and datetime.strptime(expiry_str, "%Y-%m-%d").date() < date.today()
        ):
            preliminary_flags.append("Document is expired.")

        registry_item = {}
        if doc_number:
            registry_item = check_document_registry(doc_type, doc_number)
            if not registry_item:
                preliminary_flags.append("Document not found in official registry.")
            elif registry_item.get("error"):
                preliminary_flags.append(
                    f"Registry check failed: {registry_item['error']}"
                )
            else:
                if registry_item.get("Status", "").lower() != "active":
                    preliminary_flags.append(
                        "Registry status for document is not 'active'."
                    )
                if name and name.lower() != registry_item.get("Name", "").lower():
                    preliminary_flags.append("Name does not match registry.")
                if dob_str and dob_str != registry_item.get("DOB"):
                    preliminary_flags.append("Date of Birth does not match registry.")
                else:
                    preliminary_flags.append("Found document in official registry.")
                    _update_extracted_files_table(
                        docvault_id, extracted_file_name, False
                    )
                    return {
                        "statusCode": 200 if not response_body["error"] else 500,
                        "body": json.dumps(response_body),
                        "Extraction S3 Location": extracted_key,
                        "bucket name": DOCVAULTS_BUCKET,
                    }

        file_extension = original_key.split(".")[-1].lower()
        if file_extension not in ["jpg", "jpeg", "png", "pdf"]:
            raise ValueError(f"Unsupported file type for analysis: {file_extension}")

        image_bytes = file_stream.getvalue()
        image_file_type = "png" if file_extension == "pdf" else file_extension

        if file_extension == "pdf":
            pdf_tamper_results = analyze_pdf_for_tampering(io.BytesIO(image_bytes))
            if pdf_tamper_results["is_suspicious"]:
                preliminary_flags.extend(pdf_tamper_results["reasons"])

            if not PDF_SUPPORT_ENABLED:
                raise ValueError(
                    "PDF file submitted, but PDF processing library is not available for visual analysis."
                )
            try:
                pdf_doc = fitz.open(stream=image_bytes, filetype="pdf")
                page = pdf_doc.load_page(0)
                pix = page.get_pixmap(dpi=300)
                buffer = io.BytesIO()
                pix.save(buffer, output="png")
                image_bytes = buffer.getvalue()
                pdf_doc.close()
            except Exception as e:
                raise ValueError(f"Could not process PDF file for visual analysis: {e}")

        if PILLOW_SUPPORT_ENABLED:
            image_obj = Image.open(io.BytesIO(image_bytes))
            buffer = io.BytesIO()
            image_obj.save(buffer, format="PNG")
            image_bytes = buffer.getvalue()
            image_file_type = "png"

            meta_results = analyze_image_metadata(image_obj)
            if meta_results["is_suspicious"]:
                preliminary_flags.extend(meta_results["reasons"])

            ela_results = perform_ela(image_obj)
            if ela_results["is_suspicious"]:
                preliminary_flags.extend(ela_results["reasons"])

            noise_results = analyze_background_noise(image_obj)
            if noise_results["is_suspicious"]:
                preliminary_flags.extend(noise_results["reasons"])

        bedrock_result = analyze_document_with_bedrock(
            image_bytes=image_bytes,
            file_type=image_file_type,
            extracted_data=compared_data,
            registry_data=registry_item,
            preliminary_flags=preliminary_flags,
        )
        response_body.update(bedrock_result)
        response_body["fraud_reasons"].extend(preliminary_flags)
        response_body["fraud_reasons"] = list(
            dict.fromkeys(response_body["fraud_reasons"])
        )

    except Exception as e:
        LOGGER.error(
            f"An unhandled exception occurred for Request ID {request_id}: {e}",
            exc_info=True,
        )
        response_body.update(
            {
                "error": "An internal server error occurred.",
                "is_fraud": True,
                "risk_level": "HIGH",
                "risk_score": 95,
            }
        )
        response_body["fraud_reasons"].append(
            "An unexpected system error occurred during processing."
        )

    LOGGER.info(
        f"Fraud detection complete. Final Risk Score: {response_body['risk_score']}, Level: {response_body['risk_level']}"
    )

    if docvault_id and extracted_file_name:
        _update_extracted_files_table(
            docvault_id,
            extracted_file_name,
            response_body["risk_score"] > 60,
            response_body["fraud_reasons"],
        )
    else:
        LOGGER.warning(
            f"Could not update DynamoDB as DocVaultId or ExtractedFileName was not available for Request ID: {request_id}"
        )

    return {
        "statusCode": 200 if not response_body["error"] else 500,
        "body": json.dumps(response_body),
        "Extraction S3 Location": extracted_key,
        "bucket name": DOCVAULTS_BUCKET,
    }
