"""
This Lambda function fetches file details from DynamoDB tables and calculates and returns metrics to generate dashboards upon
"""

import json
import os
from datetime import datetime, timedelta
import logging
import pandas as pd
import numpy as np
from IDPutils import response, get_current_time, get_item, query_items
import boto3

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

USERS_TABLE = os.environ['USERS_TABLE']
FILES_TABLE = os.environ['FILES_TABLE']
EXTRACTED_FILES_TABLE = os.environ['EXTRACTED_FILES_TABLE']
DOCVAULTS_TABLE = os.environ['DOCVAULTS_TABLE']
ACCESS_TABLE = os.environ['ACCESS_TABLE']

HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Content-Type": "application/json"
}

class CustomJSONEncoder(json.JSONEncoder):
    """
    Custom JSON encoder to handle non-standard types like NumPy integers/floats and Pandas Timestamps.

    This encoder extends the default JSONEncoder to provide serialization for data types
    commonly encountered when working with data analysis libraries like NumPy and Pandas,
    ensuring they can be properly converted to standard Python types (int, float, str)
    for JSON serialization.
    """
    def default(self, obj):
        """
        Overrides the default method to serialize specific object types.

        Args:
            obj: The object to serialize.

        Returns:
            int or float or str: The serialized representation of the object.
            Any: The default JSONEncoder serialization for other types.
        """
        if isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.float64, np.float32)):
            return float(obj)
        elif isinstance(obj, (pd.Timestamp, datetime)):
            return obj.isoformat()
        return super().default(obj)



def get_classification_distribution(extracted_files):
    """
    Calculates the distribution of document classifications from extracted files.

    This function takes a list of extracted file records, converts them into a Pandas DataFrame,
    identifies unique files, and then counts the occurrences of each document classification.
    The result is formatted for a pie chart visualization.

    Args:
        extracted_files (list): A list of dictionaries, each representing an extracted file
                                 record, expected to contain 'FileName' and 'ClassificationName'.

    Returns:
        dict: A dictionary containing 'type' (pie), 'data' (labels, values, title)
              representing the classification distribution. Returns an error structure
              if an exception occurs or no data is available.
    """
    try:
        df = pd.DataFrame(extracted_files)
        # Handle empty DataFrame
        if df.empty:
            return {
                'type': 'pie',
                'data': {
                    'labels': ['No Data'],
                    'values': [1],
                    'title': 'Document Classification Distribution'
                }
            }

        # Get unique files (remove duplicates)
        unique_files = df.drop_duplicates(subset=['FileName'])

        # Get counts for ALL classifications, sorted by count descending
        classification_counts = unique_files['ClassificationName'].value_counts()

        # Convert to native Python types
        return {
            'type': 'pie',
            'data': {
                'labels': classification_counts.index.astype(str).tolist(),
                'values': classification_counts.astype(int).tolist(),
                'title': 'Document Classification Distribution'
            }
        }
    except Exception as e:
        LOGGER.error("In IDP-Dashboards-Lambda.get_classification_distribution Error in classification distribution: %s" , e)
        return {
            'type': 'pie',
            'data': {
                'labels': ['Error'],
                'values': [1],
                'title': 'Error in Classification Distribution'
            }
        }

def get_extraction_accuracy(extracted_files, original_files):
    """
    Calculates the extraction accuracy by classification based on low confidence flags.

    This function merges extracted file data with original file data to determine
    the `ExtractStatus` and `LowConfidenceFlag`. It then calculates the accuracy
    (1 - mean of LowConfidenceFlag) for files with `ExtractStatus == 'Processed'`
    grouped by `ClassificationName`.

    Args:
        extracted_files (list): A list of dictionaries, each representing an extracted file
                                 record, expected to contain 'FileName', 'ClassificationName',
                                 and optionally 'LowConfidenceFlag'.
        original_files (list): A list of dictionaries, each representing an original file
                                record, expected to contain 'FileName' and 'ExtractStatus'.

    Returns:
        dict: A dictionary containing 'type' (bar), 'data' (x-axis labels, y-axis values,
              title, y-label, and metadata) representing the extraction accuracy.
              Returns an error structure if an exception occurs or data is insufficient.
    """
    try:
        # Convert inputs to DataFrames
        extracted_df = pd.DataFrame(extracted_files)
        original_df = pd.DataFrame(original_files)

        # Early return if no data or missing required columns
        if extracted_df.empty or original_df.empty or 'ClassificationName' not in extracted_df.columns or 'FileName' not in extracted_df.columns:
            return {
                'type': 'bar',
                'data': {
                    'x': [],
                    'y': [],
                    'title': 'Extraction Accuracy by Classification',
                    'y_label': 'Accuracy (%)'
                }
            }

        # Merge dataframes on FileName
        merged_df = pd.merge(
            extracted_df,
            original_df[['FileName', 'ExtractStatus']],
            on='FileName',
            how='left'
        )

        # Filter only processed files
        if 'ExtractStatus' in merged_df.columns:
            merged_df = merged_df[merged_df['ExtractStatus'] == 'Processed']

        # Return empty result if no processed files
        if merged_df.empty:
            return {
                'type': 'bar',
                'data': {
                    'x': [],
                    'y': [],
                    'title': 'Extraction Accuracy (No Processed Files)',
                    'y_label': 'Accuracy (%)',
                    'metadata': {
                        'filter': "ExtractStatus == 'Processed'",
                        'processed_files': 0
                    }
                }
            }

        # Handle missing LowConfidenceFlag - assume False if not present
        if 'LowConfidenceFlag' not in merged_df.columns:
            merged_df['LowConfidenceFlag'] = False
        else:
            # Convert to boolean if it's string 'True'/'False'
            if merged_df['LowConfidenceFlag'].dtype == object:
                merged_df['LowConfidenceFlag'] = merged_df['LowConfidenceFlag'].apply(
                    lambda x: str(x).lower() == 'true' if pd.notna(x) else False
                )
            # Fill any remaining NaN values with False
            merged_df['LowConfidenceFlag'] = merged_df['LowConfidenceFlag'].fillna(False)

        # Get unique files (remove duplicates)
        unique_files = merged_df.drop_duplicates(subset=['FileName'])

        # Calculate accuracy per classification
        accuracy = unique_files.groupby('ClassificationName', observed=True).agg({
            'LowConfidenceFlag': lambda x: round((1 - x.mean()) * 100, 2)
        }).reset_index()

        # Sort by accuracy descending
        accuracy = accuracy.sort_values('LowConfidenceFlag', ascending=False)

        return {
            'type': 'bar',
            'data': {
                'x': accuracy['ClassificationName'].astype(str).tolist(),
                'y': accuracy['LowConfidenceFlag'].astype(float).tolist(),
                'title': 'Extraction Accuracy by Classification (Processed Files)',
                'y_label': 'Accuracy (%)',
                'metadata': {
                    'total_files': len(unique_files),
                    'classifications_count': len(accuracy),
                    'filter': "ExtractStatus == 'Processed'"
                }
            }
        }

    except Exception as e:
        LOGGER.error("In IDP-Dashboards-Lambda.get_classification_distribution Error in extraction accuracy: %s" , e)
        return {
            'type': 'bar',
            'data': {
                'x': [],
                'y': [],
                'title': 'Error in Accuracy Calculation',
                'y_label': 'Accuracy (%)',
                'metadata': {
                    'error': str(e)
                }
            }
        }

def get_monthly_trends(original_files):
    """
    Analyzes the monthly processing trends of original files.

    This function filters original file records to include only 'Processed' or 'Processing'
    files, extracts the month from their 'CreatedAt' timestamp, and counts the number
    of files processed or in processing for each month. The result is formatted
    for a line chart visualization.

    Args:
        original_files (list): A list of dictionaries, each representing an original file
                                record, expected to contain 'CreatedAt' and 'ExtractStatus'.

    Returns:
        dict: A dictionary containing 'type' (line), 'data' (x-axis labels, y-axis values,
              title, y-label, and metadata) representing the monthly processing trend.
    """
    # Convert to DataFrame and filter by status
    df = pd.DataFrame(original_files)

    # Filter for only Processed or Processing files
    valid_statuses = ['Processed', 'Processing']
    df = df[df['ExtractStatus'].isin(valid_statuses)]

    # Extract month and count
    df['Month'] = pd.to_datetime(df['CreatedAt']).dt.to_period('M').astype(str) if 'CreatedAt' in df.columns else '2025-07-04T06:28:39.707134'
    monthly = df.groupby('Month').size().reset_index(name='count')

    return {
        'type': 'line',
        'data': {
            'x': monthly['Month'].tolist(),
            'y': monthly['count'].tolist(),
            'title': 'Monthly Processing Trend (Processed/Processing Files)',
            'y_label': 'Files Processed',
            'metadata': {
                'filter': 'ExtractStatus in ["Processed", "Processing"]',
                'total_files': int(df.shape[0])
            }
        }
    }

def get_fraud_by_classification(original_files, extracted_files):
    """
    Calculates the percentage of fraudulent files by classification.

    This function merges original and extracted file data to identify files flagged
    as fraudulent (`FraudFlag == True`) within specific classifications (currently
    'US-Passport' and 'US-Driver-License'). It calculates the total files and
    fraudulent files for each classification and determines the fraud percentage.

    Args:
        original_files (list): A list of dictionaries, each representing an original file
                                record, expected to contain 'DocVaultId' and 'FileName'.
        extracted_files (list): A list of dictionaries, each representing an extracted file
                                 record, expected to contain 'DocVaultId', 'FileName',
                                 'ClassificationName', and optionally 'FraudFlag'.

    Returns:
        dict: A dictionary containing 'type' (fraud_by_class), 'data' (classifications
              metrics, title, y-label, and warnings) representing fraud percentages.
              Returns an error structure if an exception occurs or data is insufficient.
    """
    try:
        files_df = pd.DataFrame(original_files)
        filtered_extracted_files = [file for file in extracted_files if file['ClassificationName'] in ['US-Passport' , 'US-Driver-License']]
        extracted_df = pd.DataFrame(filtered_extracted_files)
        results = []

        if not files_df.empty and not extracted_df.empty:
            # Ensure required columns exist
            if 'FraudFlag' not in extracted_df.columns:
                extracted_df['FraudFlag'] = False

            # Safe merge
            merged_df = pd.merge(
                extracted_df,
                files_df[['DocVaultId', 'FileName']],
                on=['DocVaultId', 'FileName'],
                how='left',
                indicator=True
            )

            if not merged_df.empty and 'ClassificationName' in merged_df.columns:
                # Convert FraudFlag to boolean if needed
                merged_df['FraudFlag'] = merged_df['FraudFlag'].astype(bool)

                classification_groups = merged_df.groupby('ClassificationName', observed=True)

                for name, group in classification_groups:
                    total = len(group)
                    fraud_count = group['FraudFlag'].sum()

                    percentage = round(
                        (fraud_count / total * 100) if total > 0 else 0.0,
                        2
                    )

                    results.append({
                        'classification': str(name),
                        'total_files': int(total),
                        'fraud_files': int(fraud_count),
                        'fraud_percentage': float(percentage),
                        'sample_size_warning': total < 10
                    })

        results_sorted = sorted(results, key=lambda x: x['fraud_percentage'], reverse=True)

        return {
            'type': 'fraud_by_class',
            'data': {
                'classifications': results_sorted,
                'title': 'Fraud Percentage by Classification',
                'y_label': 'Fraud Percentage (%)',
                'warnings': {
                    'no_data': len(results) == 0,
                    'small_samples': any(r['sample_size_warning'] for r in results)
                }
            }
        }

    except Exception as e:
        LOGGER.error("In IDP-Dashboards-Lambda.get_classification_distribution Error in fraud analysis: %s" , e)
        return {
            'type': 'fraud_by_class',
            'data': {
                'classifications': [],
                'title': 'Fraud Analysis Error',
                'y_label': 'Fraud Percentage (%)',
                'warnings': {
                    'no_data': True,
                    'error': str(e)
                }
            }
        }

def get_lowconfidence_by_classification(original_files, extracted_files):
    """
    Calculates the percentage of low confidence extractions by classification.

    This function merges original and extracted file data to identify files flagged
    with low confidence (`LowConfidenceFlag == True`). It then calculates the total
    files and low confidence files for each classification and determines the
    low confidence percentage.

    Args:
        original_files (list): A list of dictionaries, each representing an original file
                                record, expected to contain 'DocVaultId' and 'FileName'.
        extracted_files (list): A list of dictionaries, each representing an extracted file
                                 record, expected to contain 'DocVaultId', 'FileName',
                                 'ClassificationName', and optionally 'LowConfidenceFlag'.

    Returns:
        dict: A dictionary containing 'type' (lowconfidence_by_class), 'data' (classifications
              metrics, title, y-label, and warnings) representing low confidence percentages.
              Returns an error structure if an exception occurs or data is insufficient.
    """
    try:
        files_df = pd.DataFrame(original_files)
        # filtered_extracted_files = [file for file in extracted_files if file['ClassificationName'] in ['US-Passport' , 'US-Driver-License']]
        extracted_df = pd.DataFrame(extracted_files)
        results = []

        if not files_df.empty and not extracted_df.empty:
            # Ensure required columns exist
            if 'LowConfidenceFlag' not in extracted_df.columns:
                extracted_df['LowConfidenceFlag'] = False

            # Safe merge
            merged_df = pd.merge(
                extracted_df,
                files_df[['DocVaultId', 'FileName']],
                on=['DocVaultId', 'FileName'],
                how='left',
                indicator=True
            )

            if not merged_df.empty and 'ClassificationName' in merged_df.columns:
                # Convert FraudFlag to boolean if needed
                merged_df['LowConfidenceFlag'] = merged_df['LowConfidenceFlag'].astype(bool)

                classification_groups = merged_df.groupby('ClassificationName', observed=True)

                for name, group in classification_groups:
                    total = len(group)
                    fraud_count = group['LowConfidenceFlag'].sum()

                    percentage = round(
                        (fraud_count / total * 100) if total > 0 else 0.0,
                        2
                    )

                    results.append({
                        'classification': str(name),
                        'total_files': int(total),
                        'fraud_files': int(fraud_count),
                        'fraud_percentage': float(percentage),
                        'sample_size_warning': total < 10
                    })

        results_sorted = sorted(results, key=lambda x: x['fraud_percentage'], reverse=True)

        return {
            'type': 'lowconfidence_by_class',
            'data': {
                'classifications': results_sorted,
                'title': 'Low Confidence Percentage by Classification',
                'y_label': 'Low Confidence Percentage (%)',
                'warnings': {
                    'no_data': len(results) == 0,
                    'small_samples': any(r['sample_size_warning'] for r in results)
                }
            }
        }

    except Exception as e:
        LOGGER.error("In IDP-Dashboards-Lambda.get_classification_distribution Error in fraud analysis: %s" , e)
        return {
            'type': 'fraud_by_class',
            'data': {
                'classifications': [],
                'title': 'Low Confidence Analysis Error',
                'y_label': 'Low Confidence Percentage (%)',
                'warnings': {
                    'no_data': True,
                    'error': str(e)
                }
            }
        }

def get_monthly_extraction_accuracy(original_files, extracted_files, time_bucket):
    """
    Calculates monthly (or quarterly/yearly) extraction accuracy and fraud rate trends.

    This function merges original and extracted file data, groups them by time period
    ('month', 'quarter', or 'year' based on `time_bucket`), and calculates the
    extraction accuracy (based on `LowConfidenceFlag`) and fraud rate
    (based on `FraudFlag`) for each period.

    Args:
        original_files (list): A list of dictionaries, each representing an original file
                                record, expected to contain 'DocVaultId', 'FileName', and 'CreatedAt'.
        extracted_files (list): A list of dictionaries, each representing an extracted file
                                 record, expected to contain 'DocVaultId', 'FileName',
                                 and optionally 'LowConfidenceFlag' and 'FraudFlag'.
        time_bucket (str): The desired time granularity for grouping. Can be 'monthly',
                           'quarterly', 'yearly', or 'auto'. 'auto' will choose based
                           on the number of unique months.

    Returns:
        dict: A dictionary containing 'type' (monthly_accuracy), 'data' (metrics for
              each period, title, y-axis labels, and warnings) representing the trends.
              Returns an error structure if an exception occurs.
    """
    try:
        files_df = pd.DataFrame(original_files)
        extracted_df = pd.DataFrame(extracted_files)

        # Check for required columns
        if 'CreatedAt' not in files_df.columns:
            files_df['CreatedAt'] = datetime.utcnow().isoformat()

        # Merge data
        merged_df = pd.merge(
            extracted_df,
            files_df[['DocVaultId', 'FileName', 'CreatedAt']],
            on=['DocVaultId', 'FileName'],
            how='left'
        )

        # Handle missing timestamps
        merged_df['CreatedAt'] = pd.to_datetime(
            merged_df['CreatedAt'],
            errors='coerce',
            utc=True
        ).fillna(pd.Timestamp.now(tz='UTC'))

        # Extract time period
        merged_df['Month'] = merged_df['CreatedAt'].dt.to_period('M')

        if time_bucket == 'auto':
            time_bucket = 'quarterly' if len(merged_df['Month'].unique()) > 12 else 'monthly'

        if time_bucket != 'monthly':
            merged_df['Period'] = merged_df['Month'].apply(
                lambda m: f"{m.year}-Q{m.quarter}" if time_bucket == 'quarterly' else str(m.year)
            )
            group_col = 'Period'
        else:
            group_col = 'Month'

        # Initialize default values for metrics
        if 'LowConfidenceFlag' not in merged_df.columns:
            merged_df['LowConfidenceFlag'] = False
        if 'FraudFlag' not in merged_df.columns:
            merged_df['FraudFlag'] = False
        if 'ExtractStatus' not in merged_df.columns:
            merged_df['ExtractStatus'] = 'Processed'

        monthly_stats = []
        for period, group in merged_df.groupby(group_col, observed=True):
            total = len(group)
            if total == 0:
                continue

            correct_extractions = len(group[group['LowConfidenceFlag'] is False])
            accuracy = round((correct_extractions / total) * 100, 2)

            fraud_count = group['FraudFlag'].sum()
            fraud_rate = round((fraud_count / total) * 100, 2)

            monthly_stats.append({
                'period': str(period),
                'total_files': int(total),
                'accuracy': float(accuracy),
                'fraud_detected': int(fraud_count),
                'fraud_rate': float(fraud_rate),
                'status_distribution': {
                    'Processed': int(len(group[group['ExtractStatus'] == 'Processed'])),
                    'Failed': int(len(group[group['ExtractStatus'] == 'Failed']))
                }
            })

        monthly_stats_sorted = sorted(monthly_stats, key=lambda x: x['period'])

        return {
            'type': 'monthly_accuracy',
            'data': {
                'metrics': monthly_stats_sorted,
                'title': 'Monthly Extraction Accuracy',
                'y_axis': {
                    'accuracy': 'Accuracy (%)',
                    'fraud_rate': 'Fraud Rate (%)'
                },
                'warnings': {
                    'small_sample': any(m['total_files'] < 10 for m in monthly_stats_sorted)
                }
            }
        }

    except Exception as e:
        LOGGER.error("In IDP-Dashboards-Lambda.get_classification_distribution Error in monthly accuracy: %s" , e)
        return {
            'type': 'monthly_accuracy',
            'data': {
                'metrics': [],
                'title': 'Monthly Accuracy Error',
                'y_axis': {
                    'accuracy': 'Accuracy (%)',
                    'fraud_rate': 'Fraud Rate (%)'
                },
                'warnings': {
                    'error': str(e)
                }
            }
        }

def get_processing_metrics(original_files):
    """
    Calculates overall file processing metrics, including status distribution and processing rate.

    This function analyzes the `ExtractStatus` of original files to determine the
    counts of files in 'Processed', 'Unprocessed', 'Processing', and 'Failed' states.
    It also calculates the overall processing rate.

    Args:
        original_files (list): A list of dictionaries, each representing an original file
                                record, expected to contain 'ExtractStatus'.

    Returns:
        dict: A dictionary containing 'type' (stats_bar), 'data' (total files,
              processed files, processing rate, status distribution, and title)
              representing the processing overview.
    """
    files_df = pd.DataFrame(original_files)

    # Initialize all possible statuses with zero counts
    status_counts = {
        'Processed': 0,
        'Unprocessed': 0,
        'Processing': 0,
        'Failed': 0
    }

    # Update with actual counts from data
    if 'ExtractStatus' in files_df.columns:
        current_counts = files_df['ExtractStatus'].value_counts().to_dict()
        for status in status_counts:
            if status in current_counts:
                status_counts[status] = int(current_counts[status])  # Convert numpy.int64 to native int

    # Calculate processing rate (handle division by zero)
    total_files = len(files_df)
    processed_files = status_counts['Processed']
    processing_rate = round((processed_files / total_files * 100) if total_files > 0 else 0.0)

    return {
        'type': 'stats_bar',
        'data': {
            'stats': {
                'total_files': int(total_files),
                'processed_files': int(processed_files),
                'processing_rate': float(processing_rate)  # Ensures JSON serializable
            },
            'status_distribution': status_counts,
            'title': 'Processing Metrics'
        }
    }

def get_all_metrics(original_files , extracted_files , time_bucket):
    """
    Aggregates and returns all dashboard metrics.

    This function calls various sub-functions to calculate different metrics
    (classification distribution, processing metrics, class-wise accuracy,
    monthly trends, fraud analysis, monthly extraction accuracy, and low confidence analysis)
    and combines them into a single dictionary.

    Args:
        original_files (list): A list of dictionaries representing original file records.
        extracted_files (list): A list of dictionaries representing extracted file records.
        time_bucket (str): The desired time granularity for monthly extraction accuracy
                           (e.g., 'monthly', 'quarterly', 'auto').

    Returns:
        dict: A dictionary containing all calculated dashboard metrics.
    """
    return {
        'classification': get_classification_distribution(extracted_files),
        'processing': get_processing_metrics(original_files),
        'classwise_accuracy': get_extraction_accuracy(extracted_files, original_files),
        'trends': get_monthly_trends(original_files),
        'last_updated': datetime.utcnow().isoformat(),
        'fraud': get_fraud_by_classification(original_files, extracted_files),
        'monthwise_accuracy' : get_monthly_extraction_accuracy(original_files, extracted_files, time_bucket)
        # 'lowconfidence': get_lowconfidence_by_classification(original_files, extracted_files)
    }

def lambda_handler(event, context):
    """
    Main Lambda function handler to retrieve and process dashboard metrics.

    This function is the entry point for the Lambda. It authenticates the user,
    fetches accessible document vaults, retrieves all original and extracted file
    data from DynamoDB for those vaults, and then calls `get_all_metrics` to
    generate the dashboard data.

    Args:
        event (dict): The Lambda event object, expected to contain 'requestContext'
                      with authorizer claims (for username) and optionally
                      'QueryStringParameters' for 'time_bucket'.
        context (object): The Lambda context object.

    Returns:
        dict: A dictionary representing the HTTP response, containing statusCode,
              headers, and a JSON string body with the dashboard metrics.
              Returns an error response if an exception occurs or the user is not found.
    """
    try:
        LOGGER.info("In IDP-Dashboards-Lambda.lambda_handler, Event: %s" , event)
        username = event['requestContext']['authorizer']['claims']['preferred_username']

        user = get_item(
            USERS_TABLE,
            key={
                'Username': username
            }
        )

        if not user:
            return response(
                404,
                {"Message":'User not found'}
            )
        query_params = event.get('QueryStringParameters')

        time_bucket = query_params.get('time_bucket', 'auto') if query_params else 'auto'
        user = get_item(
            USERS_TABLE,
            key={
                'Username': username
            }
        )
        if not user:
            return response(
                404,
                {"Message":'User not found'}
            )

        accessible_docvaults = []
        owned_docvaults = query_items(
            DOCVAULTS_TABLE,
            index_name='CreatedBy-Index',
            key_condition_expression='CreatedBy = :username',
            expression_values={
                ':username': username
            }
        )
        shared_docvaults = query_items(
            ACCESS_TABLE,
            key_condition_expression='Username = :username',
            expression_values={
                ':username': username
            }
        )

        for docvault in owned_docvaults:
            accessible_docvaults.append(docvault['DocVaultId'])
        for docvault in shared_docvaults:
            accessible_docvaults.append(docvault['DocVaultId'])

        extracted_files = []
        original_files = []


        if not accessible_docvaults:
            return response(
                200,
                {
                    'message': 'No accessible docvaults found'
                }
            )
        for docvault_id in accessible_docvaults:
            extracted_files.extend(query_items(
                EXTRACTED_FILES_TABLE,
                key_condition_expression='DocVaultId = :docvault_id',
                expression_values={
                    ':docvault_id': docvault_id
                }
            ))
            original_files.extend(query_items(
                FILES_TABLE,
                key_condition_expression='DocVaultId = :docvault_id',
                expression_values={
                    ':docvault_id': docvault_id
                }
            ))

        dashboards = get_all_metrics(original_files , extracted_files , time_bucket)

        if not dashboards:
            return response(
                200,
                {
                    'message': 'No data'
                }
            )

        # return {
        #     'statusCode': 200,
        #     'headers': HEADERS,
        #     'body': json.dumps(dashboards , cls=CustomJSONEncoder)
        # }
        return response(200, dashboards)
    except Exception as e:
        LOGGER.error("In IDP-Dashboards-Lambda.lambda_handler Error in lambda_handler: %s" , e)
        return response(500, e)
