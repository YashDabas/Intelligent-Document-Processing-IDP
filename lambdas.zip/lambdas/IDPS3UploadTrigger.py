"""
This module defines an AWS Lambda function that triggers an AWS Step Function execution
when a batch of files has been fully uploaded to an S3 bucket and corresponding classification
metadata exists in a DynamoDB table.
"""

import os
import json
import logging
import boto3
from botocore.exceptions import ClientError
from IDPutils import query_items, update_item

AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")
STEP_FUNCTION = boto3.client("stepfunctions", region_name=AWS_REGION)
S3_CLIENT = boto3.client("s3", region_name=AWS_REGION)

CLASSIFICATIONS_TABLE_NAME = os.environ.get(
    "CLASSIFICATIONS_TABLE", "IDP-Classifications-Table"
)
STEP_FUNCTION_ARN = os.environ.get(
    "CLASSIFICATIONS_SFN_ARN",
    "arn:aws:states:us-east-1:043309350924:stateMachine:idp-classification-stepfn",
)
INDEX_NAME = os.environ.get("CLASSIFICATIONS_TABLE_INDEX1", "BatchId-index")
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)


def lambda_handler(event, context):
    """
    AWS Lambda handler that processes S3 event records to trigger a Step Function.

    This function is invoked by S3 notifications when new objects are created in a
    designated bucket. For each new object, it extracts a `batch_id` from the object
    key. It then performs the following checks:
    1. Queries a DynamoDB table to find the corresponding batch metadata.
    2. Verifies that the batch status is 'uploading'.
    3. Counts the number of files in the S3 prefix for that batch.

    If exactly 5 files have been uploaded and the status is 'uploading', the function
    atomically updates the status in DynamoDB to 'processing' using a conditional
    write to prevent race conditions. If the update is successful, it triggers the
    execution of an AWS Step Function with a payload containing batch details.

    Args:
        event (dict): The event payload from the S3 trigger, containing one or
                      more object creation records.
        context (object): The AWS Lambda runtime context object, providing
                          invocation metadata.

    Returns:
        None: The function's outputs are side effects (logging, DB updates,
              Step Function execution) and it does not return a value.
    """
    log_format = f"In {context.function_name}.%(funcName)s %(message)s"
    formatter = logging.Formatter(log_format)
    if LOGGER.handlers:
        LOGGER.handlers[0].setFormatter(formatter)

    for record in event["Records"]:
        bucket = record["s3"]["bucket"]["name"]
        key = record["s3"]["object"]["key"]

        parts = key.split("/")
        if len(parts) < 3:
            LOGGER.info(f"Invalid key format: {key}")
            continue

        batch_id = parts[1]

        LOGGER.info(f"Checking classification metadata for batch: {batch_id}")

        # Use the query_items utility function
        items_response = query_items(
            table_name=CLASSIFICATIONS_TABLE_NAME,
            index_name=INDEX_NAME,
            key_condition_expression="BatchId = :batch_id",
            expression_values={":batch_id": batch_id},
        )

        # The util can return a tuple for pagination; handle both cases
        items = (
            items_response[0] if isinstance(items_response, tuple) else items_response
        )

        if not items:
            LOGGER.info(f"No classification metadata found in DB for batch: {batch_id}")
            continue

        item = items[0]

        if item.get("Status") != "uploading":
            LOGGER.info(
                f"Batch {batch_id} is already in status '{item.get('Status')}'. Skipping trigger."
            )
            continue

        # count number of files uploaded in the batch
        response = S3_CLIENT.list_objects_v2(
            Bucket=bucket, Prefix=f"uploads/{batch_id}/"
        )
        files_uploaded = response.get("Contents", [])

        # trigger only when exactly 5 files are present
        if len(files_uploaded) != 5:
            LOGGER.info(f"[{batch_id}] Uploaded: {len(files_uploaded)} / 5 — Waiting")
            continue

        input_payload = {
            "username": item["CreatedBy"],
            "classification_name": item["ClassificationName"],
            "batch_id": batch_id,
            "files": [f["Key"] for f in files_uploaded],
        }

        try:
            primary_key = {"ClassificationName": item["ClassificationName"]}

            # Use the update_item utility function
            update_item(
                table_name=CLASSIFICATIONS_TABLE_NAME,
                key=primary_key,
                update_expression="SET #s = :new_status",
                expression_attributes={
                    ":new_status": "processing",
                    ":old_status": "uploading",
                },
                condition_expression="#s = :old_status",
                expression_attribute_names={"#s": "Status"},
            )

            LOGGER.info(
                f"Status for batch {batch_id} updated to 'processing'. Starting Step Function."
            )
            STEP_FUNCTION.start_execution(
                stateMachineArn=STEP_FUNCTION_ARN, input=json.dumps(input_payload)
            )

        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                LOGGER.warning(
                    f"Batch {batch_id} was already locked by another process. Skipping trigger."
                )
            else:
                LOGGER.error(
                    f"Error starting Step Function or updating status for batch {batch_id}: {e}"
                )
        except Exception as e:
            LOGGER.error(f"A general error occurred for batch {batch_id}: {e}")
