"""
Function Handling the User's APIs and SignUp
"""

import os
import json
import boto3
import logging
import inspect
from typing import Any
from datetime import datetime
from boto3.dynamodb.conditions import Key

# Setting up the logger.
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

DYNAMO_RESOURCE = boto3.resource("dynamodb")
ACCESS_TABLE_NAME = os.environ["ACCESS_TABLE_NAME"]
ACCESS_TABLE = DYNAMO_RESOURCE.Table(ACCESS_TABLE_NAME)
ACCESS_DOCVAULT_ID_GSI = os.environ["ACCESS_DOCVAULT_ID_GSI"]
CLASSIFICATIONS_TABLE_NAME = os.environ["CLASSIFICATION_TABLE_NAME"]
CLASSIFICATIONS_TABLE = DYNAMO_RESOURCE.Table(CLASSIFICATIONS_TABLE_NAME)
CREATED_BY_CLASSIFICATION_NAME_GSI = os.environ("CREATED_BY_CLASSIFICATION_NAME_GSI")
DOCVAULTS_TABLE_NAME = os.environ["DOCVAULTS_TABLE_NAME"]
DOCVAULTS_TABLE = DYNAMO_RESOURCE.Table(DOCVAULTS_TABLE_NAME)
DOCVAULTS_CREATED_BY_GSI = os.environ["DOCVAULTS_CREATED_BY_GSI"]
EXTRACTED_FILES_TABLE_NAME = os.environ["EXTRACTED_FILES_TABLE_NAME"]
EXTRACTED_FILES_TABLE = DYNAMO_RESOURCE.Table(EXTRACTED_FILES_TABLE_NAME)
FILES_TABLE_NAME = os.environ["FILES_TABLE_NAME"]
FILES_TABLE = DYNAMO_RESOURCE.Table(FILES_TABLE_NAME)
TOKENS_TABLE_NAME = os.environ["TOKENS_TABLE_NAME"]
TOKENS_TABLE = DYNAMO_RESOURCE.Table(TOKENS_TABLE_NAME)
USERS_TABLE_NAME = os.environ["USERS_TABLE_NAME"]
USERS_TABLE = DYNAMO_RESOURCE.Table(USERS_TABLE_NAME)
USERS_EMAIL_GSI = os.environ["USERS_EMAIL_GSI"]

COGNITO_CLIENT = boto3.client("cognito-idp")
COGNITO_USER_POOL_ID = os.environ["USER_POOL_ID"]

S3_CLIENT = boto3.client("s3")
DOCVAULTS_BUCKET = os.environ["DOCVAULTS_BUCKET"]

SECRETS_MANAGER_CLIENT = boto3.client("secretsmanager")

SES_CLIENT = boto3.client("ses")

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With",
    "Access-Control-Allow-Credentials": "true",
    "Content-Type": "application/json"
}

LAMBDA_NAME = None

NOW = lambda: datetime.now().isoformat()

CURRENT_FUNC_NAME = lambda: inspect.stack()[1][3]


class UserEmailExistsError(Exception):
    pass

class UserDeletionUnsuccessfulError(Exception):
    pass


def cognito_pre_sign_up(event: dict[str, Any]) -> dict[str, Any]:
    """
        Handles the pre sign up authentication flow for Cognito.

        Checks if the email being used to sign up is already being used or not.

        Args:
            event(dict[str, Any]): Lambda Event passed by the API Gateway. Contains the user information passed by Cognito.

        Returns:
            dict: The same event that was passed as the input.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    try:
        email = event["request"]["userAttributes"]["email"]

        LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nChecking if the email being used to sign up: {email} already exists or not.")
        check_email_existence = USERS_TABLE.query(
            IndexName=USERS_EMAIL_GSI,
            KeyConditionExpression=Key("Email").eq(email)
        )

        # Checking if the query produced a non-empty result
        if check_email_existence.get("Count", 0) > 0:
            LOGGER.error(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nEmail: {email} already exists. Aborting sign-up.")
            raise UserEmailExistsError(f"Email: {email} already exists. Aborting sign-up.")
        
    except Exception as e:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to query Users Table. ERROR: {str(e)}")
        raise Exception("Could not validate email address. Please try again.")

    LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nEmail: {email} is available. Allowing sign-up")
    return event


def cognito_post_confirmation(event: dict[str, Any]) -> dict[str, Any]:
    """
        Handles the post confirmation authentication flow for Cognito.

        Adds the user to the Users' DB and adds their username as the preferred_username to maintain uniformity with Google SignUp.

        Args:
            event(dict[str, Any]): Lambda Event passed by the API Gateway. Contains the user information passed by Cognito.

        Returns:
            dict: The same event that was passed as the input.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    try:
        username = event["userName"]
        user_attributes = event["request"]["userAttributes"]
        email = user_attributes["email"]
        first_name = user_attributes.get("given_name", "")
        last_name = user_attributes.get("family_name", "")

        # If the user has signed up using Google, the flow is different. Will add them after asking them for a username
        if user_attributes.get("cognito:user_status", None) == "EXTERNAL_PROVIDER":
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser sign up has been initiated via Google. Continuing to ask for the username.")
            return event

        # Add the username as the preferred_username just to have uniformity with the users that have/will sign up with Google
        COGNITO_CLIENT.admin_update_user_attributes(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=username,
            UserAttributes=[
                {
                    "Name": "preferred_username", 
                    "Value": username
                }
            ]
        )

        # All the required fields for a user.
        user_item = {
            "CognitoUsername": username,
            "Username": username,
            "Email": email,
            "FirstName": first_name,
            "LastName": last_name,
            "IdentityProvider": "Cognito", # Cognito has been used to sign up on the platform
            "CreatedAt": NOW(),
            "LastModifiedAt": NOW(),
            "LastModifiedBy": username
        }

        # Add the user to the Users Table
        USERS_TABLE.put_item(Item=user_item)

        # Verifying the user's email in SES
        SES_CLIENT.verify_email_identity(EmailAddress=email)

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} sign up using Cognito complete.")
        return event

    except Exception as e:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nError while authenticating and adding user to application: {str(e)}", exc_info=True)

        # Deleting the user if there arises any issue due to which the user couldn't be added to the application. Will have to re-try the sign up process.
        COGNITO_CLIENT.admin_delete_user(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=username
        )

        return event


def google_sign_up_username_completion(event: dict[str, Any]) -> dict[str, Any]:
    """
        Handles the POST call for the Users.

        This call is meant only for the users that have signed up using Google. This call asks them to give a username for readability and ease of searching.

        Args:
            event(dict[str, Any]): Lambda Event passed by the API Gateway. Contains the user information passed by Cognito.
                - username: The username that the user has selected for themselves. Present in the body of the event
        
        Returns:
            dict: The HTTP response object with a status code, body, and CORS related headers.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    try:
        body = json.loads(event["body"])
        username = body.get("Username")

        # Fetching the user details from ID Token passed to the API
        cognito_claims = event.get("requestContext", {}).get("authorizer", {}).get("claims", {})
        cognito_username = cognito_claims["cognito:username"]
        first_name = cognito_claims["given_name"]
        last_name = cognito_claims["family_name"]
        email = cognito_claims["email"]

        # Check for the existence of the username provided by the user.
        check_username_validity = USERS_TABLE.get_item(Key={"Username": username})
        if "Item" in check_username_validity:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nUsername: {username} is already taken. Asking user to enter a new unique username.")
            return {
                "statusCode": 400,
                "body": json.dumps({"Message": "The username entered is already taken. Try another."}), # If the username exists the user has to choose another username
                "headers": CORS_HEADERS
            }

        # Updating the users Cognito profile to have this Username as the preferred_username
        COGNITO_CLIENT.admin_update_user_attributes(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=cognito_username,
            UserAttributes=[
                {
                    "Name": "preferred_username", 
                    "Value": username
                }
            ]
        )

        # All the required fields for a user.
        user_item = {
            "CognitoUsername": cognito_username,
            "Username": username,
            "Email": email,
            "FirstName": first_name,
            "LastName": last_name,
            "IdentityProvider": "Google", # Google has been used to sign up on the platform
            "CreatedAt": NOW(),
            "LastModifiedAt": NOW(),
            "LastModifiedBy": username
        }

        # Add the user to the Users Table
        USERS_TABLE.put_item(Item=user_item)

        # Verifying the user's email in SES
        SES_CLIENT.verify_email_identity(EmailAddress=email)

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} sign up using Google complete.")
        return {
            "statusCode": 200,
            "body": json.dumps({"Message": "User signed up. Welcome."}),
            "headers": CORS_HEADERS
        }
    
    except Exception as e:
        LOGGER.error(f"""Error in function: {function_name} in lambda: {LAMBDA_NAME}.
                     Issue with the signin up the user via Google. Deleting the User. Ask them to try signing in again.\n{str(e)}""", 
                     exc_info=True)

        # Deleting the user if he cannot complete the signup process and cannot be added to the application. Will have to re-try the sign up process
        COGNITO_CLIENT.admin_delete_user(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=cognito_username
        )

        return {
            "statusCode": 500,
            "body": json.dumps({"Message": f"Error while completing user sign up: {str(e)}"}),
            "headers": CORS_HEADERS
        }


def get_all_users():
    """
        Handles the GET call for listing all the user present on the application

        Returns:
             dict: The HTTP response object with a status code, body, and CORS related headers.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    try:
        user_scan = USERS_TABLE.scan(ProjectionExpression="Username, Email")

        # Check if any users exist or not
        if user_scan["Count"] == 0:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nNo users have signed up yet. Nothing to fetch.")
            return {
                "statusCode": 200,
                "body": json.dumps({"Message":"No users have signed up yet."}),
                "headers": CORS_HEADERS
            }

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nSuccessfully fetched the users list")
        return {
            "statusCode": 200,
            "body": json.dumps({"Users": user_scan["Items"]}),
            "headers": CORS_HEADERS
        }

    except Exception as e:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nError fetching the users list.", exc_info=True)
        return {
            "statusCode": 500,
            "body": json.dumps({"Message": f"Error while fetching the user list: {str(e)}"}),
            "headers": CORS_HEADERS
        }


def get_user(event: dict[str, Any]) -> dict[str, Any]:
    """
        Handles the GET call for a specific user.

        Provides all the details regarding the individual user.

        Args:
            event(dict[str, Any]): Lambda Event passed by the API Gateway. 
                - username: Username of the user to be updated. Present in the path parameters.

        Returns:
            dict: The HTTP response object with a status code, body, and CORS related headers.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    # The user who is calling the delete function
    USER = event.get("requestContext", {}).get("authorizer", {}).get("claims", {}).get("preferred_username", "")

    # The user who is to be deleted
    username = event["pathParameters"]["username"]

    try:
        # Only the user themselves see their information
        if username != USER:
            LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUserNotAuthorizedError: {USER} is not authorized to get details of another user: {username}.")
            return {
                "statusCode": 403,
                "body": json.dumps({"Message": f"Access Denied. {USER} is not authorized to get details of another user: {username}."}),
                "headers": CORS_HEADERS
            }

        # Check for the existence of the user
        user = USERS_TABLE.get_item(Key={"Username": username},
                                    ProjectionExpression="Username, Email, FirstName, LastName")
        if "Item" not in user:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} does not exist. Nothing to fetch.")
            return {
                "statusCode": 200,
                "body": json.dumps({"Message": f"User: {username} does not exist."}),
                "headers": CORS_HEADERS
            }

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} successfully fetched.")
        return {
            "statusCode": 200,
            "body": json.dumps({"User": user["Item"]}), # Return the entire information regarding the user
            "headers": CORS_HEADERS
        }
    
    except Exception as e:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nError fetching the user: {username}", exc_info=True)
        return {
            "statusCode": 500,
            "body": json.dumps({"Message": f"Error while fetching the user: {str(e)}"}),
            "headers": CORS_HEADERS
        }


def update_user(event: dict[str, Any]) -> dict[str, Any]:
    """
        Handles the PUT/PATCH (update) calls for Uses.

        Allows the updation of user's First Name and Last Name.

        Args:
            event(dict[str, Any]): Lambda Event passed by the API Gateway. 
                - username: Username of the user to be updated. Present in the path parameters.
                - body: Contains the the attributes to be updated and the new values.
        
        Returns:
            dict: The HTTP response object with a status code, body, and CORS related headers.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    # The user who is calling the delete function
    USER = event.get("requestContext", {}).get("authorizer", {}).get("claims", {}).get("cognito:username", "")

    # The user who is to be deleted
    username = event["pathParameters"]["username"]

    body = json.loads(event["body"])

    # If FirstName and LastName aren't present then we can continue without updation since the other fields are immutable fields.
    if "FirstName" not in body and "LastName" not in body:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nFirstName and LastName were not present in the body. Stopping updation.")
        return {
            "statusCode": 400,
            "body": json.dumps({"Message": "No items to be updated."}),
            "headers": CORS_HEADERS
        }

    # If the user who requested the updation isn't the user whose details are being updated, then we shouldn't allow it.
    # Only a user can change their own details.
    if username != USER:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUserNotAuthorizedError: {USER} is not authorized to delete another user: {username}.")
        return {
            "statusCode": 403,
            "body": json.dumps({"Message": f"Access Denied. {USER} is not authorized to update {username} details."}),
            "headers": CORS_HEADERS
        }

    # Checking for the presence of immutable fields trying to be updated 
    immutable_attributes = ["CognitoUsername", "Username", "Email", "IdentityProvider", "CreatedAt", "LastModifiedAt", "LastModifiedBy"]
    immutable_in_request = [attr for attr in immutable_attributes if attr in body]
    if immutable_in_request:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nAttributeNotSupportedError: Immutable Attribute(s) detected: {immutable_in_request}. Stopping updation.")
        return {
            "statusCode": 400,
            "body": json.dumps({"Message": f"The following attribute(s) cannot be updated: {', '.join(immutable_in_request)}."}),
            "headers": CORS_HEADERS
        }

    # Check if the user even exists
    check_user_existence = USERS_TABLE.get_item(Key={"Username": username})
    if "Item" not in check_user_existence:
        LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} does not exist. Cannot proceed further with updation. Stopping updation.")
        return {
            "statusCode": 200,
            "body": json.dumps({"Message": f"User: {username} does not exists."}),
            "headers": CORS_HEADERS
        }
    cognito_username = check_user_existence["Item"]["CognitoUsername"]

    modification_updates = {
        "LastModifiedAt": NOW(),
        "LastModifiedBy": USER
    }

    # Creating the update expression and the corresponding attributes
    combined_data = {**body, **modification_updates}
    update_expression = "SET " + " ,".join([f"{key} = :{key}" for key in combined_data.keys()])
    attribute_values = {f":{key}": value for key, value in combined_data.items()}

    # Getting a list of the attributes as Cognito expects
    attributes_to_update = []
    for key, value in body.items():
        if key == "FirstName":
            attributes_to_update.append({"Name": "given_name", "Value": value})
        if key == "LastName":
            attributes_to_update.append({"Name": "family_name", "Value": value})

    if attributes_to_update:
        try:
            # Updating the attributes in Cognito
            COGNITO_CLIENT.admin_update_user_attributes(
                UserPoolId=COGNITO_USER_POOL_ID,
                Username=cognito_username,
                UserAttributes=attributes_to_update
            )
        except Exception as e:
            LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nError while updating attributes in Cognito: {str(e)}", exc_info=True)
            return {
                "statusCode": 500,
                "body": json.dumps({"Message": f"Error while updating attributes in Cognito: {str(e)}"}),
                "headers": CORS_HEADERS
            }

    try:
        # Updating the attributes in the DynamoDB Table
        response = USERS_TABLE.update_item(
            Key={"Username": username},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=attribute_values,
            ReturnValues="ALL_NEW")

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} has been updated.")
        return {
            "statusCode": 200,
            "body": json.dumps({"Message": "User updated successfully.", "Item": response["Attributes"]}),
            "headers": CORS_HEADERS
        }

    except Exception as e:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nError while updating attributes in Users Table: {str(e)}", exc_info=True)
        return {
            "statusCode": 500,
            "body": json.dumps({"Message": f"Error while updating attributes in Users Table: {str(e)}"}),
            "headers": CORS_HEADERS
        }


def delete_user(event: dict[str, Any]) -> dict[str, Any]:
    """
        Handles the DELETE call for Users.

        Deletes the user from both the Users Table in DynamoDB and the Cognito User Pool.

        Args:
            event(dict[str, Any]): Lambda Event passed by the API Gateway. 
                - username: Username of the user to be deleted. Present in the path parameters.
        
        Returns:
            dict: The HTTP response object with a status code, body, and CORS related headers.
    """

    # Getting the current function name
    function_name = CURRENT_FUNC_NAME()
    LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

    # The user who is calling the delete function
    USER = event.get("requestContext", {}).get("authorizer", {}).get("claims", {}).get("cognito:username", "")

    # The user who is to be deleted
    username = event["pathParameters"]["username"]
    
    if username != USER:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUserNotAuthorizedError: {USER} is not authorized to delete another user: {username}.")
        return {
            "statusCode": 403,
            "body": json.dumps({"Message": f"Access Denied. {USER} is not authorized to update {username} details."}),
            "headers": CORS_HEADERS
        }

    # Check for use existence
    check_user_existence = USERS_TABLE.get_item(Key={"Username": username})

    # If not found, return a message mentioning the same
    if "Item" not in check_user_existence:
        LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} does not exist. Cannot proceed further with deletion. Stopping deletion.")
        return {
            "statusCode": 200,
            "body": json.dumps({"Message": f"User: {username} does not exists."}),
            "headers": CORS_HEADERS
        }
    
    cognito_username = check_user_existence["Item"]["CognitoUsername"]
    email = check_user_existence["Item"]["Email"]

    # Function to delete all the files in particular docvault
    def delete_docvault_files(docvault_id: str) -> None:
        """
            Deletes all the files - Original and Extracted DocVaults created by the user who is to be deleted.

            Args:
                docvault_id(str): Id of the DocVault from where the files are to be deleted.
            
            Returns:
                None
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        # Get all the original files present in the requested DocVault
        try:
            original_files_fetch = FILES_TABLE.query(KeyConditionExpression=Key("DocVaultId").eq(docvault_id))
        except Exception as e:
            LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable fetch original files present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")
            raise UserDeletionUnsuccessfulError(f"Unable fetch original files present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")

        if original_files_fetch.get("Count", 0) == 0:
            LOGGER.info(f"No files present in the DocVault with ID: {docvault_id}")
            return
        
        else:
            original_files = [file_item["FileName"] for file_item in original_files_fetch["Items"]]

            # Handle Pagination if the data exceeds 1MB.
            try:
                while "LastEvaluatedKey" in original_files_fetch:
                    original_files_fetch = FILES_TABLE.query(
                        KeyConditionExpression=Key("DocVaultId").eq(docvault_id),
                        ExclusiveStartKey=original_files_fetch['LastEvaluatedKey']
                    )
                    original_files.extend([file_item["FileName"] for file_item in original_files_fetch["Items"]])
            except Exception as e:
                LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable fetch original files (in while) present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")
                raise UserDeletionUnsuccessfulError(f"Unable fetch original files (in while) present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")

            # Delete the original files fetched
            for file_name in original_files:
                try:
                    FILES_TABLE.delete_item(Key={
                        "DocVaultId": docvault_id,
                        "FileName": file_name
                        },
                        ReturnValues="ALL_OLD"
                    )
                    S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f"original/{docvault_id}/{file_name}")
                except Exception as e:
                    LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable delete original file: {file_name} present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")
                    raise UserDeletionUnsuccessfulError(f"Unable delete original file: {file_name} present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")

        # Get all the extracted files present in the requested DocVault
        try:
            extracted_files_fetch = EXTRACTED_FILES_TABLE.query(KeyConditionExpression=Key("DocVaultId").eq(docvault_id))
        except Exception as e:
            LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable fetch extracted files present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")
            raise UserDeletionUnsuccessfulError(f"Unable fetch extracted files present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")

        if extracted_files_fetch.get("Count", 0) == 0:
            LOGGER.info(f"No extracted files present in the DocVault with ID: {docvault_id}")
            return 
        
        else:
            extracted_files = [file_item["FileName"] for file_item in extracted_files_fetch["Items"]]

            # Handle Pagination if the data exceeds 1MB.
            try:
                while "LastEvaluatedKey" in extracted_files_fetch:
                    extracted_files_fetch = EXTRACTED_FILES_TABLE.query(
                        KeyConditionExpression=Key("DocVaultId").eq(docvault_id),
                        ExclusiveStartKey=extracted_files_fetch['LastEvaluatedKey']
                    )
                    extracted_files.extend([file_item["FileName"] for file_item in extracted_files_fetch["Items"]])
            except Exception as e:
                LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable fetch extracted files (in while) present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")
                raise UserDeletionUnsuccessfulError(f"Unable fetch extracted files (in while) present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")

            # Delete the extracted files fetched
            for file_name in extracted_files:
                try:
                    EXTRACTED_FILES_TABLE.delete_item(Key={
                        "DocVaultId": docvault_id,
                        "ExtractedFileName": file_name
                        },
                        ReturnValues="ALL_OLD"
                    )
                    S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f"final-extracted/{docvault_id}/{file_name}")
                    S3_CLIENT.delete_object(Bucket=DOCVAULTS_BUCKET, Key=f"final-extracted/{docvault_id}/{file_name}.metadata.json")
                except Exception as e:
                    LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable delete extracted file: {file_name} present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")
                    raise UserDeletionUnsuccessfulError(f"Unable delete extracted file: {file_name} present in DocVault with ID: {docvault_id}. ERROR: {str(e)}")
        
        return

    def delete_user_docvaults(username: str) -> None:
        """
            Deletes all the DocVaults created by the user

            Args:
                username(str): Username of the user that is to be deleted.
            
            Returns:
                None
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        #Get all the DocVaults related to the user to be deleted
        get_user_docvaults = DOCVAULTS_TABLE.query(
            IndexName=DOCVAULTS_CREATED_BY_GSI,
            KeyConditionExpression=Key("CreatedBy").eq(username),
            ProjectionExpression="DocVaultId, DocVaultName, CreatedBy"
        )

        # Check if the user doesn't have any DocVaults
        if get_user_docvaults.get("Count", 0) == 0:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nNo docvaults to be deleted for user: {username}")
            return
        
        else:
            docvaults = get_user_docvaults["Items"]
            
            # Handle Pagination if the data exceeds 1MB.
            while "LastEvaluatedKey" in get_user_docvaults:
                get_user_docvaults = EXTRACTED_FILES_TABLE.query(
                    KeyConditionExpression=Key("DocVaultId").eq(docvault_id),
                    ExclusiveStartKey=get_user_docvaults['LastEvaluatedKey']
                )
                docvaults.extend(get_user_docvaults["Items"])

            for docvault in docvaults:
                docvault_id = docvault["DocVaultId"]
                docvault_name = docvault["DocVaultName"]
                try:
                    DOCVAULTS_TABLE.delete_item(Key={"DocVaultId": docvault_id}, ReturnValues="ALL_OLD")
                except Exception as e:
                    LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to delete DocVault: {docvault_name}; Id: {docvault_id} created by User: {username}. ERROR: {str(e)}")
                    raise UserDeletionUnsuccessfulError(f"Unable to delete DocVault: {docvault_name}; Id: {docvault_id} created by User: {username}. ERROR: {str(e)}")

                # Only delete the files once the docvault has been deleted
                try:
                    LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nProcessing deletion of files from DocVault: {docvault_name}.")
                    delete_docvault_files(docvault_id)
                except Exception as e:
                    LOGGER.ERROR(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to delete all the files belonging to DocVault: {docvault_name} with Id: {docvault_id} created by User: {username}. ERROR: {str(e)}")
                    raise e
                    
                # Only delete the sharing associations related once the docvault has been deleted
                try:
                    LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nProcessing deletion of access associated with DocVault: {docvault_name}.")
                    delete_docvaults_access(docvault_id, username)
                except Exception as e:
                    LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to delete all the files belonging to DocVault: {docvault_name} with Id: {docvault_id} created by User: {username}. ERROR: {str(e)}")
                    raise e

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nDeleted {len(get_user_docvaults)} DocVaults belonging to user: {username}.")
        return
    
    def delete_user_classifications(username: str) -> None:
        """
            Deletes all the Classifications created by the user

            Args:
                username(str): Username of the user that is to be deleted.
            
            Returns:
                None
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        # Get all the classifications created by a user
        get_user_classifications = CLASSIFICATIONS_TABLE.query(
            IndexName=CREATED_BY_CLASSIFICATION_NAME_GSI,
            KeyConditionExpression=Key("CreatedBy").eq(username),
            ProjectionExpression="ClassificationName"
        )

        # Check if the user doesn't have any classifications
        if get_user_classifications.get("Count", 0) == 0:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nNo classifications to be deleted for user: {username}")
            return
        
        else:
            classifications = [classifications["Name"] for classifications in get_user_classifications]
            
            # Handle Pagination if the data exceeds 1MB.
            while "LastEvaluatedKey" in get_user_classifications:
                get_user_classifications = EXTRACTED_FILES_TABLE.query(
                    KeyConditionExpression=Key("CreatedBy").eq(username),
                    ExclusiveStartKey=get_user_classifications['LastEvaluatedKey']
                )
                classifications.extend([classifications["Name"] for classifications in get_user_classifications])

            for classification in classifications:
                classification_name = classification["ClassificationName"]
                try:
                    CLASSIFICATIONS_TABLE.delete_item(
                        Key={
                            "ClassificationName": classification_name,
                            "CreatedBy": username
                            }, 
                        ReturnValues="ALL_OLD"
                    )
                except Exception as e:
                    LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to delete Classification: {classification_name} created by User: {username}. ERROR: {str(e)}")
                    raise UserDeletionUnsuccessfulError(f"Unable to delete Classification: {classification_name} created by User: {username}. ERROR: {str(e)}")

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nDeleted {len(get_user_classifications)} Classifications created by user: {username}.")
        return
    
    def delete_user_access(username: str) -> None:
        """
            Deletes all the sharing related associations of the User

            Args:
                username(str): Username of the user that is to be deleted.
            
            Returns:
                None
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        # Get all the access the user has
        get_user_related_access = ACCESS_TABLE.query(
            KeyConditionExpression=Key("Username").eq(username)
        )

        # Check if the user doesn't have access to any other DocVaults
        if get_user_related_access.get("Count", 0) == 0:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} has no access to other docvaults")
            return
        
        else:
            user_access = get_user_related_access["Items"]
            
            # Handle Pagination if the data exceeds 1MB.
            while "LastEvaluatedKey" in get_user_related_access:
                get_user_related_access = EXTRACTED_FILES_TABLE.query(
                    KeyConditionExpression=Key("Username").eq(username),
                    ExclusiveStartKey=get_user_related_access['LastEvaluatedKey']
                )
                user_access.extend(get_user_related_access["Items"])

            for access in user_access:
                docvault_id = access["DocVaultId"]
                try:
                    CLASSIFICATIONS_TABLE.delete_item(
                        Key={
                            "Username": username,
                            "DocVaultId": docvault_id
                            }, 
                        ReturnValues="ALL_OLD"
                    )
                except Exception as e:
                    LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to remove User: {username} access from DocVault with ID: {docvault_id}. ERROR: {str(e)}")
                    raise UserDeletionUnsuccessfulError(f"Unable to remove User: {username} access from DocVault with ID: {docvault_id}. ERROR: {str(e)}")
        
        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nRevoked all the access given to User: {username}")
        return

    def delete_docvaults_access(docvault_id: str, username: str) -> None:
        """
            Deletes all the sharing related associations of the given DocVaults.

            Args:
                username(str): Username of the user that is to be deleted.
            
            Returns:
                None
        """
            
        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        # Get all the access the docvault to be deleted has
        get_docvault_related_access = ACCESS_TABLE.query(
            IndexName=ACCESS_DOCVAULT_ID_GSI,
            KeyConditionExpression=Key("DocVaultId").eq(docvault_id)
        )

        if get_docvault_related_access.get("Count", 0) == 0:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nNo access given to DocVault with ID: {docvault_id}")
            return
        
        else:
            docvault_access = get_docvault_related_access["Items"]
            
            # Handle Pagination if the data exceeds 1MB.
            while "LastEvaluatedKey" in get_docvault_related_access:
                get_docvault_related_access = EXTRACTED_FILES_TABLE.query(
                    KeyConditionExpression=Key("DocVaultId").eq(docvault_id),
                    ExclusiveStartKey=get_docvault_related_access['LastEvaluatedKey']
                )
                docvault_access.extend(get_docvault_related_access["Items"])

            for access in docvault_access:
                user_given_access = access["Username"]
                try:
                    ACCESS_TABLE.delete_item(
                        Key={
                            "Username": user_given_access,
                            "DocVaultId": docvault_id
                            }, 
                        ReturnValues="ALL_OLD"
                    )
                except Exception as e:
                    LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to remove User: {user_given_access} access from DocVault with ID: {docvault_id} created by {username}. ERROR: {str(e)}")
                    raise UserDeletionUnsuccessfulError(f"Unable to remove User: {user_given_access} access from DocVault with ID: {docvault_id} created by {username}. ERROR: {str(e)}")
        
        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nRevoked all the access permissions related to DocVault with Id: {docvault_id}")
        return

    def delete_user_token(username: str) -> None:
        """
            Deletes the Google Drive token that belongs to the user

            Args:
                username(str): Username of the user that is to be deleted.
            
            Returns:
                None
        """

        # Getting the current function name
        function_name = CURRENT_FUNC_NAME()
        LOGGER.info(f"Entering function: {function_name} in lambda: {LAMBDA_NAME}")

        get_user_token = TOKENS_TABLE.get_item(
            Key={
                "Username": username,
                "Provider": "Google"
            }
        )

        # Check if the user has any token associated with him
        if "Item" not in get_user_token:
            LOGGER.info(f"In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} does not have any tokens associated with him.")
            return
        else:
            # Deleting the secret where the token is stored.
            secret_arn = get_user_token["Item"]["SecretARN"]
            try:
                SECRETS_MANAGER_CLIENT.delete_secret(
                    SecretId=secret_arn,
                    ForceDeleteWithoutRecovery=True
                )
            except Exception as e:
                LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to delete secret for token associated with user: {username} from Secrets Manager. ERROR: {str(e)}")
                raise UserDeletionUnsuccessfulError(f"Unable to delete secret for token associated with user: {username} from Secrets Manager. ERROR: {str(e)}")
            
            # Delete the token from the table
            try:
                TOKENS_TABLE.delete_item(
                    Key={"Username": username}
                )
            except Exception as e:
                LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nUnable to delete token associated with user: {username} from tokens table. ERROR: {str(e)}")
                raise UserDeletionUnsuccessfulError(f"Unable to delete token associated with user: {username} from tokens table. ERROR: {str(e)}")
        
        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nDeleted token associated with user: {username}")
        return


    try:
        # Deleting all the user docvaults, and the files belonging to those docvaults. Also removing anu sharing access to the given docvaults
        delete_user_docvaults(username)

        # Deleting all the user-defines classifications
        delete_user_classifications(username)

        # Deleting all the docvaults that have been shared with the user
        delete_user_access(username)

        # Deleting any Google drive token associated with the user.
        delete_user_token(username)

        # Deleting the user's email from the verified list in SES
        SES_CLIENT.delete_identity(email)

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nDeleted all the user related resources. Continuing to delete the user...")
    except UserDeletionUnsuccessfulError as e:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nFailed to delete all the user related resources. Aborting deletion...")
        return {
            "statusCode": 500,
            "body": json.dumps({"Message": f"Error: {str(e)}"}),
            "headers": CORS_HEADERS
        }

    try:
        # Delete from the Users' DB
        USERS_TABLE.delete_item(Key={"Username": username}, ReturnValues="ALL_OLD")

        # Delete from the applications Cognito AppClient
        COGNITO_CLIENT.admin_delete_user(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=cognito_username
        )

        LOGGER.info(f"SUCCESS. In function: {function_name} in lambda: {LAMBDA_NAME}.\nUser: {username} has been deleted.")
        return {
            "statusCode": 200,
            "body": json.dumps({"Message": f"User: {username} has been deleted."}),
            "headers": CORS_HEADERS
        }

    except Exception as e:
        LOGGER.error(f"Error in function: {function_name} in lambda: {LAMBDA_NAME}.\nError occurred while deleting user: {str(e)}", exc_info=True)
        return {
            "statusCode": 500,
            "body": json.dumps({"Message": f"Error occurred while deleting user.\nError: {str(e)}"}),
            "headers": CORS_HEADERS
        }


def lambda_handler(event, context) -> dict[str, Any]:
    """
        Main handler for the API Gateway Lambda proxy integration.

        This function processes the incoming request from the API Gateway, executes business logic, and returns a standard HTTP response object.

        Args:
            event(dict[str, Any]): API Gateway Lambda Proxy Input Format.
                Contains request data like httpMethod, resource, body, pathParameters, queryStringParameters.

            context(Object): Lambda context object. Provides runtime information.
        
        Returns:
            dict: The HTTP response object with a status code, body, and CORS related headers.
    """

    # Getting the Lambda Name
    global LAMBDA_NAME
    LAMBDA_NAME = context.function_name

    if "resource" not in event:
        match event["triggerSource"]:
            case "PreSignUp_SignUp":
                return cognito_pre_sign_up(event)
            case "PreSignUp_ExternalProvider":
                return cognito_pre_sign_up(event)
            case "PostConfirmation_ConfirmSignUp":
                return cognito_post_confirmation(event)
            case _:
                LOGGER.error(f"Error in lambda: {LAMBDA_NAME}.\nCognito Trigger Source: {event["triggerSource"]} not configured.")
                return {
                    "statusCode": 404,
                    "body": json.dumps({"Message": "Cognito Trigger not found."}),
                    "headers": CORS_HEADERS
                }
    else:
        resource = event["resource"]
        http_method = event["httpMethod"]

        match resource:
            case "/users":
                match http_method:
                    case "POST":
                        return google_sign_up_username_completion(event)
                    case "GET":
                        return get_all_users()
                    case _:
                        LOGGER.error(f"Error in lambda: {LAMBDA_NAME}.\nAPI Resource: {resource} not found.")
                        return {
                            "statusCode": 404,
                            "body": json.dumps({"Message": "API Resource not found"}),
                            "headers": CORS_HEADERS
                        }
            case "/users/{username}":
                match http_method:
                    case "GET":
                        return get_user(event)
                    case "PUT":
                        return update_user(event)
                    case "DELETE":
                        return delete_user(event)
                    case _:
                        LOGGER.error(f"Error in lambda: {LAMBDA_NAME}.\nAPI Resource: {resource} not found.")
                        return {
                            "statusCode": 404,
                            "body": json.dumps({"Message": "API Resource not found"}),
                            "headers": CORS_HEADERS
                        }
            case _:
                LOGGER.error(f"Error in lambda: {LAMBDA_NAME}.\nAPI Resource: {resource} not found.")
                return {
                    "statusCode": 404,
                    "body": json.dumps({"Message": "API Resource not found"}),
                    "headers": CORS_HEADERS
                }