import os
import json
import logging
import boto3
import time
import urllib.request
from jose import jwk, jwt
from jose.utils import base64url_decode
from botocore.exceptions import ClientError
from IDPutils import response, get_current_time, get_item, query_items, put_item, update_item

# Initialize logging with basic configuration
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

# AWS region where Cognito is deployed
AWS_REGION = 'us-east-1'

# Initialize Cognito client
COGNITO_CLIENT = boto3.client("cognito-idp")

try:
    # Get environment variables for Cognito configuration
    USER_POOL_ID = os.environ["USER_POOL_ID"]  # Cognito User Pool ID
    CLIENT_ID = os.environ["CLIENT_ID"]       # Cognito App Client ID
except KeyError as e:
    LOGGER.error("In lambdaAuthorizer.__init__, Error in environment variables: %s", e)
    raise KeyError(f"Error in environment variables : {e}")

# Construct issuer and JWKS endpoint URLs for token verification
COGNITO_ISSUER = f"https://cognito-idp.{AWS_REGION}.amazonaws.com/{USER_POOL_ID}"
JWKS_URL = f"{COGNITO_ISSUER}/.well-known/jwks.json"

# Load JWKS keys to verify the signature of JWT tokens
LOGGER.info("In lambdaAuthorizer.__init__, Loading JWKS keys from %s", JWKS_URL)
with urllib.request.urlopen(JWKS_URL) as response:
    jwks = json.loads(response.read().decode("utf-8"))["keys"]
LOGGER.info("In lambdaAuthorizer.__init__, Successfully loaded %d JWKS keys", len(jwks))

def generate_policy(principal_id, effect, resource, context=None):
    """
    Generate an IAM policy document to control access to API Gateway endpoint.
    
    Args:
        principal_id (str): The principal identifier (usually the user's username)
        effect (str): Either 'Allow' or 'Deny' to specify access
        resource (str): The resource ARN that the policy applies to
        context (dict, optional): Additional context data to pass to the API
        
    Returns:
        dict: A policy document in the format expected by API Gateway
    """
    LOGGER.info("In lambdaAuthorizer.generate_policy, Generating policy for principal %s with effect %s on resource %s", 
                principal_id, effect, resource)
    policy = {
        "principalId": principal_id,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [{
                "Action": "execute-api:Invoke",
                "Effect": effect,
                "Resource": resource
            }]
        },
        "context": context or {}
    }
    LOGGER.debug("In lambdaAuthorizer.generate_policy, Generated policy: %s", policy)
    return policy

def verify_jwt_token(token):
    """
    Verify a JWT token using the Cognito JWKS public keys.
    
    Args:
        token (str): The JWT token to verify
        
    Returns:
        dict: The decoded claims from the token if verification succeeds
        
    Raises:
        Exception: If verification fails for any reason
    """
    LOGGER.info("In lambdaAuthorizer.verify_jwt_token, Starting JWT token verification")
    try:
        # Get unverified headers to find the key ID
        headers = jwt.get_unverified_headers(token)
        kid = headers["kid"]
        LOGGER.debug("In lambdaAuthorizer.verify_jwt_token, Found key ID in token headers: %s", kid)
        
        # Find the matching key in JWKS
        key_index = next((i for i, key in enumerate(jwks) if key["kid"] == kid), None)
        if key_index is None:
            raise Exception("Public key not found in JWKS")
        LOGGER.debug("In lambdaAuthorizer.verify_jwt_token, Found matching key at index %d", key_index)

        # Construct public key and verify signature
        public_key = jwks[key_index]
        key = jwk.construct(public_key)
        message, encoded_signature = token.rsplit('.', 1)
        decoded_signature = base64url_decode(encoded_signature.encode("utf-8"))

        if not key.verify(message.encode("utf-8"), decoded_signature):
            raise Exception("Signature verification failed")
        LOGGER.debug("In lambdaAuthorizer.verify_jwt_token, Signature verification succeeded")

        # Verify token claims
        claims = jwt.get_unverified_claims(token)
        LOGGER.info("In lambdaAuthorizer.verify_jwt_token, Token claims: %s", claims)
        
        # Check token expiration
        if time.time() > claims["exp"]:
            raise Exception("Token is expired")
        LOGGER.debug("In lambdaAuthorizer.verify_jwt_token, Token is not expired")

        # Verify issuer matches Cognito
        if claims["iss"] != COGNITO_ISSUER:
            raise Exception("Invalid issuer")
        LOGGER.debug("In lambdaAuthorizer.verify_jwt_token, Issuer verification succeeded")

        # Verify audience matches our client ID
        if claims["aud"] != CLIENT_ID:
            raise Exception("Invalid audience")
        LOGGER.debug("In lambdaAuthorizer.verify_jwt_token, Audience verification succeeded")

        # Ensure required claims are present
        if "preferred_username" not in claims:
            raise Exception("preferred_username claim not found in ID token")
        LOGGER.debug("In lambdaAuthorizer.verify_jwt_token, Required claims present in token")

        LOGGER.info("In lambdaAuthorizer.verify_jwt_token, JWT token verification completed successfully")
        return claims
        
    except Exception as e:
        LOGGER.error("In lambdaAuthorizer.verify_jwt_token, JWT verification failed: %s", e)
        raise
    
def lambda_handler(event, context):
    """
    Lambda function entry point for API Gateway custom authorizer.
    
    Args:
        event (dict): The event data from API Gateway
        context (LambdaContext): Runtime information about the Lambda function
        
    Returns:
        dict: An IAM policy document allowing or denying access to the API
    """
    LOGGER.info("In lambdaAuthorizer.lambda_handler, Lambda authorizer invoked")
    try:
        LOGGER.debug("In lambdaAuthorizer.lambda_handler, Received event: %s", json.dumps(event, indent=2))

        # Get query string parameters from the request
        query_params = event.get("queryStringParameters", {})
        id_token = query_params.get("token", "")
        method_arn = event.get("methodArn", "*")
        LOGGER.debug("In lambdaAuthorizer.lambda_handler, Extracted token: %s, methodArn: %s", 
                     'present' if id_token else 'missing', method_arn)

        if not method_arn:
            LOGGER.error("In lambdaAuthorizer.lambda_handler, Missing methodArn in event")
            return generate_policy("unauthorized", "Deny", "*")

        if not id_token:
            LOGGER.warning("In lambdaAuthorizer.lambda_handler, ID token is missing in query parameters")
            return generate_policy("unauthorized", "Deny", method_arn)

        # Verify the JWT token
        claims = verify_jwt_token(id_token)
        LOGGER.info("In lambdaAuthorizer.lambda_handler, Token verified for user: %s", claims['preferred_username'])

        # Extract user information from claims
        username = claims["preferred_username"]
        email = claims.get("email", "")
        
        # Prepare additional user attributes from claims
        user_attributes = {
            "email": email,
            "email_verified": claims.get("email_verified", "false"),
            "name": claims.get("name"),
            "given_name": claims.get("given_name"),
            "family_name": claims.get("family_name")
        }
        LOGGER.debug("In lambdaAuthorizer.lambda_handler, User attributes extracted: %s", user_attributes)

        # Generate allow policy with user context
        policy = generate_policy(username, "Allow", method_arn, {
            "username": username,
            "email": email,
            **user_attributes
        })
        LOGGER.info("In lambdaAuthorizer.lambda_handler, Access granted for user %s", username)
        return policy

    except Exception as e:
        LOGGER.exception("In lambdaAuthorizer.lambda_handler, Unhandled exception in authorizer: %s", e)
        return generate_policy("unauthorized", "Deny", event.get("methodArn", "*"))
