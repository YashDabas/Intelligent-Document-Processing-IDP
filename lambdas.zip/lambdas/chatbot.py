import json
import os
import boto3
import logging
from datetime import datetime, timezone
import time
import random
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from IDPutils import response, get_current_time, get_item, query_items, put_item, update_item

# Initialize environment variables from Lambda configuration
KNOWLEDGE_BASE_ID = os.environ["KNOWLEDGE_BASE_ID"]
BEDROCK_REGION = os.environ["BEDROCK_REGION"]
INFERENCE_PROFILE_ARN = os.environ["INFERENCE_PROFILE_ARN"]
API_GATEWAY_DOMAIN = os.environ["WS_API_DOMAIN_NAME"]
STAGE = os.environ["WS_STAGE"]
DOCVAULTS_TABLE_NAME = os.environ["DOCVAULTS_TABLE"]
MESSAGES_TABLE_NAME = os.environ.get("MESSAGES_TABLE")
DATA_SOURCE_ID = os.environ["DATA_SOURCE_ID"]
USERS_TABLE_NAME = os.environ.get("USERS_TABLE")
DOCVAULTS_TABLE_INDEX_NAME = os.environ.get("DOCVAULTS_TABLE_INDEX")

# Initialize AWS service clients
BEDROCK_AGENT_RUNTIME = boto3.client("bedrock-agent-runtime", region_name=BEDROCK_REGION)
BEDROCK_AGENT = boto3.client("bedrock-agent", region_name=BEDROCK_REGION)
DYNAMODB = boto3.resource("dynamodb")
MESSAGES_TABLE = DYNAMODB.Table(MESSAGES_TABLE_NAME)

# Configure WebSocket management client
APIGW_MANAGEMENT = boto3.client(
    "apigatewaymanagementapi",
    endpoint_url=f"https://{API_GATEWAY_DOMAIN}/{STAGE}"
)

# prompt template with conversation history
PROMPT_TEMPLATE = """You are a precise document analysis assistant. Answer questions based on:
1. The user's uploaded documents (context)
2. The conversation history below

Rules:
1. If the answer isn't in the context, say "I don't know the answer based on the provided information."
2. Be concise and factual.
3. Format Requirements:
- No introductions/closing phrases
- No speculative phrases like "based on the context"
4. Never describe or invent media you can't find
5. If the same question is asked again, provide the answer again without refusing.
6. Don't make up answers or speculate beyond what's in the context.

Conversation History:
{conversation_history}

Context:
$search_results$
$output_format_instructions$

Question: {input}

Answer:"""

# Initialize logger
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

MAX_MESSAGE_HISTORY = 10  # Number of previous messages to maintain
MESSAGE_TTL = 2 * 60 * 60  # 2 hours in seconds for TTL

def send_to_client(connection_id, message):
    """
    Send a message to a WebSocket client.
    
    Args:
        connection_id (str): The WebSocket connection ID
        message (dict): The message to send (will be JSON serialized)
        
    Handles:
        - Client disconnection (GoneException)
        - Other ClientError scenarios
        - General exceptions
    """
    try:
        LOGGER.info("In chatbot.send_to_client, Sending message to %s: %s", connection_id, message)
        APIGW_MANAGEMENT.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(message).encode("utf-8")
        )
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'GoneException':
            LOGGER.warning("In chatbot.send_to_client, Client %s disconnected. Cannot send message.", connection_id)
        else:
            LOGGER.error("In chatbot.send_to_client, ClientError while sending to %s: %s", connection_id, str(e))
    except Exception as e:
        LOGGER.error("In chatbot.send_to_client, Unexpected error while sending to %s: %s", connection_id, str(e))



def start_and_monitor_ingestion(connection_id, max_retries=3):
    """
    Start a knowledge base ingestion job and monitor its progress.
    
    Args:
        connection_id (str): WebSocket connection ID for status updates
        max_retries (int): Maximum retry attempts for conflicts
        
    Sends status updates to client throughout the process:
    - AlreadyInProgress if another job is running
    - Started when job begins
    - Success/Failed when job completes
    - Timeout if monitoring takes too long
    - Error for other failures
    """
    LOGGER.info("In chatbot.start_and_monitor_ingestion, Starting ingestion monitoring for %s", connection_id)

    for attempt in range(max_retries):
        if is_ingestion_in_progress():
            LOGGER.info("In chatbot.start_and_monitor_ingestion, Ingestion already in progress")
            send_to_client(connection_id, {"Status": "AlreadyInProgress"})
            return
        try:
            # Start new ingestion job
            resp = BEDROCK_AGENT.start_ingestion_job(
                knowledgeBaseId=KNOWLEDGE_BASE_ID,
                dataSourceId=DATA_SOURCE_ID
            )
            job_id = resp.get("ingestionJob", {}).get("ingestionJobId")
            if not job_id:
                raise Exception("Missing ingestionJobId in response.")
            LOGGER.info("In chatbot.start_and_monitor_ingestion, Ingestion job started: %s", job_id)
            send_to_client(connection_id, {"Status": "Started", "IngestionJobId": job_id})

            # Monitor job status with timeout
            timeout = 180  # Max wait time in seconds
            interval = 5   # Poll interval in seconds
            waited = 0
            while waited < timeout:
                job_status = BEDROCK_AGENT.get_ingestion_job(
                    knowledgeBaseId=KNOWLEDGE_BASE_ID,
                    dataSourceId=DATA_SOURCE_ID,
                    ingestionJobId=job_id
                )["ingestionJob"]
                status = job_status["status"]
                LOGGER.info("In chatbot.start_and_monitor_ingestion, Ingestion job %s status: %s", job_id, status)
                
                if status in ["COMPLETE", "FAILED"]:
                    final_status = "Success" if status == "COMPLETE" else "Failed"
                    LOGGER.info("In chatbot.start_and_monitor_ingestion, Ingestion job completed with status: %s", final_status)
                    send_to_client(connection_id, {
                        "Status": final_status,
                        "IngestionJobId": job_id,
                    })
                    return
                
                time.sleep(interval)
                waited += interval

            LOGGER.warning("In chatbot.start_and_monitor_ingestion, Ingestion job %s timed out", job_id)
            send_to_client(connection_id, {
                "Status": "Timeout",
                "IngestionJobId": job_id
            })
            return

        except ClientError as e:
            if e.response["Error"]["Code"] == "ConflictException":
                sleep_time = random.uniform(1.5, 3.0)
                LOGGER.warning("In chatbot.start_and_monitor_ingestion, Conflict. Retrying in %.2fs (attempt %d)", sleep_time, attempt + 1)
                time.sleep(sleep_time)
            else:
                LOGGER.error("In chatbot.start_and_monitor_ingestion, ClientError during ingestion: %s", str(e))
                send_to_client(connection_id, {"Status": "Error", "Message": str(e)})
                return
        except Exception as e:
            LOGGER.error("In chatbot.start_and_monitor_ingestion, Error during ingestion: %s", str(e))
            send_to_client(connection_id, {"Status": "Error", "Message": str(e)})
            return

    LOGGER.error("In chatbot.start_and_monitor_ingestion, Max retries exceeded for ingestion start")
    send_to_client(connection_id, {"Status": "Failed", "Message": "Max retries exceeded."})

def is_ingestion_in_progress():
    """
    Check if there are any active ingestion jobs.
    
    Returns:
        bool: True if any job is in STARTING or IN_PROGRESS state
    """
    LOGGER.info("In chatbot.is_ingestion_in_progress, Checking for active ingestion jobs")
    try:
        resp = BEDROCK_AGENT.list_ingestion_jobs(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            dataSourceId=DATA_SOURCE_ID,
            maxResults=5
        )
        jobs = resp.get("ingestionJobSummaries", [])
        for job in jobs:
            if job["status"] in ["STARTING", "IN_PROGRESS"]:
                LOGGER.info("In chatbot.is_ingestion_in_progress, Ingestion already in progress: %s", job['ingestionJobId'])
                return True
        return False
    except Exception as e:
        LOGGER.error("In chatbot.is_ingestion_in_progress, Error checking ingestion status: %s", str(e))
        return False


# Store message and delete older if limit reached
def store_message(username, role, content, unique_docvault_ids=None, unique_classifications=None):
    """Store a message in DynamoDB and keep only the latest 10 messages per user."""
    LOGGER.info("In chatbot.store_message, Storing message for %s", username)
    timestamp = get_current_time()

    # Prepare the message content based on role
    if role == "assistant" and (unique_docvault_ids or unique_classifications):
        # For assistant messages with metadata, store structured content
        message_content = {
            "Answer": content,
            "UniqueDocVaultIds": unique_docvault_ids or [],
            "UniqueClassifications": unique_classifications or []
        }
    else:
        # For user messages or assistant messages without metadata, store plain content
        message_content = content

    try:
        #Store the new message
        put_item(
            MESSAGES_TABLE_NAME,
            item={
                "Username": username,
                "CreatedAt": timestamp,
                "Role": role,
                "Content": message_content if isinstance(message_content, str) else json.dumps(message_content)
            }
        )

        #Fetch all messages for that user (sorted by CreatedAt descending)
        items = query_items(
            MESSAGES_TABLE_NAME,
            key_condition_expression=Key("Username").eq(username),
            scan_index_forward=True  # True = ascending order, oldest first
        )

        #If more than 10 messages, delete the oldest ones
        if len(items) > 10:
            excess_count = len(items) - 10
            items_to_delete = items[:excess_count]  # oldest ones

            with MESSAGES_TABLE.batch_writer() as batch:
                for item in items_to_delete:
                    batch.delete_item(
                        Key={
                            "Username": item["Username"],
                            "CreatedAt": item["CreatedAt"]
                        }
                    )

    except Exception as e:
        LOGGER.error("In chatbot.store_message, Store error: %s", str(e))


# Fetch last 10 messages
def get_message_history(username):
    """
    Fetch last 10 messages.
    """
    LOGGER.info("In chatbot.get_message_history, Fetching history for %s", username)
    try:
        resp = query_items(
            MESSAGES_TABLE_NAME,
            key_condition_expression=Key("Username").eq(username),
            scan_index_forward=False,
            limit=MAX_MESSAGE_HISTORY
        )
        items = sorted(resp, key=lambda x: x["CreatedAt"])
        
        # Process each message to handle both string and JSON content
        formatted_messages = []
        for m in items:
            try:
                # Try to parse content as JSON if it's assistant message
                if m["Role"] == "assistant":
                    content = json.loads(m["Content"])
                else:
                    content = m["Content"]
            except (json.JSONDecodeError, TypeError):
                content = m["Content"]
                
            formatted_messages.append({
                "CreatedAt": m["CreatedAt"],
                "Content": content,
                "Role": m["Role"]
            })
            
        return formatted_messages
    except Exception as e:
        LOGGER.error("In chatbot.get_message_history, History error: %s", str(e))
        return []


# Clear message history
def clear_message_history(username):
    """
    Clear message history.
    """
    try:
        items = query_items(
            MESSAGES_TABLE_NAME,
            key_condition_expression=Key("Username").eq(username),
            projection_expression="Username, CreatedAt"
        )
        with MESSAGES_TABLE.batch_writer() as batch:
            for item in items:
                batch.delete_item(Key=item)
    except Exception as e:
        LOGGER.error("In chatbot.clear_message_history, Clear history error: %s", str(e))

def handle_websocket_event(event, context):
    """Handle WebSocket messages with proper conversation context handling."""
    try:
        LOGGER.info("In chatbot.handle_websocket_event, Processing WebSocket event: %s", json.dumps(event))
        route_key = event["requestContext"]["routeKey"]
        connection_id = event["requestContext"]["connectionId"]
        username = event.get("requestContext", {}).get("authorizer", {}).get("username")
        
        if not username:
            LOGGER.error("In chatbot.handle_websocket_event, Unauthorized: Username not found")
            send_to_client(connection_id, {"Error": "Unauthorized: Username not found."})
            return response(403)

        user = get_item(USERS_TABLE_NAME,key={'Username': username})
        if not user:
            return response(401,{"Error": "Unauthorized, user not found"})

        # Parse message body
        try:
            body = json.loads(event.get("body", "{}") or "{}")
        except json.JSONDecodeError as e:
            LOGGER.error("In chatbot.handle_websocket_event, Error parsing body: %s", str(e))
            send_to_client(connection_id, {"Error": "Invalid message format"})
            return response(400, {"Error": "Invalid message format"})
        
        # Extract query parameters
        query = body.get("Query", "").strip()
        docvault_ids = body.get("DocVaultIds", [])
        classifications = body.get("Classifications", [])
        
        # Convert single values to lists
        if isinstance(docvault_ids, str):
            docvault_ids = [docvault_ids.strip()] if docvault_ids.strip() else []
        if isinstance(classifications, str):
            classifications = [classifications.strip()] if classifications.strip() else []

        # Validate query
        if not query:
            LOGGER.warning("In chatbot.handle_websocket_event, Empty query received")
            send_to_client(connection_id, {"Error": "Query is required."})
            return response(400, {"Error": "Query is required."})

        if len(query.split()) < 2:
            LOGGER.warning("In chatbot.handle_websocket_event, Query too short")
            send_to_client(connection_id, {"Error": "Please rephrase your question to be more specific."})
            return response(400, {"Error": "Please rephrase your question to be more specific."})

        # Store user message before processing
        store_message(username, "user", query)
        
        # Get conversation history
        message_history = get_message_history(username)
        LOGGER.info("In chatbot.handle_websocket_event, Retrieved message history: %d messages", len(message_history))

        # Validate and get allowed docvaults
        allowed_docvaults = []
        if not docvault_ids:
            # Get all user's docvaults if none specified
            resp = query_items(
                DOCVAULTS_TABLE_NAME,
                index_name=DOCVAULTS_TABLE_INDEX_NAME,
                key_condition_expression=Key('CreatedBy').eq(username)
            )
            allowed_docvaults = [v["DocVaultId"] for v in resp]
            if not allowed_docvaults:
                LOGGER.warning("In chatbot.handle_websocket_event, No DocVaults found for user %s", username)
                send_to_client(connection_id, {"Error": "No DocVaults found for user."})
                return response(404, {"Error": "No DocVaults found for user."})
        else:
            # Verify user owns all specified docvaults
            for docvault_id in docvault_ids:
                item = get_item(DOCVAULTS_TABLE_NAME,key={'DocVaultId': docvault_id})
                if not item:
                    LOGGER.warning("In chatbot.handle_websocket_event, DocVault %s not found", docvault_id)
                    send_to_client(connection_id, {"Error": f"DocVault {docvault_id} not found."})
                    return response(404, {"Error": f"DocVault {docvault_id} not found."})
                if item.get("CreatedBy") != username:
                    LOGGER.warning("In chatbot.handle_websocket_event, User %s doesn't own DocVault %s", username, docvault_id)
                    send_to_client(connection_id, {"Error": f"You don't own DocVault {docvault_id}."})
                    return response(403, {"Error": f"You don't own DocVault {docvault_id}."})
            allowed_docvaults = docvault_ids

        # Build filter for knowledge base query
        filter_obj = None
        filters = []
        
        # DocVault filter
        if allowed_docvaults:
            if len(allowed_docvaults) == 1:
                filters.append({
                    "equals": {
                        "key": "DocVaultId",
                        "value": allowed_docvaults[0]
                    }
                })
            else:
                filters.append({
                    "orAll": [
                        {
                            "equals": {
                                "key": "DocVaultId",
                                "value": dv
                            }
                        } for dv in allowed_docvaults
                    ]
                })
        
        # Classification filter
        if classifications:
            if len(classifications) == 1:
                filters.append({
                    "equals": {
                        "key": "Classification",
                        "value": classifications[0]
                    }
                })
            else:
                filters.append({
                    "orAll": [
                        {
                            "equals": {
                                "key": "Classification",
                                "value": c
                            }
                        } for c in classifications
                    ]
                })
        
        # Combine filters
        if len(filters) == 1:
            filter_obj = filters[0]
        elif len(filters) > 1:
            filter_obj = {"andAll": filters}

        LOGGER.info("In chatbot.handle_websocket_event, Using filter: %s", json.dumps(filter_obj))
        
        try:
            # Format conversation history for the prompt template
            conversation_history = "\n".join(
                f"{msg['Role'].capitalize()}: {msg['Content']}"
                for msg in message_history
            )
            LOGGER.info("In chatbot.handle_websocket_event, Conversation history: %s", conversation_history)
            
            # Use the global PROMPT_TEMPLATE with formatted conversation history
            formatted_prompt = PROMPT_TEMPLATE.format(
                conversation_history=conversation_history,
                input=query
            )
            
            resp = BEDROCK_AGENT_RUNTIME.retrieve_and_generate(
                    input={"text": query},
                    retrieveAndGenerateConfiguration={
                        "type": "KNOWLEDGE_BASE",
                        "knowledgeBaseConfiguration": {
                            "knowledgeBaseId": KNOWLEDGE_BASE_ID,
                            "modelArn": INFERENCE_PROFILE_ARN,
                            "generationConfiguration": {
                                "promptTemplate": {
                                    "textPromptTemplate": formatted_prompt
                                }
                            },
                            "retrievalConfiguration": {
                                "vectorSearchConfiguration": {
                                    "numberOfResults": 100,
                                    "filter": filter_obj
                                }
                            }
                        }
                    }
                )
            # Process and send response
            answer = resp.get("output", {}).get("text", "")
            if not answer:
                answer = "I couldn't find a relevant answer in the knowledge base."
                LOGGER.info("In chatbot.handle_websocket_event, No answer found in knowledge base")

            # Prepare citations if available
            citations = []
            unique_docvault_ids = set()
            unique_classifications = set()

            for c in resp.get("citations", []):
                for ref in c.get("retrievedReferences", []):
                    # Get metadata
                    metadata = ref.get("metadata", {})
                    docvault_id = metadata.get("DocVaultId")
                    classification = metadata.get("Classification")
                    
                    # Add to unique sets
                    if docvault_id:
                        unique_docvault_ids.add(docvault_id)
                    if classification:
                        unique_classifications.add(classification)
            
                    # Prepare citation
                    citations.append({
                        "source": ref.get("location", {}).get("s3Location", {}).get("uri", "Unknown"),
                        "excerpt": ref.get("text", "")
                    })

            # Store assistant's response
            store_message(
                username,
                "assistant", 
                answer,
                unique_docvault_ids=list(unique_docvault_ids),
                unique_classifications=list(unique_classifications)
            )

            LOGGER.info("In chatbot.handle_websocket_event, Sending answer to client: %.100s...", answer)
            send_to_client(connection_id, {
                "Answer": answer,
                "UniqueDocVaultIds": list(unique_docvault_ids),
                "UniqueClassifications": list(unique_classifications)
            })
            return response(200)

        except ClientError as e:
            LOGGER.error("In chatbot.handle_websocket_event, Error during retrieval and generation: %s", str(e))
            send_to_client(connection_id, {"Error": "Internal error during retrieval and generation."})
            return response(500, {"Error": "Internal error during retrieval and generation."})

    except Exception as e:
        LOGGER.error("In chatbot.handle_websocket_event, Unexpected error: %s", str(e), exc_info=True)
        send_to_client(connection_id, {"Error": "Internal server error."})
        return response(500, {"Error": "Internal server error."})

def lambda_handler(event, context):
    """
    Main Lambda function handler for WebSocket connections.
    
    Routes incoming WebSocket events to appropriate handlers:
    - $connect: Handle new connections
    - $disconnect: Handle connection cleanup
    - $default: Process regular messages
    
    Args:
        event (dict): Lambda event containing WebSocket data
        context (LambdaContext): Runtime context object
        
    Returns:
        dict: Response with status code and headers
    """
    LOGGER.info("In chatbot.lambda_handler, Event received: %s", json.dumps(event, indent=2))
    route_key = event["requestContext"].get("routeKey")
    connection_id = event["requestContext"].get("connectionId")
    username = event.get("requestContext", {}).get("authorizer", {}).get("username")

    if route_key == "$connect":
        LOGGER.info("In chatbot.lambda_handler, New connection: %s", connection_id)
        return response(200, {"Message": "Connected."})
    elif route_key == "$disconnect":
        LOGGER.info("In chatbot.lambda_handler, Disconnecting: %s", connection_id)
        return response(200, {"Message": "Disconnected."})
    elif route_key == "$default":
        try:
            body = json.loads(event.get("body", "{}"))
            action = body.get("Action")

            if action == "StartIngestion":
                LOGGER.info("In chatbot.lambda_handler, Starting ingestion for %s", connection_id)
                start_and_monitor_ingestion(connection_id)
                return response(200, {"Message": "Ingestion started."})
            elif action == "ClearHistory":
                LOGGER.info("In chatbot.lambda_handler, Clearing history for %s", connection_id)
                clear_message_history(username)
                send_to_client(connection_id, {"Message": "History cleared."})
                return response(200, {"Message": "History cleared."})
            elif action == "RestoreHistory":
                LOGGER.info("In chatbot.lambda_handler, Retrieving history for %s", connection_id)
                history = get_message_history(username)
                send_to_client(connection_id, {"MessageHistory": history})
                return response(200, {"Message": "History retrieved."})
            else:
                LOGGER.info("In chatbot.lambda_handler, Processing default message for %s", connection_id)
                handle_websocket_event(event, context)
                return response(200, {"Message": "Default message processed."})

        except Exception as e:
            LOGGER.error("In chatbot.lambda_handler, Error handling $default message: %s", str(e))
            send_to_client(connection_id, {"error": "Server error."})
            return response(500, {"error": "Server error."})
    else:
        LOGGER.error("In chatbot.lambda_handler, Unsupported route: %s", route_key)
        return response(400, {"Message": "Unsupported route."})
