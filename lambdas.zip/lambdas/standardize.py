import os
import json
import boto3
import logging
from boto3.dynamodb.conditions import Key
from IDPutils import response, get_current_time, get_item, query_items, update_item

# Initialize AWS clients
DYNAMODB = boto3.resource('dynamodb')
S3 = boto3.client('s3')
BEDROCK_RUNTIME = boto3.client('bedrock-runtime')
SFN = boto3.client('stepfunctions')
STATE_MACHINE_ARN= os.environ['STANDARDIZE_SFN_ARN']

# Configure logging
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

EXTRACTED_FILES_TABLE_NAME = os.environ['EXTRACTED_FILES_TABLE']
DOCVAULTS_TABLE_NAME = os.environ['DOCVAULTS_TABLE']
# Initialize DynamoDB tables
BUCKET_NAME = os.environ['DOCVAULTS_BUCKET']
EXTRACTED_FILES_TABLE_INDEX2_NAME = os.environ['EXTRACTED_FILES_TABLE_INDEX2']
INFERENCE_PROFILE_ARN = os.environ['INFERENCE_PROFILE_ARN']

# Prompt template for Bedrock model
PROMPT_TEMPLATE = """
You are a strict JSON transformer. Your job is to **only modify the "value" fields** of a JSON object based on the provided instructions.

INSTRUCTIONS:
- Input is a JSON object with arbitrary nested structure.
- Only look at fields where the key is "value".
- If the "value" matches or contains any text or pattern **similar to** "{initial_format}" (case-insensitive), replace or convert it appropriately to match "{final_format}".
- Examples:
- Perform actual numeric conversions when the formats represent measurable quantities (e.g., temperature, distance, weight, etc.):
- Detect numeric values combined with the initial unit (e.g., "25°C", "100 km", "5kg").
- Convert the numeric part to the equivalent value in the "{final_format}" unit using the correct mathematical formula.
- Replace the string with the converted numeric value and the final unit.
- Example:
    - If converting from Celsius to Fahrenheit: (C × 9/5) + 32 → "°F".
    - If converting from kilometers to miles: (km × 0.621371) → "mi".
    - This is just an example. Apply the same principle to any measurable conversion.
- If initial format is "blue" and final format is "pink", then change "Blue", "BLUE", "bluE" → "pink".
- If initial format is a date format like "YYYY/MM/DD" or MM/DD/YYYY  and final is "DD/MM/YYYY", convert all date strings in that format accordingly.
- If initial format is "inr", "ruppees", or "Rs." and final is "USD", Detect amounts in strings such as "Rs.100", "100 Ruppees", "INR 100". convert any such textual representation to "USD" at the end of the number i.e. 100 USD.
- Do **not** modify anything outside of "value" fields.
- Preserve all keys, nested structure, and any non-matching values exactly as-is.
- Do not add any explanations or comments.
- Return only the fully transformed JSON.

Input JSON:
{content_json}

Output JSON:
"""

def handle_api_request(event):
    """
    Handles API Gateway requests to initiate standardization workflow.
    
    Validates inputs, checks permissions, and starts Step Function execution.
    
    Args:
        event (dict): API Gateway event containing request details
        
    Returns:
        dict: API response with status code and body
    """
    LOGGER.info("In standardize.handle_api_request, Handling API request to standardize files")
    try:
        # Extract request details
        path_params = event.get('pathParameters', {})
        query_params = event.get('queryStringParameters', {})
        body = json.loads(event.get('body', '{}'))
        
        docvault_id = path_params.get('docvault-id')
        classification = query_params.get('classification')
        initial_format = body.get('InitialFormat')
        final_format = body.get('FinalFormat')
        username = event.get('requestContext', {}).get('authorizer', {}).get('claims', {}).get('preferred_username',{})

        LOGGER.info(
            "In standardize.handle_api_request, Request parameters - DocVault: %s, Classification: %s, InitialFormat: %s, FinalFormat: %s",
            docvault_id, classification, initial_format, final_format
        )

        # Validate inputs
        if not all([docvault_id, classification, initial_format, final_format]):
            LOGGER.error("In standardize.handle_api_request, Missing required parameters")
            return response(400, {'Error': 'Missing required parameters'})

        # Verify docvault ownership
        LOGGER.info("In standardize.handle_api_request, Checking docvault %s ownership", docvault_id)
        docvault = get_item(DOCVAULTS_TABLE_NAME, key={'DocVaultId': docvault_id})
        if not docvault:
            LOGGER.error("In standardize.handle_api_request, Docvault %s not found", docvault_id)
            return response(404, {'Error': 'Docvault not found'})
        
        if username != docvault['CreatedBy']:
            LOGGER.error("In standardize.handle_api_request, User %s is not owner of docvault %s", username, docvault_id)
            return response(403, {'Error': 'Only docvault owner can standardize files'})

        # Start Step Function execution
        LOGGER.info("In standardize.handle_api_request, Initiating standardization workflow for docvault %s", docvault_id)
        execution = SFN.start_execution(
            stateMachineArn=STATE_MACHINE_ARN,
            input=json.dumps({
                'docvaultId': docvault_id,
                'classification': classification,
                'initialFormat': initial_format,
                'finalFormat': final_format,
                'username': username
            })
        )
        
        LOGGER.info("In standardize.handle_api_request, Step Function execution started: %s", execution['executionArn'])
        return response(202, {'ExecutionArn': execution['executionArn'], 'StartDate': execution['startDate'].isoformat()})
    except Exception as e:
        LOGGER.error("In standardize.handle_api_request, Error: %s", str(e))
        return response(500, {'Error': str(e)})

def handle_get_files(event):
    """
    Retrieves files of a specific classification from a docvault.
    
    Args:
        event (dict): Step Function task event containing docvaultId and classification
        
    Returns:
        list: List of file items matching the criteria
    """
    LOGGER.info(
        "In standardize.handle_get_files, Handling get_files task for docvault %s and classification %s",
        event['docvaultId'], event['classification']
    )
    try:
        docvault_id = event['docvaultId']
        classification = event['classification']
        
        # Query DynamoDB for files
        LOGGER.info(
            "In standardize.handle_get_files, Querying for files in docvault %s with classification %s",
            docvault_id, classification
        )
        files = query_items(
            EXTRACTED_FILES_TABLE_NAME,
            index_name=EXTRACTED_FILES_TABLE_INDEX2_NAME,
            key_condition_expression=Key('DocVaultId').eq(docvault_id) &
                                 Key('ClassificationName').eq(classification)
        )
        
        LOGGER.info("In standardize.handle_get_files, Found %d files matching criteria", len(files))
        return files
        
    except Exception as e:
        LOGGER.error("In standardize.handle_get_files, Error: %s", str(e))
        return []

def process_single_file(event):
    """
    Processes a single file for standardization.
    
    Updates status, performs standardization, and handles errors.
    
    Args:
        event (dict): Step Function task event containing file details
        
    Returns:
        dict: Result containing status and file identifiers
    """
    LOGGER.info(
        "In standardize.process_single_file, Processing standardization for file: %s",
        event.get('file', {}).get('ExtractedFileName')
    )
    try:
        file_info = event['file']
        docvault_id = event['docvaultId']
        extracted_file_name = file_info['ExtractedFileName']
        
        # Update status to PROCESSING
        LOGGER.info("In standardize.process_single_file, Updating status to PROCESSING for %s", extracted_file_name)
        update_item(
            EXTRACTED_FILES_TABLE_NAME,
            key={
                'DocVaultId': docvault_id,
                'ExtractedFileName': extracted_file_name
            },
            update_expression="""
                SET StandardizeStatus = :status,
                    ModifiedAt = :now,
                    ModifiedBy = :user
            """,
            expression_attributes={
                ':status': 'PROCESSING',
                ':now': get_current_time(),
                ':user': event['username']
            }
        )
        
        # Load original data
        s3_location = file_info['ExtractionS3Location']
        pii_location = f"pii/{docvault_id}/pii_{extracted_file_name}"
        LOGGER.info(
            "In standardize.process_single_file, Processing file - S3 location: %s, PII location: %s",
            s3_location, pii_location
        )
        
        # Standardize the file
        LOGGER.info("In standardize.process_single_file, Beginning standardization for %s", extracted_file_name)
        standardize_file(
            bucket=BUCKET_NAME,
            key=s3_location,
            pii_location=pii_location,
            initial_format=event['initialFormat'],
            final_format=event['finalFormat'],
            docvault_id=docvault_id,
            extracted_file_name=extracted_file_name,
            username=event['username']
        )
        
        LOGGER.info("In standardize.process_single_file, Successfully standardized %s", extracted_file_name)
        return response(200, {'status': 'SUCCESS', 'fileId': extracted_file_name, 'docvaultId': docvault_id})
        
    except Exception as e:
        LOGGER.error("In standardize.process_single_file, Failed to standardize %s: %s", extracted_file_name, str(e))
        # Update status to FAILED
        update_item(
            EXTRACTED_FILES_TABLE_NAME,
            key={
                'DocVaultId': docvault_id,
                'ExtractedFileName': extracted_file_name
            },
            update_expression="""
                SET StandardizeStatus = :status,
                    StandardizeError = :error,
                    ModifiedAt = :now
            """,
            expression_attributes={
                ':status': 'FAILED',
                ':error': str(e),
                ':now': get_current_time()
            }
        )
        return response(500, {'status': 'FAILED', 'error': str(e), 'fileId': extracted_file_name, 'docvaultId': docvault_id})


def standardize_file(bucket, key, pii_location, initial_format, final_format, docvault_id, extracted_file_name, username):
    """
    Performs the actual standardization of a file's data.
    
    Args:
        bucket (str): S3 bucket name
        key (str): S3 key for the original extracted data
        pii_location (str): S3 key for the PII-redacted version
        initial_format (str): Format to look for (e.g. "DD/MM/YYYY")
        final_format (str): Format to convert to (e.g. "YYYY-MM-DD")
        docvault_id (str): ID of the docvault
        extracted_file_name (str): Name of the extracted file
        username (str): Username performing the operation
    """
    LOGGER.info(
        "In standardize.standardize_file, Standardizing file %s in docvault %s",
        extracted_file_name, docvault_id
    )
    
    # Initialize pii_data to None at the start
    pii_data = None
    
    try:
        # Load original extracted data from S3
        LOGGER.info("In standardize.standardize_file, Loading original data from s3://%s/%s", bucket, key)
        s3_response = S3.get_object(Bucket=bucket, Key=key)
        original_data = json.loads(s3_response['Body'].read().decode('utf-8'))

        if not isinstance(original_data, dict) or 'compared_data' not in original_data:
            raise ValueError("Invalid data format: expected a dict with 'compared_data'")

        # Call model to transform data
        LOGGER.info(
            "In standardize.standardize_file, Transforming data from %s to %s",
            initial_format, final_format
        )
        original_text = json.dumps(original_data['compared_data'], indent=2)
        updated_text = call_model_to_transform(original_text, initial_format, final_format)
        updated_compared_data = json.loads(updated_text)

        # Update the compared_data section
        original_data['compared_data'] = updated_compared_data

        # Save updated extracted file
        LOGGER.info("In standardize.standardize_file, Saving updated data to s3://%s/%s", bucket, key)
        S3.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(original_data),
            ContentType='application/json'
        )

        # Update PII-redacted version if it exists
        try:
            LOGGER.info(
                "In standardize.standardize_file, Attempting to update PII-redacted version at s3://%s/%s",
                bucket, pii_location
            )
            pii_response = S3.get_object(Bucket=bucket, Key=pii_location)
            pii_data = json.loads(pii_response['Body'].read().decode('utf-8'))
            
            # Update only non-PII fields in the redacted version
            def update_non_pii_fields(original, redacted):
                if isinstance(original, dict) and isinstance(redacted, dict):
                    for key, value in original.items():
                        if key in redacted:
                            # Handle nested objects
                            if isinstance(value, dict) and isinstance(redacted[key], dict):
                                if 'pii_detected' in value and not value['pii_detected']:
                                    # Copy the entire value object if it's not PII
                                    redacted[key] = value
                                else:
                                    update_non_pii_fields(value, redacted[key])
                            # Handle direct value updates for non-PII fields
                            elif isinstance(value, dict) and 'pii_detected' in value and not value['pii_detected']:
                                redacted[key] = value
                            # Skip non-dict values (like numbers, strings)
                            elif not isinstance(value, dict):
                                continue
            
            update_non_pii_fields(updated_compared_data, pii_data['compared_data'])
            
            # Save updated PII version
            LOGGER.info("In standardize.standardize_file, Saving updated PII-redacted version")
            S3.put_object(
                Bucket=bucket,
                Key=pii_location,
                Body=json.dumps(pii_data),
                ContentType='application/json'
            )
        except Exception as pii_error:
            LOGGER.warning("In standardize.standardize_file, Could not update PII-redacted version: %s", str(pii_error))
            if pii_data is not None:
                LOGGER.debug("In standardize.standardize_file, PII data: %s", json.dumps(pii_data, indent=2))
            LOGGER.debug("In standardize.standardize_file, Original data: %s", json.dumps(updated_compared_data, indent=2))

        # Mark standardization as completed
        LOGGER.info("In standardize.standardize_file, Marking standardization as COMPLETED for %s", extracted_file_name)
        update_item(
            EXTRACTED_FILES_TABLE_NAME,
            key={
                'DocVaultId': docvault_id,
                'ExtractedFileName': extracted_file_name
            },
            update_expression="""
                SET StandardizeStatus = :status,
                    ModifiedAt = :now
                REMOVE StandardizeError
            """,
            expression_attributes={
                ':status': 'COMPLETED',
                ':now': get_current_time()
            }
        )

    except Exception as e:
        LOGGER.error("In standardize.standardize_file, Standardization failed for %s: %s", extracted_file_name, str(e))
        # Update the item with error status
        update_item(
            EXTRACTED_FILES_TABLE_NAME,
            key={
                'DocVaultId': docvault_id,
                'ExtractedFileName': extracted_file_name
            },
            update_expression="""
                SET StandardizeStatus = :status,
                    StandardizeError = :error,
                    ModifiedAt = :now
            """,
            expression_attributes={
                ':status': 'FAILED',
                ':error': str(e),
                ':now': get_current_time()
            }
        )
        raise Exception(f"Failed to standardize {extracted_file_name}: {str(e)}")

def call_model_to_transform(content_json, initial_format, final_format):
    """
    Uses a Bedrock model to transform values in the JSON content.
    
    Args:
        content_json (str): JSON string of the compared_data section
        initial_format (str): Format to look for (e.g. "DD/MM/YYYY")
        final_format (str): Format to convert to (e.g. "YYYY-MM-DD")
        
    Returns:
        str: Transformed JSON string
        
    Raises:
        Exception: If model invocation fails or returns invalid JSON
    """
    LOGGER.info(
        "In standardize.call_model_to_transform, Calling model to transform from %s to %s",
        initial_format, final_format
    )
    prompt = PROMPT_TEMPLATE.format(
        initial_format=initial_format,
        final_format=final_format,
        content_json=content_json
    )

    try:
        LOGGER.info("In standardize.call_model_to_transform, Invoking Bedrock model")
        response = BEDROCK_RUNTIME.invoke_model(
            modelId=INFERENCE_PROFILE_ARN,
            contentType="application/json",
            accept="application/json",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 4096,
                "temperature": 0.2,
                "stop_sequences": ["\n\nHuman:", "\n\nAssistant:"]
            })
        )

        # Parse the response body
        response_body = json.loads(response['body'].read())
        
        # Handle different response formats
        if isinstance(response_body, dict):
            # For Anthropic Claude models
            if 'content' in response_body:
                content = response_body['content']
                if isinstance(content, list):
                    # Join all text parts
                    raw_content = ''.join([item.get('text', '') for item in content if isinstance(item, dict)])
                else:
                    raw_content = str(content)
            else:
                raw_content = str(response_body)
        else:
            raw_content = str(response_body)

        # Extract the JSON part from the response
        json_start = raw_content.find('{')
        json_end = raw_content.rfind('}') + 1
        if json_start == -1 or json_end == -1:
            raise Exception("Could not extract valid JSON from model response")

        transformed_json = raw_content[json_start:json_end]
        
        # Validate the JSON
        try:
            json.loads(transformed_json)
            LOGGER.info("In standardize.call_model_to_transform, Successfully transformed JSON")
            return transformed_json
        except json.JSONDecodeError:
            LOGGER.error("In standardize.call_model_to_transform, Model returned invalid JSON format")
            raise Exception("Model returned invalid JSON format")

    except Exception as error:
        LOGGER.error("In standardize.call_model_to_transform, Model transformation failed: %s", str(error))
        raise Exception(f"Model transformation failed: {str(error)}")

def lambda_handler(event, context):
    """
    Main Lambda handler function that routes requests based on event type.
    
    Handles both API Gateway requests and Step Function task events.
    
    Args:
        event (dict): The event triggering the Lambda function
        context (object): Lambda context object
        
    Returns:
        dict: Response containing status code and body for API requests,
              or task results for Step Function tasks
    """
    LOGGER.info("In standardize.lambda_handler, Received event: %s", json.dumps(event))
    try:
        # Check if this is a Step Function task
        if 'task' in event:
            LOGGER.info("In standardize.lambda_handler, Processing Step Function task")
            if event['task'] == 'get_files':
                return handle_get_files(event)
            elif event['task'] == 'standardize_file':
                return process_single_file(event)
        
        # Check if this is an API Gateway request
        elif 'pathParameters' in event or 'queryStringParameters' in event:
            LOGGER.info("In standardize.lambda_handler, Processing API Gateway request")
            return handle_api_request(event)
            
        LOGGER.error("In standardize.lambda_handler, Invalid request format")
        return response(400, {'Error': 'Invalid request format'})
    except Exception as e:
        LOGGER.error("In standardize.lambda_handler, Error: %s", str(e))
        return response(500, {'Error': str(e)})
