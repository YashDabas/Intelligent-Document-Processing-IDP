"""
IDPClassificationsLambda.py
This module provides AWS Lambda handlers and supporting classes/functions for intelligent document processing
(IDP) workflows, including document classification, schema generation, and extraction of structured data from uploaded files (PDFs and images).
 It integrates with AWS services such as S3, DynamoDB, Step Functions, and Bedrock for AI-powered text extraction and analysis.
Key Components:
- AppConfig: Centralized configuration for image processing, Bedrock model settings, and chunking parameters.
- File Processing Utilities: Functions to determine file types, resize images, convert PDFs to images, and save markdown to S3_CLIENT.
- Bedrock Integration: Functions and classes to invoke Bedrock models for text extraction and document analysis, both synchronously and asynchronously.
- MarkdownContextualChunker: Splits extracted markdown text into context-aware chunks for downstream processing.
- DocumentChunkConsolidator: Merges and consolidates structured data extracted from document chunks.
- Lambda Handlers:
    - extract_from_files: Orchestrates the extraction and processing of text from uploaded files.
    - schema_generation: Generates a representative JSON schema from extracted document texts using BEDROCK.
    - create_blueprint: Converts a base schema into a detailed, Draft-07 compliant JSON schema and registers it as a blueprint.
    - save_results: Persists schema data and metadata to S3 and DynamoDB.
    - lambda_handler: Main entry point for API Gateway and task-based Lambda invocations,
      supporting CRUD operations for classifications and orchestrating the IDP workflow.
Usage:
This module is intended to be deployed as an AWS Lambda function behind API Gateway, supporting both RESTful endpoints and asynchronous
 task-based invocations for document classification and schema management in intelligent document processing pipelines.
"""

import os
import json
import base64
import logging
import re
import asyncio
import datetime
import io
import mimetypes
import uuid
from typing import Any, Dict, List, Tuple
import boto3
import fitz
from aiobotocore.session import get_session
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from PIL import Image
from IDPutils import (
    response,
    query_items,
    put_item,
    delete_item,
    paginate_list,
    VALID_CLASSIFICATIONS_KEYS,
)


AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")
BEDROCK = boto3.client(service_name="bedrock-runtime", region_name=AWS_REGION)
BEDROCK_AUTOMATION = boto3.client("bedrock-data-automation", region_name=AWS_REGION)
S3_CLIENT = boto3.client("s3", region_name=AWS_REGION)

BEDROCK_MODEL_ID = os.environ.get(
    "CLAUDE_3_5_V1_MODEL_ID", "us.anthropic.claude-3-5-sonnet-20240620-v1:0"
)
CLASSIFICATIONS_TABLE_NAME = os.environ.get(
    "CLASSIFICATIONS_TABLE", "IDP-Classifications-Table"
)
USERS_TABLE_NAME = os.environ.get("USERS_TABLE", "IDP-Users-Table")
STEP_FUNCTION_ARN = os.environ.get(
    "CLASSIFICATIONS_SFN_ARN",
    "arn:aws:states:us-east-1:043309350924:stateMachine:idp-classification-stepfn",
)
CLASSIFICATIONS_BUCKET = os.environ.get(
    "CLASSIFICATIONS_BUCKET", "idp-classifications-file-bucket"
)
INDEX1 = os.environ.get(
    "CLASSIFICATIONS_TABLE_INDEX1", "CreatedBy-ClassificationName-index"
)


VALID_CONTENT_TYPES = ["application/pdf", "image/png", "image/jpeg", "image/jpg"]
PREBUILT_CLASSIFICATIONS = [
    "US-Bank-Statement",
    "US-Passport",
    "US-Driver-License",
    "Invoices",
    "Receipts",
]

HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Content-Type": "application/json",
}

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

from decimal import Decimal


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            if o % 1 == 0:
                return int(o)
            else:
                return float(o)
        return super(DecimalEncoder, self).default(o)


class AppConfig:
    """
    AppConfig holds all configuration constants for the application, including:

    S3 and File Processing Settings:
        - DEFAULT_OUTPUT_PREFIX: Default prefix for output files in S3_CLIENT.

    Image Processing Settings:
        - DEFAULT_DPI: Default DPI for image processing.
        - IMAGE_MAX_SIZE: Maximum allowed image size (width, height) in pixels.
        - IMAGE_QUALITY: JPEG quality for image saving.

    Bedrock - Stage 1 (Text Extraction) Settings:
        - EXTRACTION_MODEL_ID: Model ID for text extraction.
        - EXTRACTION_MAX_TOKENS: Maximum tokens for extraction model.
        - EXTRACTION_CHUNK_SIZE: Number of pages to process per chunk.

    Bedrock - Stage 2 (Data Analysis) Settings:
        - ANALYSIS_MODEL_ID: Model ID for data analysis.
        - ANALYSIS_MAX_TOKENS: Maximum tokens for analysis model.

    Chunking Settings:
        - MARKDOWN_MAX_CHUNK_SIZE: Maximum size of markdown chunks.
        - MARKDOWN_OVERLAP_SIZE: Overlap size between chunks for context.
        - MARKDOWN_MIN_CHUNK_SIZE: Minimum size of markdown chunks.
    """

    DEFAULT_OUTPUT_PREFIX = "extracted-text"
    DEFAULT_DPI = 150
    IMAGE_MAX_SIZE: Tuple[int, int] = (1024, 1024)
    IMAGE_QUALITY = 90
    EXTRACTION_MODEL_ID = os.environ.get(
        "PIXTRAL_MODELID", "us.mistral.pixtral-large-2502-v1:0"
    )
    EXTRACTION_MAX_TOKENS = 4000
    EXTRACTION_CHUNK_SIZE = 3
    ANALYSIS_MODEL_ID = os.environ.get(
        "CLAUDE_3.7_MODELID", "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
    )
    ANALYSIS_MAX_TOKENS = 4000
    MARKDOWN_MAX_CHUNK_SIZE = 2000
    MARKDOWN_OVERLAP_SIZE = 200
    MARKDOWN_MIN_CHUNK_SIZE = 100


class DynamoDBHandler:
    """DynamoDBHandler provides methods to interact with DynamoDB tables for IDP classifications and user management.
    It abstracts common operations such as querying, inserting, and deleting items in the classifications and users tables.
    Attributes:
        classifications_table (boto3.Table): The DynamoDB table for IDP classifications.
        users_table (boto3.Table): The DynamoDB table for user management.
    Methods:

        get_user(username: str) -> List[Dict]:
            Queries the USERS_TABLE for a specific user by username.
        get_classifications_by_creator(creator: str) -> List[Dict]:
            Queries the CLASSIFICATIONS_TABLE by the 'CreatedBy' index to retrieve all classifications created by a specific user.
        get_classification_by_name(creator: str, name: str) -> List[Dict]:
            Queries the CLASSIFICATIONS_TABLE for a specific classification by creator and name.
        put_classification_item(item: Dict):
            Inserts or updates a single item in the classifications table.
        delete_classification_by_key(key: Dict):
            Deletes an item from the classifications table by its primary key.
    """

    def __init__(self):
        pass

    def get_user(self, username: str) -> List[Dict]:
        """
        Queries the USERS_TABLE for a specific user by username.
        Args:
            username (str): The username to query in the USERS_TABLE.
        Returns:
            List[Dict]: A list of user items matching the provided username.
        Raises:
            ClientError: If there is an error querying the DynamoDB table.
        """
        return query_items(
            USERS_TABLE_NAME, key_condition_expression=Key("Username").eq(username)
        )

    def get_classifications_by_creator(self, creator: str) -> List[Dict]:
        """
        Queries the CLASSIFICATIONS_TABLE by the 'CreatedBy' index to retrieve all classifications created by a specific user.
        Args:
            creator (str): The username of the creator to filter classifications.
        Returns:
            List[Dict]: A list of classification items created by the specified user.
        Raises:
            ClientError: If there is an error querying the DynamoDB table.
        """
        return query_items(
            CLASSIFICATIONS_TABLE_NAME,
            index_name=INDEX1,
            key_condition_expression=Key("CreatedBy").eq(creator),
            filter_expression="attribute_exists(SchemaS3Location)",
        )

    def get_classification_by_name(self, creator: str, name: str) -> List[Dict]:
        """
        Queries the CLASSIFICATIONS_TABLE for a specific classification by creator and name.
        Args:
            creator (str): The username of the creator to filter classifications.
            name (str): The name of the classification to query.
        Returns:
            List[Dict]: A list of classification items matching the creator and name.
        Raises:
            ClientError: If there is an error querying the DynamoDB table.
        """
        return query_items(
            CLASSIFICATIONS_TABLE_NAME,
            index_name=INDEX1,
            key_condition_expression=Key("CreatedBy").eq(creator)
            & Key("ClassificationName").eq(name),
        )

    def put_classification_item(self, item: Dict):
        """
        Inserts or updates a single item in the classifications table.
        Args:
            item (Dict): The classification item to insert or update in the table.
        Raises:
            ClientError: If there is an error putting the item into the DynamoDB table.
        """
        put_item(CLASSIFICATIONS_TABLE_NAME, item=item)

    def delete_classification_by_key(self, key: Dict):
        """
        Deletes an item from the classifications table by its primary key.
        Args:
            key (Dict): The primary key of the classification item to delete.
        Raises:
            ClientError: If there is an error deleting the item from the DynamoDB table.
        """
        delete_item(CLASSIFICATIONS_TABLE_NAME, key=key)


DB_HANDLER = DynamoDBHandler()


def get_file_type(key: str) -> str:
    """
    Determines the file type based on the provided file key (filename or path).
    Attempts to infer the file type using the MIME type guessed from the file extension.
    If the MIME type is not recognized, falls back to checking the file extension directly.
    Args:
        key (str): The filename or file path to determine the type for.
    Returns:
        str: The file type, which can be "image", "pdf", or "unknown" if the type cannot be determined.
    """
    mime_type, _ = mimetypes.guess_type(key)
    if mime_type:
        if mime_type.startswith("image/"):
            return "image"
        elif mime_type == "application/pdf":
            return "pdf"

    extension = key.lower().split(".")[-1]
    if extension in ["jpg", "jpeg", "png", "tiff"]:
        return "image"
    elif extension == "pdf":
        return "pdf"

    return "unknown"


def resize_image_from_bytes(image_data: bytes) -> str:
    """
    Resize an image provided as bytes, convert it to JPEG with specified quality, and return the result as a base64-encoded string.

    Args:
        image_data (bytes): The raw image data in bytes.

    Returns:
        str: The base64-encoded JPEG image as a UTF-8 string.
    """
    img = Image.open(io.BytesIO(image_data))
    if img.mode != "RGB":
        img = img.convert("RGB")

    img.thumbnail(AppConfig.IMAGE_MAX_SIZE, Image.Resampling.LANCZOS)
    img_byte_arr = io.BytesIO()
    img.save(
        img_byte_arr, format="JPEG", quality=AppConfig.IMAGE_QUALITY, optimize=True
    )
    return base64.b64encode(img_byte_arr.getvalue()).decode("utf-8")


def pdf_to_images(pdf_data: bytes) -> List[str]:
    """
    Converts a PDF file (provided as bytes) into a list of resized PNG images, one per page.
    Args:
        pdf_data (bytes): The PDF file data as a bytes object.
    Returns:
        List[str]: A list of resized images in PNG format, each represented as a base64-encoded string or file path (depending on the implementation of `resize_image_from_bytes`).
    Raises:
        Any exceptions raised by PyMuPDF (fitz) or image processing functions may propagate.
    Notes:
        - Uses the DPI setting from `AppConfig.DEFAULT_DPI` for rendering.
        - Each page is rendered and resized using `resize_image_from_bytes`.
    """
    images = []
    pdf_document = fitz.open(stream=pdf_data, filetype="pdf")
    try:
        for page_num in range(len(pdf_document)):
            page = pdf_document[page_num]
            mat = fitz.Matrix(AppConfig.DEFAULT_DPI / 72, AppConfig.DEFAULT_DPI / 72)
            pix = page.get_pixmap(matrix=mat)
            img_data = pix.tobytes("png")
            resized_image = resize_image_from_bytes(img_data)
            images.append(resized_image)
    finally:
        pdf_document.close()
    return images


def create_bedrock_message(images: List[str], prompt: str) -> Dict[str, Any]:
    """
    Creates a message payload for Bedrock API with a text prompt and optional images.
    Args:
        images (List[str]): A list of base64-encoded image strings to include in the message.
        prompt (str): The text prompt to send as part of the message.
    Returns:
        Dict[str, Any]: A dictionary containing the formatted message payload, including the user role,
        content (prompt and images), and the maximum number of tokens allowed for extraction.
    Raises:
        None
    """
    content = [{"type": "text", "text": prompt}]
    for image_b64 in images:
        content.append(
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"},
            }
        )
    return {
        "messages": [{"role": "user", "content": content}],
        "max_tokens": AppConfig.EXTRACTION_MAX_TOKENS,
    }


def process_with_bedrock(images: List[str], file_type: str) -> Dict[str, Any]:
    """
    Processes a list of images (or PDF pages) using the Bedrock model to extract text content.
    Args:
        images (List[str]): A list of image data or file paths representing pages or images to process.
        file_type (str): The type of file being processed ("pdf" or other image types).
    Returns:
        Dict[str, Any]: A dictionary containing:
            - "combined_content": The concatenated extracted content from all processed chunks/pages.
            - "chunks_processed": The number of chunks processed.
            - "total_pages": The total number of pages/images processed.
            - "chunk_details": A list of dictionaries with details for each chunk, including extracted content or error messages.
    Raises:
        This function handles exceptions internally and includes error messages in the result.
    """
    all_results = []
    total_pages = len(images)
    chunk_size = AppConfig.EXTRACTION_CHUNK_SIZE

    for i in range(0, total_pages, chunk_size):
        chunk = images[i : i + chunk_size]
        start_page, end_page = i + 1, min(i + chunk_size, total_pages)
        LOGGER.info(f"Processing pages {start_page}-{end_page} of {total_pages}")

        if file_type == "pdf":
            prompt = (
                f"Extract and return all text from page {start_page} of this {total_pages}-page PDF document as markdown:"
                if len(chunk) == 1
                else f"Extract all text from pages {start_page}-{end_page} of this {total_pages}-page PDF. Maintain structure and indicate page breaks."
            )
        else:
            prompt = "Extract and return all text from this image as markdown:"

        request_body = create_bedrock_message(chunk, prompt)
        try:
            response = BEDROCK.invoke_model(
                modelId=AppConfig.EXTRACTION_MODEL_ID,
                contentType="application/json",
                body=json.dumps(request_body),
            )
            response_body = json.loads(response.get("body").read())
            content = (
                response_body.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            all_results.append(
                {"pages": f"{start_page}-{end_page}", "content": content}
            )
        except ClientError as e:
            error_message = f"Bedrock API error on chunk {start_page}-{end_page}: {e.response['Error']['Message']}"
            LOGGER.error(error_message)
            all_results.append(
                {"pages": f"{start_page}-{end_page}", "error": error_message}
            )
        except Exception as e:
            error_message = f"An unexpected error occurred on chunk {start_page}-{end_page}: {str(e)}"
            LOGGER.error(error_message)
            all_results.append(
                {"pages": f"{start_page}-{end_page}", "error": error_message}
            )

    combined_content = "\n\n".join(
        (
            f"--- Pages {result['pages']} ---\n{result['content']}"
            if "content" in result
            else f"--- Pages {result['pages']} (ERROR) ---\n{result['error']}"
        )
        for result in all_results
    )

    return {
        "combined_content": combined_content.strip(),
        "chunks_processed": len(all_results),
        "total_pages": total_pages,
        "chunk_details": all_results,
    }


def save_markdown_to_s3(
    content: str, bucket: str, original_key: str, batch_id: str
) -> str:
    """
    Saves the provided markdown content to an S3 bucket under a structured key.
    Args:
        content (str): The markdown content to be saved.
        bucket (str): The name of the S3 bucket where the file will be stored.
        original_key (str): The original S3 object key, used to derive the output filename.
        batch_id (str): The batch identifier used to organize the output path.
    Returns:
        str: The S3 key where the markdown file was saved.
    Raises:
        ClientError: If there is an error uploading the file to S3_CLIENT.
    """
    base_name = original_key.split("/")[-1]
    name_without_ext = ".".join(base_name.split(".")[:-1])
    output_key = f"extracted/{batch_id}/{name_without_ext}.md"

    try:
        S3_CLIENT.put_object(
            Bucket=bucket,
            Key=output_key,
            Body=content.encode("utf-8"),
            ContentType="text/markdown",
        )
        LOGGER.info(f"Markdown saved to: s3://{bucket}/{output_key}")
        return output_key
    except ClientError as e:
        LOGGER.error(f"Error saving markdown to S3: {e.response['Error']['Message']}")
        raise


class MarkdownContextualChunker:
    """
    MarkdownContextualChunker splits markdown text into context-aware chunks based on section headers,
    ensuring each chunk does not exceed a maximum size and includes configurable overlap for context continuity.
    Attributes:
        max_chunk_size (int): Maximum allowed size for each chunk, loaded from AppConfig.
        overlap_size (int): Number of overlapping characters between consecutive chunks, loaded from AppConfig.
    Methods:
        create_contextual_chunks(text: str) -> List[Dict[str, Any]]:
            Splits the input markdown text into chunks, preserving section context and overlap.
            Returns a list of dictionaries, each containing chunk content and metadata.
        _create_chunk_obj(content: str) -> Dict[str, Any]]:
            Helper method to create a standardized chunk object with content and metadata.
    """

    def __init__(self):
        self.max_chunk_size = AppConfig.MARKDOWN_MAX_CHUNK_SIZE
        self.overlap_size = AppConfig.MARKDOWN_OVERLAP_SIZE

    def create_contextual_chunks(self, text: str) -> List[Dict[str, Any]]:
        chunks = []
        current_chunk_content = ""
        sections = re.split(r"(^#+\s.*$)", text, flags=re.MULTILINE)

        for i in range(1, len(sections), 2):
            header = sections[i]
            content = sections[i + 1]
            section_text = header + content

            if (
                len(current_chunk_content) + len(section_text) > self.max_chunk_size
                and current_chunk_content
            ):
                chunks.append(self._create_chunk_obj(current_chunk_content))
                overlap = current_chunk_content[-self.overlap_size :]
                current_chunk_content = overlap + section_text
            else:
                current_chunk_content += section_text

        if current_chunk_content:
            chunks.append(self._create_chunk_obj(current_chunk_content))
        return chunks

    def _create_chunk_obj(self, content: str) -> Dict[str, Any]:
        """Helper to create a standard chunk object."""
        return {"content": content, "metadata": {"char_count": len(content)}}


class BedrockLLMProcessor:
    """
    Asynchronously invokes a Bedrock model using the provided session and prompt.
    Args:
        session: An aiobotocore or boto3 session object used to create the Bedrock client.
        formatted_prompt (str): The prompt string to send to the model.
    Returns:
        dict: A dictionary containing either:
            - 'response' (str): The model's response text and 'success' (bool) True on success.
            - 'error' (str): The error message and 'success' (bool) False on failure.
    Raises:
        Exception: Any exception encountered during the model invocation is caught and logged.
    """

    async def _invoke_model_async(self, session, formatted_prompt: str) -> dict:
        try:
            async with session.create_client(
                "bedrock-runtime", region_name=AWS_REGION
            ) as client:
                request_body = {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": AppConfig.ANALYSIS_MAX_TOKENS,
                    "messages": [{"role": "user", "content": formatted_prompt}],
                }
                response = await client.invoke_model(
                    modelId=AppConfig.ANALYSIS_MODEL_ID, body=json.dumps(request_body)
                )
                response_body_bytes = await response["body"].read()
                response_body = json.loads(response_body_bytes)
                return {
                    "response": response_body["content"][0]["text"],
                    "success": True,
                }
        except Exception as e:
            LOGGER.error(f"AIOBedrock Error: {str(e)}")
            return {"error": str(e), "success": False}

    async def process_chunks_batch(
        self, chunks: list[dict], prompt_template: str
    ) -> list[dict]:
        """Processes a batch of document chunks asynchronously using Bedrock models.
        Args:
            chunks (list[dict]): A list of dictionaries, each containing a 'content' key with the text to process.
            prompt_template (str): A template string for the prompt to be sent to the model.
        Returns:
            list[dict]: A list of dictionaries, each updated with the model's response and success status.
        """
        session = get_session()
        tasks = [
            self._invoke_model_async(session, prompt_template.format(**chunk))
            for chunk in chunks
        ]
        results = await asyncio.gather(*tasks)
        for i, chunk in enumerate(chunks):
            chunk.update(results[i])
        return chunks


class DocumentChunkConsolidator:
    def extract_json_from_response(self, response_text: str) -> Dict[str, Any]:
        """Extracts a JSON object from the response text, handling both code blocks and inline JSON.
        Args:
            response_text (str): The text response from the model, which may contain JSON in code blocks or inline.
        Returns:
            Dict[str, Any]: A dictionary parsed from the JSON string found in the response.
        """
        match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", response_text, re.DOTALL)
        if match:
            json_str = match.group(1)
        else:
            start = response_text.find("{")
            end = response_text.rfind("}")
            if start != -1 and end != -1:
                json_str = response_text[start : end + 1]
            else:
                return {}

        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            json_str_fixed = re.sub(r",\s*([\}\]])", r"\1", json_str)
            try:
                return json.loads(json_str_fixed)
            except json.JSONDecodeError:
                LOGGER.warning("Failed to parse JSON even after attempting to fix it.")
                return {}

    def merge_data(self, base_data: Dict, new_data: Dict) -> Dict:
        """
        Merges two dictionaries, preferring non-empty values from `new_data` and combining lists without duplicates.
        Args:
            base_data (Dict): The original dictionary to merge into.
            new_data (Dict): The dictionary with new or updated values.
        Returns:
            Dict: A merged dictionary with the following rules:
                - Non-empty values from `new_data` overwrite empty or missing values in `base_data`.
                - For list values, combines items from both dictionaries without duplicates.
                - For string values, prefers the longer string (assumed to be more detailed).
                - Empty values in `new_data` are ignored.
        """
        merged = base_data.copy()
        for key, value in new_data.items():
            if not value:
                continue

            if key not in merged or not merged.get(key):
                merged[key] = value
            elif isinstance(merged.get(key), list) and isinstance(value, list):
                merged[key].extend([item for item in value if item not in merged[key]])
            elif isinstance(merged.get(key), str) and isinstance(value, str):
                if len(value) > len(merged[key]):
                    merged[key] = value
        return merged

    def consolidate_chunks(self, chunks: List[Dict]) -> Dict[str, Any]:
        """
        Consolidates a list of chunk dictionaries into a single dictionary by merging the data from successful chunks.
        Args:
            chunks (List[Dict]): A list of dictionaries, each representing a chunk with potential response data.
        Returns:
            Dict[str, Any]: A single dictionary containing the merged data from all successful chunks.
        Notes:
            - Only chunks with a truthy "success" key are processed.
            - The method relies on `extract_json_from_response` to parse the response and `merge_data` to combine results.
        """
        consolidated = {}
        for chunk in chunks:
            if chunk.get("success"):
                response_data = self.extract_json_from_response(chunk["response"])
                consolidated = self.merge_data(consolidated, response_data)
        return consolidated


async def main_processing_flow(bucket: str, key: str) -> Dict[str, Any]:
    LOGGER.info(f"Processing file: s3://{bucket}/{key}")
    file_type = get_file_type(key)
    if file_type == "unknown":
        raise ValueError(f"Unsupported file type for key: {key}")

    try:
        response = S3_CLIENT.get_object(Bucket=bucket, Key=key)
        file_data = response["Body"].read()
    except ClientError as e:
        raise ConnectionError(f"S3 download failed for s3://{bucket}/{key}: {e}")

    images = (
        pdf_to_images(file_data)
        if file_type == "pdf"
        else [resize_image_from_bytes(file_data)]
    )
    LOGGER.info(f"Converted document to {len(images)} image(s).")

    bedrock_response = process_with_bedrock(images, file_type)
    markdown_content = bedrock_response["combined_content"]
    batch_id = key.split("/")[1]
    save_markdown_to_s3(markdown_content, bucket, key, batch_id)

    chunker = MarkdownContextualChunker()
    chunks = chunker.create_contextual_chunks(markdown_content)
    LOGGER.info(f"Created {len(chunks)} contextual chunks from markdown.")

    processor = BedrockLLMProcessor()
    prompt_template = """Analyze this document chunk and extract the following key-value pairs in JSON format.
    For example, for an invoice:
    The values to be returned are "Invoice Number", "Total Amount", "Discounts", "Billing Address",
    "Shipping Address", "Payment Information", "Vendor Information", "Items Bought".
    If a value is not present, omit the key. Return the results like this. Content: {content}"""
    processed_chunks = await processor.process_chunks_batch(chunks, prompt_template)

    consolidator = DocumentChunkConsolidator()
    final_json = consolidator.consolidate_chunks(processed_chunks)
    return {"markdown_content": markdown_content, "final_json": final_json}


def extract_from_files(event):
    """
    Extracts text from files uploaded to S3, processes the content using Bedrock models,
    and returns the extracted text and metadata.
    Args:
        event (dict): A dictionary containing the following keys:
            - "batch_id" (str): The batch identifier for the classification.
            - "file_key" (str): The S3 key of the file to process.
    Returns:
        dict: A dictionary containing the extracted text, file key, S3 output key, and any error messages.
    Raises:
        ValueError: If the bucket or key is missing from the event.
        ConnectionError: If there is an error downloading the file from S3.
        Exception: If there is an unexpected error during processing.
    """
    bucket = CLASSIFICATIONS_BUCKET
    batch_id = event.get("batch_id")
    file_key = event.get("file_key")

    if not bucket or not file_key:
        return {
            "ExtractedText": {"text": ""},
            "file_key": file_key or "",
            "s3_output_key": "",
            "error": "Missing bucket or key.",
        }

    try:
        results = asyncio.run(main_processing_flow(bucket, file_key))
        s3_output_key = (
            f"extracted/{batch_id}/{file_key.split('/')[-1].split('.')[0]}.md"
        )
        return {
            "ExtractedText": {"text": results["markdown_content"].strip()},
            "file_key": file_key,
            "s3_output_key": s3_output_key,
            "final_json": results["final_json"],
        }
    except (ValueError, ConnectionError) as e:
        LOGGER.error(f"A processing error occurred: {e}")
        return {
            "ExtractedText": {"text": ""},
            "file_key": file_key,
            "s3_output_key": "",
            "error": str(e),
        }
    except Exception as e:
        LOGGER.error(f"An unexpected error occurred: {e}", exc_info=True)
        return {
            "ExtractedText": {"text": ""},
            "file_key": file_key,
            "s3_output_key": "",
            "error": "An internal server error occurred.",
        }


def put_classification_item(
    classification_name: str,
    username: str,
    batch_id: str,
    schema_key: str,
    blueprint_arn: str = None,
):
    """
    Saves metadata for a classification in the DynamoDB table.
    Args:
        classification_name (str): The name of the classification.
        username (str): The username of the creator.
        batch_id (str): The batch identifier for the classification.
        schema_key (str): The S3 key where the schema is stored.
        blueprint_arn (str, optional): The ARN of the blueprint, if applicable.
    Returns:
        bool: True if the item was successfully saved, False otherwise.
    Raises:
        ClientError: If there is an error putting the item into DynamoDB.
    """
    item = {
        "ClassificationName": classification_name,
        "CreatedBy": username,
        "BatchId": batch_id,
        "Description": "Generated from uploaded PDFs",
        "SchemaS3Location": schema_key,
        "CreatedAt": datetime.datetime.utcnow().isoformat(),
    }
    if blueprint_arn and blueprint_arn != "not created":
        item["BlueprintArn"] = blueprint_arn
    try:
        put_item(CLASSIFICATIONS_TABLE_NAME, item=item)
        LOGGER.info(
            f"Successfully saved metadata for classification '{classification_name}'."
        )
        return True
    except ClientError as e:
        LOGGER.error(f"Failed to put item in DynamoDB for '{classification_name}': {e}")
        return False


def schema_generation(event):
    """Generates a JSON schema from extracted text data using a Bedrock model.
    Args:
        event (dict): A dictionary containing the following keys:
            - "batch_id" (str): The batch identifier for the classification.
            - "username" (str): The username of the requester.
            - "classification_name" (str): The name of the classification.
            - "texts" (list): A list of dictionaries containing extracted text data, each with a "text" key.
    Returns:
        dict: A dictionary containing the generated schema, batch ID, username, and classification name.
    Raises:
        ValueError: If the input data is invalid or empty.
        Exception: If there is an error during the Bedrock model invocation or schema generation.
    """
    batch_id = event.get("batch_id")
    username = event.get("username")
    classification_name = event.get("classification_name")
    texts = event.get("texts", [])

    flat_texts = [
        item["text"] for item in texts if isinstance(item, dict) and "text" in item
    ]
    combined_text = "\n\n".join(
        t.strip() for t in flat_texts if t and isinstance(t, str)
    )

    if not combined_text:
        error_body = json.dumps(
            {
                "error": "Bedrock classification failed",
                "details": "No valid extracted text to classify",
            }
        )
        return {"statusCode": 500, "body": error_body}

    schema_example = {
        "InvoiceNumber": "unique identifier for the invoice",
        "OrderNumber": "associated order number, if applicable",
    }
    prompt = f"""You are a document classification and schema generation assistant. Your task is to analyze the following extracted text data from 5 documents in batch `{batch_id}` and generate a representative JSON schema. For each field, include the field name and the description of what the field represents.
        ### Example Output Format:
        {json.dumps(schema_example, indent=2)}
        ### Extracted Texts:
        {combined_text}
        Return the JSON schema only. Do not include explanations or markdown."""

    try:
        response = BEDROCK.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            body=json.dumps(
                {
                    "anthropic_version": "bedrock-2023-05-31",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 4000,
                    "temperature": 0.3,
                }
            ),
            contentType="application/json",
            accept="application/json",
        )
        body_str = response["body"].read().decode("utf-8")
        content_block = json.loads(body_str)
        raw_schema = content_block.get("content", [{}])[0].get("text", "")
        parsed_schema = json.loads(clean_json_string(raw_schema))
        return {
            "batch_id": batch_id,
            "username": username,
            "classification_name": classification_name,
            "schema": parsed_schema,
        }
    except Exception as e:
        LOGGER.error(f"Bedrock classification failed with error: {str(e)}")
        error_body = json.dumps(
            {"error": "Bedrock classification failed", "details": str(e)}
        )
        return {"statusCode": 500, "body": error_body}


def create_blueprint(event):
    """Creates a new blueprint for classification based on the provided event data.
    Args:
        event (dict): A dictionary containing the following
            - "username" (str): The username of the requester.
            - "batch_id" (str): The batch identifier for the classification.
            - "classification_name" (str): The name of the classification blueprint.
            - "blueprintStage" (str, optional): The stage of the blueprint, defaults to "LIVE".
            - "tags" (list, optional): A list of tags associated with the blueprint.
            - "schema" (dict, optional): The JSON schema for the classification.
    Returns:
        dict: A dictionary containing the blueprint name, stage, tags, and schema.
    Raises:
        KeyError: If required keys are missing from the event.
        Exception: If there is an error during the creation of the blueprint.
    """
    username = event.get("username")
    batch_id = event.get("batch_id")
    blueprint_name = event.get("classification_name")
    schema = event.get("schema")

    if not all([username, batch_id, blueprint_name]):
        raise KeyError("Missing 'username', 'batch_id', or 'classification_name'.")

    blueprint_stage = event.get("blueprintStage", "LIVE")
    tags = event.get("tags", [])
    model_schema = event.get("schema")

    example_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "class": "CMS 1500 Claim Form",
        "description": "A standard medical claim form used by healthcare providers in the US to bill health insurance companies for medical services.",
        "definitions": {
            "Procedure_Service_Supplies": {
                "properties": {
                    "service_start_date": {
                        "type": "string",
                        "inferenceType": "explicit",
                        "instruction": "The service start date from item 24A in YYYY-MM-DD format",
                    },
                    "service_end_date": {
                        "type": "string",
                        "inferenceType": "explicit",
                        "instruction": "The service end date from item 24A in YYYY-MM-DD format",
                    },
                    "place_of_service": {
                        "type": "string",
                        "instruction": "The place the service was provided",
                    },
                    "type_of_service": {
                        "type": "string",
                        "instruction": "The type of medical service",
                    },
                    "procedure_modifier": {
                        "type": "string",
                        "inferenceType": "explicit",
                        "instruction": "The procedure modifier from item 24D",
                    },
                    "diagnosis_code": {
                        "type": "string",
                        "inferenceType": "explicit",
                        "instruction": "The diagnosis code from item 24E",
                    },
                    "procedure_code": {
                        "type": "string",
                        "instruction": "The procedure code",
                    },
                    "charge_amount": {
                        "type": "number",
                        "instruction": "The charge amount for the procedure",
                    },
                }
            }
        },
        "properties": {
            "insurance_program": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insurance program from item 1: Medicare, Medicaid, CHAMPUS, CHAMPVA, Group Health Plan",
            },
            "insured_id_number": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's ID number from item 1a",
            },
            "patient_name": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The patient's name from item 2 in Last Name, First Name, Middle Initial format",
            },
            "patient_date_of_birth": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The patient's date of birth from item 3 in YYYY-MM-DD format",
            },
            "insured_name": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's name from item 4 in Last Name, First Name, Middle Initial format",
            },
            "patient_address": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The patient's address from item 5",
            },
            "patient_relationship_to_insured": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The patient's relationship to insured from item 6",
            },
            "insured_address": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's address from item 7 including No.,Street, City, State, Zip Code",
            },
            "insured_phone_number": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's phone number, including area code from item 7 ",
            },
            "patient_sex": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The patient's address from item 8",
            },
            "patient_marital_status": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The patient's address from item 8",
            },
            "patient_condition_related_to": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "Whether the patient's condition is related to employment, auto accident, or other accident from item 10",
            },
            "insured_policy_feca_number": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's policy group or FECA number from item 11",
            },
            "insured_date_of_birth": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's policy or group number from item 11a",
            },
            "insured_employer_or_school": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's employer or school 11b",
            },
            "insured_insurance_plan_name": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's plan name or program name from item 11c",
            },
            "another_health_benefit_plan_indicator": {
                "type": "boolean",
                "inferenceType": "explicit",
                "instruction": "d. IS THERE ANOTHER HEALTH BENEFIT PLAN? Yes or No from item 11d",
            },
            "patient_signed_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "patient's or authorized person's signature date from item 12",
            },
            "insured_signed_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The insured's or authorized person's signed date from item 13",
            },
            "illness_injury_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The date of current illness, injury, or pregnancy from item 14 in YYYY-MM-DD format",
            },
            "previous_illness_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The date of a previous similar illness from item 15 in YYYY-MM-DD format",
            },
            "unable_to_work_start_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The dates the patient was unable to work from item 16",
            },
            "unable_to_work_end_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The dates the patient was unable to work until item 16",
            },
            "referring_physician": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The name of the referring physician from item 17",
            },
            "referring_physician_id": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The ID number of the referring physician from item 17a",
            },
            "hospitalization_start_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The hospitalization start date related to current services from item 18",
            },
            "hospitalization_end_date": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The hospitalization end date related to current services from item 18",
            },
            "is_outside_lab_indicator": {
                "type": "boolean",
                "inferenceType": "explicit",
                "instruction": "Are there outside lab charges? from item 20",
            },
            "outside_lab_charges": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "Whether outside lab was used and charges from item 20",
            },
            "diagnosis_1": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The diagnosis or nature of illness or injury from item 21.1",
            },
            "diagnosis_2": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The diagnosis or nature of illness or injury from item 21.2",
            },
            "diagnosis_3": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The diagnosis or nature of illness or injury from item 21.3",
            },
            "diagnosis_4": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The diagnosis or nature of illness or injury from item 21.4",
            },
            "medicaid_resubmission_number": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "MEDICAID RESUBMISSION NUMBER from item 22",
            },
            "medicaid_original_ref_number": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "Medicaid - Original ref no. from item 22",
            },
            "prior_authorization_number": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The prior authorization number from item 23",
            },
            "medical_procedures": {
                "type": "array",
                "instruction": "The list of medical procedures from the table in item 24",
                "items": {"$ref": "#/definitions/Procedure_Service_Supplies"},
            },
            "tax_id_type": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The tax ID type (SSN or EIN) from item 25",
            },
            "tax_id_number": {
                "type": "string",
                "inferenceType": "explicit",
                "instruction": "The federal tax ID number (SSN or EIN) from item 25",
            },
            "total_charges": {
                "type": "number",
                "inferenceType": "explicit",
                "instruction": "The total charges in dollars from item 28",
            },
            "amount_paid": {
                "type": "number",
                "inferenceType": "explicit",
                "instruction": "The amount paid in dollars from item 29",
            },
        },
    }
    prompt = f"""
        You are a schema expert designing detailed JSON Schemas for intelligent document processing and structured extraction.

        Given a simplified JSON Schema, generate a **complete and enriched Draft-07 compliant JSON Schema** with:

        1. `$schema`, `class`, `description`, `type`, `definitions`, and `properties`.
        2. "$schema": "http://json-schema.org/draft-07/schema#" should be the first line 
        3.  IMPORTANT: There shouldnt be a "type" field after the "class" field in the schema.
        4. `"type"` for every field in definitions (string, number, boolean, array, object) 
        5. `"inferenceType"` as `"explicit"` for every extractable field.
        6. `"inferenceType"` should not be a field for anything with the `"type"` as `"array"`
        7. `"instruction"` based on the meaning of the field — elaborated to help guide intelligent extraction.
        8. `"instruction"` must be present for all types. even `"type"` as `"array"`
        8. Use `definitions` and `$ref` for all reusable structures (like BankDetails, ProviderDetails, etc.).
        9. Use consistent naming (camelCase for keys).

        This is an example of how the schema generated should be:
        {example_schema}
        Make sure the schema is:
        - Fully valid JSON (no markdown formatting),
        - Draft-07 compliant,
        - Complete, modular, and well-structured.

        Respond ONLY with a valid JSON object — no comments or extra text.
        If you do not do this properly i will get fired.

        Here is the base schema that you should perform the conversion on:
        {schema}
        """

    try:
        response = BEDROCK.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            body=json.dumps(
                {
                    "anthropic_version": "bedrock-2023-05-31",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 4000,
                    "temperature": 0.3,
                }
            ),
            contentType="application/json",
            accept="application/json",
        )
        body_str = response["body"].read().decode("utf-8")
        content_block = json.loads(body_str)
        raw_schema = content_block.get("content", [{}])[0].get("text", "")
        cleaned = clean_json_string(raw_schema)
        parsed_schema = json.loads(cleaned)

        try:
            bp_response = BEDROCK_AUTOMATION.create_blueprint(
                blueprintName=blueprint_name,
                type="DOCUMENT",
                blueprintStage=blueprint_stage,
                schema=json.dumps(parsed_schema),
                clientToken=str(uuid.uuid4()),
                tags=tags,
            )
            return {
                "statusCode": 200,
                "batch_id": batch_id,
                "username": username,
                "classification_name": blueprint_name,
                "blueprint_arn": bp_response["blueprint"]["blueprintArn"],
                "schema": model_schema,
            }
        except ClientError as e:
            LOGGER.info(f"Could not create blueprint, continuing without it: {e}")
            return {
                "statusCode": 200,
                "batch_id": batch_id,
                "username": username,
                "classification_name": blueprint_name,
                "blueprint_arn": "not created",
                "schema": model_schema,
            }
    except Exception as e:
        return {"statusCode": 500, "error": f"Failed to create blueprint: {str(e)}"}


def save_results(event):
    """
    Saves classification schema data to S3 and metadata to DynamoDB.

    Args:
        event (dict): A dictionary containing the following keys:
            - "schema" (dict or str): The schema data to be saved. Can be a dict or a JSON string.
            - "username" (str): The username of the creator.
            - "batch_id" (str): The batch identifier.
            - "classification_name" (str): The name of the classification.
            - "blueprint_arn" (str): The ARN of the blueprint, or "not created".
            - "blueprintStage" (str, optional): The blueprint stage. Defaults to "LIVE".
            - "tags" (list, optional): List of tags. Defaults to an empty list.

    Returns:
        dict: A response dictionary with:
            - "statusCode" (int): HTTP status code.
            - "body" (str): JSON-encoded response body with either a success message or error details.

    Raises:
        None. All exceptions are caught and returned as error responses.
    """
    try:
        schema_data = event.get("schema")
        username = event.get("username")
        batch_id = event.get("batch_id")
        classification_name = event.get("classification_name")
        blueprint_arn = event.get("blueprint_arn")

        if isinstance(schema_data, str):
            schema_data = json.loads(schema_data)

        classification_name_no_space = classification_name.replace(" ", "_").upper()
        schema_key = f"schemas/{classification_name_no_space}-{username}-schema.json"

        S3_CLIENT.put_object(
            Bucket=CLASSIFICATIONS_BUCKET,
            Key=schema_key,
            Body=json.dumps(schema_data),
            ContentType="application/json",
        )

        item = {
            "ClassificationName": classification_name,
            "CreatedBy": username,
            "BatchId": batch_id,
            "Description": "Generated from uploaded PDFs",
            "SchemaS3Location": schema_key,
            "CreatedAt": datetime.datetime.utcnow().isoformat(),
        }
        if blueprint_arn and blueprint_arn != "not created":
            item["BlueprintArn"] = blueprint_arn
        DB_HANDLER.put_classification_item(item=item)
        return {
            "statusCode": 200,
            "body": json.dumps(
                {
                    "message": "Classification created",
                    "classification_name": classification_name,
                }
            ),
        }
    except Exception as e:
        LOGGER.error(f"Failed to save results: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Failed to save results: {str(e)}"}),
        }


def clean_json_string(raw: str) -> str:
    """
    Removes Markdown code block markers and backticks from a raw JSON string.

    Args:
        raw (str): The raw string potentially containing Markdown code block markers or backticks.

    Returns:
        str: The cleaned string with code block markers and backticks removed.
    """
    cleaned = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE)
    return re.sub(r"^\s*`|`\s*$", "", cleaned)


def generate_presigned_url(bucket, key, expiration, content_type, method):
    """
    Generates a pre-signed URL for an S3 object.

    Args:
        bucket (str): The name of the S3 bucket.
        key (str): The object key (path/filename) in the S3 bucket.
        expiration (int): Time in seconds for the pre-signed URL to remain valid.
        content_type (str): The MIME type of the object.
        method (str): The client method to generate the URL for (e.g., 'get_object', 'put_object').

    Returns:
        str: A pre-signed URL.

    Raises:
        botocore.exceptions.ClientError: If the URL could not be generated.
    """
    params = {"Bucket": bucket, "Key": key}
    if method == "get_object" and content_type:
        params["ResponseContentType"] = content_type
    elif method == "put_object" and content_type:
        params["ContentType"] = content_type
    return S3_CLIENT.generate_presigned_url(
        ClientMethod=method, Params=params, ExpiresIn=expiration
    )


def _success_response(status_code, body):
    """
    Generates a standardized success response dictionary for AWS Lambda functions.

    Args:
        status_code (int): The HTTP status code to return.
        body (dict): The response body to be serialized into JSON.

    Returns:
        dict: A dictionary with 'statusCode', a JSON-encoded 'body', and standard headers.
    """
    return response(status_code, body)


def _error_response(status_code, message):
    """
    Generates a standardized error response dictionary for AWS Lambda functions.

    Args:
        status_code (int): The HTTP status code to return.
        message (str): The error message to include in the response body.

    Returns:
        dict: A dictionary with 'statusCode' and a JSON-encoded 'body' containing the error message.
    """
    return response(status_code, {"Error": message})


def get_schema_from_s3(bucket, key):
    """
    Retrieves a schema file from an S3 bucket.

    Args:
        bucket (str): The name of the S3 bucket.
        key (str): The object key (path/filename) in the S3 bucket.

    Returns:
        dict: The schema file as a dictionary, or None if the file could not be retrieved.
    """
    try:
        response = S3_CLIENT.get_object(Bucket=bucket, Key=key)
        return json.loads(response["Body"].read().decode("utf-8"))
    except Exception as e:
        LOGGER.error(f"Error retrieving schema from S3: {str(e)}")
        return None


def get_all_classifications(event, username):
    """
    Retrieves all classifications created by the user and system.
    Args:
        username (str): The username of the requester.
    Returns:
        dict: A JSON-encoded list of classifications, including user and system-created ones.
    Raises:
        Exception: If there is an error retrieving classifications from the database.
    """

    try:
        LOGGER.info(f"Getting classifications for user: {username}")
        query_string_parameters = event.get("queryStringParameters") or {}
        limit_param = query_string_parameters.get("limit")
        sort_by = query_string_parameters.get("sort-by", None)
        offset_param = query_string_parameters.get("offset")
        limit = int(limit_param) if limit_param else 15
        offset = int(offset_param) if offset_param else 0
        try:
            user_items = DB_HANDLER.get_classifications_by_creator(username)
            system_items = DB_HANDLER.get_classifications_by_creator("System")
            LOGGER.info(f"Classifications: {user_items+system_items}")
            result = paginate_list(
                "Classifications",
                user_items + system_items,
                VALID_CLASSIFICATIONS_KEYS,
                offset,
                limit,
                sort_by,
            )
            return response(200, result)
        except Exception as e:
            LOGGER.error(f"Error getting classifications: {str(e)}")
            return response(500, {"Error": "Internal Server Error"})
    except Exception as e:
        LOGGER.error(f"Error getting classifications: {str(e)}")
        return response(500, {"Error": "Internal Server Error"})


def delete_classification(username, classification_name):
    """
    Deletes a classification by its name if it exists and the user has permission.
    Args:
        username (str): The username of the requester.
        classification_name (str): The name of the classification to delete.
    Returns:
        dict: A success response if the classification was deleted, or an error response if not found
            or unauthorized.
    Raises:
        Exception: If there is an error deleting the classification from the database.
    """
    try:
        items = DB_HANDLER.get_classification_by_name(username, classification_name)
        if not items:
            return _error_response(404, "Classification not found or unauthorized")
        item_to_delete = items[0]
        DB_HANDLER.delete_classification_by_key(
            {"ClassificationName": item_to_delete["ClassificationName"]}
        )
        return _success_response(
            200, {"Message": "Classification deleted successfully."}
        )
    except Exception as e:
        LOGGER.error(f"Error deleting classification: {str(e)}")
        return _error_response(500, "Internal Server Error")


def get_single_classification(username, classification_name):
    """
    Retrieves a single classification by its name if it exists and the user has permission.
    Args:
        username (str): The username of the requester.
        classification_name (str): The name of the classification to retrieve.
    Returns:
        dict: A success response with the classification details if found, or an error response if not found
            or unauthorized.
    Raises:
        Exception: If there is an error retrieving the classification from the database.
    """
    try:
        creator = (
            "System" if classification_name in PREBUILT_CLASSIFICATIONS else username
        )
        items = DB_HANDLER.get_classification_by_name(creator, classification_name)
        if not items:
            return _error_response(404, "Classification not found or unauthorized")

        item = items[0]
        presigned_url = generate_presigned_url(
            CLASSIFICATIONS_BUCKET,
            item["SchemaS3Location"],
            3600,
            "application/json",
            "get_object",
        )
        item["PresignedURL"] = presigned_url
        return _success_response(200, item)
    except Exception as e:
        LOGGER.error(f"Error getting classification: {e}")
        return _error_response(500, "Internal Server Error")


def create_classification(username, body):
    """
    Creates a new classification by generating pre-signed URLs for file uploads and saving metadata.
    Args:
        username (str): The username of the requester.
        body (dict): The request body containing:
            - "ClassificationName" (str): The name of the classification.
            - "Files" (list): A list of dictionaries with "FileName" and "ContentType".
            - "Description" (str, optional): A description for the classification.
    Returns:
        dict: A response dictionary with 'statusCode', 'body', and 'headers'.
            - On success, includes pre-signed URLs for file uploads.
            - On error, includes an error message.
    Raises:
        ValueError: If the request body is missing or invalid.
        Exception: If there is an error creating the classification or generating pre-signed URLs.
    """
    if not body:
        return _error_response(400, "Request body is needed.")
    classification_name = body.get("ClassificationName")
    files = body.get("Files", [])

    if classification_name in PREBUILT_CLASSIFICATIONS:
        return _error_response(
            400, "Cannot create a classification with a reserved name."
        )
    if len(files) != 5:
        return _error_response(400, "Exactly 5 files must be uploaded.")
    try:
        creator = (
            "System" if classification_name in PREBUILT_CLASSIFICATIONS else username
        )
        classifications = DB_HANDLER.get_classification_by_name(
            creator, classification_name
        )
    except Exception as e:
        LOGGER.error(f"Error getting classification: {e}")
        return _error_response(500, "Internal Server Error")
    if classification_name in [c["ClassificationName"] for c in classifications]:
        LOGGER.error(f"Already created classification with same name")
        return _error_response(400, "Already created classification with same name")
    try:

        files = body["Files"]

        if len(files) != 5:
            return _error_response(
                400,
                "Exactly 5 files must be uploaded to create a classification.",
            )

        batch_id = str(uuid.uuid4())

        presigned_urls = []
        s3_keys = []

        for file in files:
            file_name = file["FileName"]
            content_type = file["ContentType"]

            if content_type not in VALID_CONTENT_TYPES:
                presigned_urls.append(
                    {
                        "FileName": file_name,
                        "FilePreSignedUrl": "",
                        "S3Bucket": CLASSIFICATIONS_BUCKET,
                        "S3Key": "",
                        "Status": "Invalid content type",
                    }
                )
                continue

            s3_key = f"uploads/{batch_id}/{file_name}"

            presigned_url = generate_presigned_url(
                CLASSIFICATIONS_BUCKET,
                s3_key,
                expiration=3600,
                content_type=content_type,
                method="put_object",
            )

            presigned_urls.append(
                {
                    "FileName": file_name,
                    "FilePreSignedUrl": presigned_url,
                    "Status": "Uploading",
                }
            )

            s3_keys.append(s3_key)

        if any(u["Status"] == "Invalid content type" for u in presigned_urls):
            return {
                "statusCode": 400,
                "body": json.dumps(
                    {
                        "Message": "One or more files had invalid content types.",
                        "UploadUrls": presigned_urls,
                    }
                ),
                "headers": HEADERS,
            }
        item = {
            "BatchId": batch_id,
            "CreatedBy": username,
            "ClassificationName": classification_name,
            "Description": body.get("Description", ""),
            "Status": "uploading",
            "CreatedAt": datetime.datetime.utcnow().isoformat(),
            "FilesUploaded": 0,
        }
        DB_HANDLER.put_classification_item(item=item)
        LOGGER.info(
            f"Created classification item in DynamoDB for {classification_name} with batch ID {batch_id}."
        )
        return _success_response(
            200,
            {
                "Message": "Creating Classification",
                "UserName": username,
                "ClassificationName": classification_name,
                "BatchId": batch_id,
                "UploadUrls": presigned_urls,
            },
        )

    except Exception as e:
        LOGGER.error(f"Error creating classification: {str(e)}")
        return _error_response(500, "Internal Server Error")


def handle_api_request(event):
    """Handles API requests for classification management.
    Args:
        event (dict): The API Gateway event containing request details.
            Expected keys:
                - "resource": The API resource path.
                - "httpMethod": The HTTP method (GET, POST, DELETE).
                - "requestContext": Contains authorizer claims with 'cognito:username'.
                - "pathParameters": Optional parameters for the request.
    Returns:
        dict: A response dictionary with 'statusCode', 'body', and 'headers'.
    Raises:
        KeyError: If required keys are missing from the event.
    """
    resource = event.get("resource")
    method = event.get("httpMethod")
    try:
        username = event["requestContext"]["authorizer"]["claims"]["cognito:username"]
        users_response = query_items(
            USERS_TABLE_NAME, key_condition_expression=Key("Username").eq(username)
        )
        if not users_response:
            LOGGER.error(f"User not signed in: {username}")
            return _error_response(404, "User not found")
    except KeyError:
        return _error_response(401, "Unauthorized")

    path_params = event.get("pathParameters") or {}

    if resource == "/classifications" and method == "GET":
        return get_all_classifications(event, username)
    elif resource == "/classifications/{classification-name}" and method == "DELETE":
        return delete_classification(username, path_params.get("classification-name"))
    elif resource == "/classifications/{classification-name}" and method == "GET":
        return get_single_classification(
            username, path_params.get("classification-name")
        )
    elif resource == "/classifications" and method == "POST":
        return create_classification(username, json.loads(event.get("body", "{}")))

    return _error_response(404, "Resource not found")


def handle_task_request(event):
    """
    Handles task requests for IDP classifications.
    Args:
        event (dict): The event data containing the task to execute.
            Expected keys:
                - "task": The name of the task to execute (e.g., "classification_extraction", "schema_generation", "blueprint_creation", "save_results").
    Returns:
        dict: A response dictionary containing the result of the executed task.
    Raises:
        KeyError: If the "task" key is missing from the event.
        Exception: If the task execution fails.
    """
    task = event.get("task")
    LOGGER.info(f"Executing task: {task}")

    if task == "classification_extraction":
        try:
            return extract_from_files(event)
        except Exception as e:
            LOGGER.error(f"Task '{task}' failed: {str(e)}")
            return {"statusCode": 500, "error": f"Task failed: {str(e)}"}
    elif task == "schema_generation":
        try:
            return schema_generation(event)
        except Exception as e:
            LOGGER.error(f"Task '{task}' failed: {str(e)}")
            return {"statusCode": 500, "error": f"Task failed: {str(e)}"}
    elif task == "blueprint_creation":
        try:
            return create_blueprint(event)
        except Exception as e:
            LOGGER.error(f"Task '{task}' failed: {str(e)}")
            return {"statusCode": 500, "error": f"Task failed: {str(e)}"}
    elif task == "save_results":
        try:
            return save_results(event)
        except Exception as e:
            LOGGER.error(f"Task '{task}' failed: {str(e)}")
            return {"statusCode": 500, "error": f"Task failed: {str(e)}"}
    else:
        LOGGER.error(f"Unknown task: {task}")
        return {"statusCode": 400, "error": "Unknown task"}


def lambda_handler(event, context):
    """Main entry point for the Lambda function handling IDP classifications.
    Args:
        event (dict): The event data passed to the Lambda function, typically from an API Gateway request.
        context (LambdaContext): The context object providing runtime information.
    Returns:
        dict: A response dictionary containing the status code and body.
    """
    log_format = f"In {context.function_name}.%(funcName)s %(message)s"
    formatter = logging.Formatter(log_format)
    if LOGGER.handlers:
        LOGGER.handlers[0].setFormatter(formatter)
    LOGGER.info(f"Received event: {json.dumps(event)}")
    if "resource" in event:
        return handle_api_request(event)
    elif "task" in event:
        return handle_task_request(event)
    else:
        LOGGER.error("Invalid event structure")
        return _error_response(400, "Invalid event structure")
